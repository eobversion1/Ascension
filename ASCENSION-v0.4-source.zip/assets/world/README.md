# World artwork

`ascension-eras.png` was generated for ASCENSION v0.3 using the image generation tool. It contains three equal panels: poverty/alley, commerce/harbour, and political power/citadel. Godot AtlasTexture regions select panels at runtime; the original image is not destructively cropped. The smaller SVG studies are original project artwork. Font and engine notices remain in assets/licenses.

`living-districts.png` is original generated artwork for v0.4, a four-panel district atlas (survival, artisan market, guild commerce, civic capital). The image-generation tool produced the unmodified master at `/workspace/generated_images/exec-2c75bb4d-5d6a-40ec-98a0-e2ec91026f62.png`. Runtime AtlasTextures select each panel. Building ownership controls and animated supply links are drawn by `scripts/world_view.gd`; reduced motion freezes those effects. No third-party game artwork or interface was copied.
