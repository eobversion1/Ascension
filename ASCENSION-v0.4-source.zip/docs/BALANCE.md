# Deterministic chapter balance

## Current v0.2 results

The unchanged rank gates and prices, with the new derived rank benefits, complete in **20m15s (economy)** and **38m (influence)** under the same actual-engine policies. Both first promotions occur at 60 simulated seconds. Both policies complete all ranks without mandatory deadlocks and remain finite at every checkpoint through one day. See `tests/results/v02/balance.json` and [current validation](VALIDATION_V02.md).

The methodology and v0.1 tuning history below are retained for reference; the historical checkpoint table is not the v0.2 result.

The simulation runs the real `AscensionGame` GDScript, not a translated economy model. It starts with zero, performs fifteen WORK taps, buys the first stall, then advances in 15-second steps. Each visit may make up to three investments plus available strategic decisions. No resources, ranks or passive earnings are granted outside normal game actions. No automatic Legacy resets occur after chapter completion.

The economy profile values coin/reputation/influence income at 1/100/1000; the influence profile uses 1/120/1600. Each compares production increase against mixed-resource cost and waits for the best investment. Both establish required holdings and a five-Trading-Post commercial foundation after Guildmaster to avoid starving civic investment. They choose opposite options in all four decisions. These heuristic policies demonstrate two viable paths; they are not exhaustive proofs of optimality or human completion-time estimates.

## Measured tuning

The initial rates allowed overly fast completion. With the same final policy harness, the original content completed in 11m45s (economy) and 18m00s (influence). Production base rates were reduced to 40% of the original rates, preserving price growth and multiplier interactions. Cultivate Patrons now adds 20% coins (previously 10%); Coalition adds 10% (previously 5%). These retain a commercial trade-off while making civic investment less coin-starved.

The final paths complete at **21m15s** and **37m30s**, inside the requested 20–45 minute first-chapter target. Earlier exploratory policies lacking a minimum commercial foundation took longer for influence; baseline and final JSON use the same final harness.

| Profile | Minutes | Rank | Coins earned | Reputation earned | Influence earned |
|---|---:|---|---:|---:|---:|
| economy | 5 | Street Vendor | 675 | 0 | 0 |
| economy | 20 | Civic Advocate | 643,595 | 3,128 | 18 |
| economy | 45 | Civic Leader | 12,712,694 | 112,964 | 30,373 |
| economy | 120 | Civic Leader | 65,784,787 | 650,058 | 207,631 |
| economy | 1440 | Civic Leader | 1,420,848,177 | 15,218,999 | 5,440,533 |
| influence | 5 | Street Vendor | 675 | 0 | 0 |
| influence | 20 | Guildmaster | 86,386 | 1,669 | 10 |
| influence | 45 | Civic Leader | 660,970 | 135,360 | 965 |
| influence | 120 | Civic Leader | 6,177,661 | 1,254,826 | 127,999 |
| influence | 1440 | Civic Leader | 337,315,064 | 48,586,706 | 8,153,638 |

Economy leads wealth and chapter completion; influence produces more reputation at 45 minutes and more influence by one day. These trade-offs depend on investment policy and holdings. Both buy all four decisions by one day, complete all seven ranks, and keep valid nonnegative balances. At one day the first chapter is already complete; results describe continued investment without prestige, not another day of new content.

Evidence: `tests/results/balance-before.json` contains the original content at all five checkpoints; `tests/results/balance.json` contains the final content and full rank timestamps. Run `./tools/godot.sh --headless --path . --script res://tests/balance_simulation.gd` to regenerate the final report.

Remaining balance validation: first-time human playtests, alternative purchase behaviour, long idle gaps and repeat Legacy runs. The numerical tests do not establish enjoyment or device performance.
