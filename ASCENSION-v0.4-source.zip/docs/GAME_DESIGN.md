# Chapter One design

The player builds a livelihood from fifteen manually earned coins, replaces tapping with recurring production, then converts commercial success into reputation and political influence. The delivered chapter ends at Civic Leader. Its seven ranks are Homeless Beggar, Street Scavenger, Street Vendor, Independent Trader, Guildmaster, Civic Advocate and Civic Leader.

Six institutions form an interdependent economy. Stalls, Workshops and Trading Posts generate coins; Rumour Networks generate reputation; Campaign Offices and Civic Halls create influence and reputation. Ownership is additive, purchase prices grow geometrically, and fourteen permanent-for-this-run upgrades multiply production; a fifteenth, the Trade Clerk, automates paid contract reinvestment. Coin upgrades show payback estimates for the current asset mix. Promotions use cumulative earnings and holdings so spending does not undo milestone progress.

Enterprise introduces reputation networks and a coin-to-reputation action. Guildmaster introduces campaigns that convert coins plus reputation into influence. Civic leadership unlocks Legacy: a confirmed reset grants one permanent point worth +25% global output. Later runs retain all previous points. Four exclusive decisions change resource and institution multipliers; commercial choices improve wealth at the expense of reputation or influence, while public investment trades faster commercial growth for greater civic output.

The UI uses navy surfaces, warm gold for money/status, green reputation and blue influence. A persistent goal opens an inspectable rank ladder. Resources and affordability refresh without rebuilding touch controls. A scrollable content area keeps fixed navigation and action targets available on portrait screens. Android display-safe-area margins are computed on resize.

Persistence is offline-first. Atomic replacement and a backup protect version-1 JSON saves; unsupported or corrupt files cannot silently overwrite a player's progress. Background/resume grants one capped award and skips the first resumed simulation frame. Manual Pause means no income, including offline income. Clock trust is local and bounded, not secure.

## Next three improvements

1. Physical Android tests across tall/narrow screens, system bars, process eviction and battery-saving modes; use measured frame/memory results before optimisation claims.
2. A short contextual tutorial explaining reinvestment, resource bottlenecks and mutually exclusive decisions, informed by first-time human playtests.
3. A new administrative era after Civic Leader with policy budgets and civic objectives. Do not introduce cosmic reskins before that layer offers new decisions.
