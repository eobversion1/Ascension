# ASCENSION — Codex Build Brief

## Immediate instruction to GPT-6 Astra in Codex

You are the lead game designer, gameplay systems engineer, Godot developer, economy balancer, and QA engineer for **ASCENSION: From Beggar to God-Emperor**.

**Begin creating a real, working Godot project in the currently selected repository/folder immediately. Do not stop after producing a design document.** Make reasonable product and implementation decisions without repeatedly asking for preferences. Work in small verifiable milestones, test each milestone, and prioritise something genuinely playable before attempting the entire enormous progression tree.

The intended deliverable is an **offline-capable, portrait-first Android idle / incremental strategy RPG** with satisfying compounding gains, meaningful gameplay decisions, visible status progression, and eventually staggering cosmic scale. The player begins as a destitute, homeless beggar and, over many transformations, becomes a universally worshipped God-Emperor and finally an omnipotent creator of existence. This is a fictional game: handle destitution as the starting challenge without making mockery of real poverty.

### Technology and build

- Engine: a current **stable Godot 4.x**, GDScript, using native Godot Control-based UI.
- Target: touch-driven Android phone, portrait aspect ratio, readable type, responsive layouts, safe-area handling. Desktop play/test in the editor must also work.
- Delivery: complete editable Godot source project, documented build/export instructions, and a debug **APK only if successfully compiled** in the actual environment. If Android SDK, OpenJDK, export templates, signing, or other tools are missing and cannot be installed, say so specifically. Do **not** report that an APK exists unless verified on disk. Do not create a fake APK or substitute a website for the requested Android app.
- No paid assets, proprietary artwork, ads, microtransactions, account requirements, backend, or intrusive permissions.
- Initialise Git if appropriate and create a clear README, a concise GAME_DESIGN.md, and DEVELOPMENT_LOG.md. Do not publish a public repository or spend money without explicit approval.

## Product pillars (non-negotiable)

1. **Compounding power that feels extraordinary.** Resource production and strategic multipliers should genuinely interact; upgrades should be mathematically consequential, not cosmetic. Players can inspect income rates, costs, returns and bottlenecks.
2. **Meaningful decisions.** At every major rank, the player can choose competing investments, political strategies, societal structures, research directions, or methods of conquest with understandable tradeoffs. There must be no single always-optimal choice in all contexts.
3. **An unfolding game.** The rules change as status rises. Begging and survival become trade and reinvestment, then political influence and administration, then military/economic/geopolitical control, then stellar/galactic expansion, then metaphysical governance and reality creation. Do not simply reskin the same button every era.
4. **Useful idling.** Automate previously manual actions, earn capped offline progress fairly, and make returning to the game interesting. No punitive wait walls and no need to tap continuously.
5. **Prestige is transformative.** Reset systems eventually sacrifice temporary resources for substantial permanent upgrades and new mechanics. A reset should involve a genuine strategic decision rather than an obligatory instant loop.
6. **Great mobile ergonomics.** Clear next goals, obvious interactions, readable compact resource bars, understandable upgrade economics, satisfying notifications, light animations and haptics if appropriate, accessible colour contrast.

## Long-range progression vision

Illustrative hierarchy; flesh out over time with intermediate ranks and unlock conditions:

1. **Survival:** Homeless Beggar → Scavenger → Street Vendor.
2. **Enterprise:** Trader → Merchant → Guildmaster → Industrial Magnate.
3. **Influence and Statecraft:** Civic Leader → Mayor → Noble → Monarch → Emperor.
4. **Planetary Dominion:** World Sovereign → Planetary Emperor.
5. **Spacefaring Power:** Stellar Regent → Galactic Emperor.
6. **Universal Dominion:** Universal Sovereign → God-Emperor.
7. **Absolute Ascension:** Architect of Reality → Creator of Existence.

A status promotion must introduce a new resource, system, strategic challenge, automation layer, or interactable mechanic; changing only a title is insufficient.

## Phase 1: build a playable vertical slice NOW

**Scope:** first three distinct eras (Survival, Enterprise, Local Influence), culminating in a civic-leadership milestone. Make this playable in roughly 20–45 minutes for a first-time tester, with replay and an early prestige-like 'Legacy' mechanic if it can be added without compromising completeness. This target is for balancing, not for promising production time.

Minimum real gameplay:

- Start with no money and no assets. One initially active action to earn the first coins, soon replaced by automation.
- At least **three distinct resources** (e.g. Coins, Reputation, Influence), with at least two direct interactions between them. Wealth alone must not determine every promotion.
- At least **12 working, data-driven upgrades** with nontrivial compounding modifiers, mixed pricing curves and clear income consequences. Include both additive/linear and multiplicative effects.
- At least **three income-producing enterprises or institutions** with ownership levels, scale-dependent upgrade costs, automatic generation, and unlock requirements.
- At least **four meaningful decisions/events** with two or more selectable outcomes each, visible costs and benefits, persistent consequences, and alternative viable builds (e.g. reinvest profits vs cultivate patronage; commercial expansion vs local influence).
- At least **two systems unlocked by a rank transition**, such as reputation networks, hiring, civic projects, or political alliances; do not just unlock new upgrade buttons.
- A visible rank ladder with progress to the next milestone and requirements that can be inspected.
- Automation upgrades that retire low-level busywork; recurring revenue while the app is open; pause/resume and offline awards after the app is closed.
- A lightweight achievement log, brief event log, upgrade affordability indicators, and an easy way to understand why a target is blocked.
- Save/load with versioned JSON or other robust Godot-native format and atomic/backup-safe strategy where practical; a voluntary reset and clear confirmation for destructive actions.
- Optional sound and vibration must default to respectful levels, with a mute toggle.

### Progression maths and balance

Implement a reusable economy engine, separate from presentation code. Define generator production, cost scaling, upgrade effects, bonuses, rank requirements, permanent bonuses, and offline income as **data** where possible.

Suggested mechanics, to refine through automated simulation:

- Generator n-th purchase cost: `base_cost * growth_factor ^ owned`, using different growth factors per enterprise.
- Effective production: `sum(base_output_i * owned_i * generator_multiplier_i) * global_multiplier * era_multiplier`, with transparent breakdowns.
- Strategic decisions modify multipliers, unlocks, resource-conversion rates, or risks; permanent and temporary multipliers must be clearly separated.
- A production upgrade must show estimated payoff time where meaningfully calculable, without promising perfect predictions under changing rates.
- Do not allow exploits through buy/sell arithmetic, negative time, free resets, or precision loss.

Create a **tested BigNumber abstraction** or equivalent representation that safely supports very large values (eventually well beyond `1e308`), comparisons, arithmetic needed for the economy, and human-readable suffixes/scientific notation. It need not be arbitrary-precision mathematics, but must avoid `INF`, `NaN`, overflow and obvious rounding exploits. Small-number transactions should remain accurate.

Use a delta-time-based simulation appropriate for variable frame rates. Make offline rewards bounded (initial default: up to 8 hours of elapsed time), detect backward-clock changes, avoid duplicating rewards on reload, and document the limits of local clock trust. Do not pretend offline rewards are tamper-proof on a fully offline device.

Balance from a cold start using deterministic simulation harnesses at **5 min, 20 min, 45 min, 2 hours, 1 day**, under at least two strategy profiles (economy-heavy and influence-heavy). Verify that both can progress, that the player faces interesting tradeoffs, that purchase prices remain achievable, and that progression is neither instant nor artificially stalled. Adjust curves based on the test outputs, not guesswork.

## Visual direction

- A premium, clean, slightly atmospheric interface: dark charcoal / deep navy surfaces, warm gold for status, cool blue for technology, and restrained colour coding for resources.
- Portrait mobile: compact top status/rank area, primary action and income indicators, distinct tabs for **Empire**, **Upgrades**, **Decisions**, and **Ascension / Milestones**. Different eras should feel visually distinct without rebuilding the entire UI.
- Animate resource increments subtly, celebrate milestone promotions, and include useful empty states and tooltips.
- Prefer polished reusable components to elaborate artwork; any icons should be authored or legally reusable.

## Architecture and quality

Separate:

- `GameState` / save schema;
- economy and BigNumber mathematics;
- content definitions (eras, ranks, enterprises, upgrades, decisions);
- progression / unlock logic;
- offline accrual;
- event handling;
- UI scenes and presentation;
- automated tests and balancing simulations.

Use idiomatic Godot signals and scene composition. Avoid all state and business logic living in one enormous script. Include defensive handling for save corruption and state migration.

### Automated tests / acceptance criteria

1. Project opens in the selected stable Godot release without parse errors.
2. It runs from the project main scene and shows an actually interactive game (not an unconnected UI prototype).
3. From a fresh save a human can earn resources, buy upgrades, automate production, choose at least two mutually exclusive decision paths, and advance through the initial three eras.
4. Numbers and income rates update correctly across time steps, upgrades and multipliers, including a very-large-number test.
5. Save -> close -> reopen restores ranks, purchases, choices and balances; an 8-hour offline calculation cannot award more than its cap.
6. There are no negative balances, duplicated purchase benefits, NaN/INF values, or broken progression gates under normal test cases.
7. UI works on at least two phone-like portrait viewport sizes and handles touch target sizing.
8. If the environment supports an Android build, create and verify the actual APK's path and file size; if possible install/run it on an Android emulator. Distinguish **compiled**, **installed**, and **manually play-tested**.
9. Create a README with exact steps to run the project, test it, and export Android APK; list outstanding issues honestly.

## How to execute this assignment

Start by checking the current folder, Godot installation, and Android export tooling. Write a **short** implementation plan and then immediately implement Phase 1. If infrastructure is missing, continue with all work that can be completed, documenting what is blocked. Install dependencies only when permitted. Run tests and correct discovered issues. After Phase 1 is working, provide a concise report: what was built, what actually runs, what was tested, whether the APK was produced, where artifacts are located, and the next three highest-value enhancements.

**Do not attempt to generate all cosmic eras before the initial game is functional. Do not stop at architecture, wireframes, placeholders, or a source-code dump. The measure of success is whether someone can genuinely play and enjoy the first progression loop.**
