# Android build and verification

## Tested toolchain

- Godot **4.6.3.stable.official.7d41c59c4**, matching **4.6.3.stable** Android debug/release templates.
- OpenJDK **21.0.12.1+1-1-deb13u1-Debian**.
- Android SDK platform **36 revision 2**, build-tools **36.0.0**, platform-tools **37.0.1**.
- Optional Android command-line tools **19.0** were downloaded; this template-based export does not invoke Gradle or sdkmanager.
- Optional graphical tests: Xvfb **21.1.16**, Mesa **25.0.7**, LLVM **19.1.7** software rendering.

The retained toolchain is `/workspace/.ascension`. Godot itself is `/usr/local/bin/godot` (binary under `/opt/godot/4.6.3`). The Java SDK is `/usr/lib/jvm/java-21-openjdk-amd64`.

## Existing cloud environment

```bash
cd /workspace/Ascension
./tools/build_android.sh
```

The helper checks/configures the toolchain, imports the project, exports the Android preset, verifies APK signing/alignment and records metadata, permissions and SHA-256 beside the APK. The preset uses non-Gradle templates, game category, portrait compatibility renderer, Android API 24 minimum / 36 target, ARMv7 + ARM64 + x86_64, and no permissions. Android texture import is explicitly enabled; without this Godot can report an empty configuration error.

The standard debug keystore is created by Godot under `$XDG_DATA_HOME/godot/keystores`, outside source. Debug keys are for testing. This is not a release/store signing configuration. Keep the debug key when rebuilding if you want Android to accept an update over an existing installation.

## Fresh machine

1. Install [Godot 4.6.3](https://github.com/godotengine/godot-builds/releases/tag/4.6.3-stable) and its matching export templates through the editor's template manager. Verify downloads against the release `SHA512-SUMS.txt`.
2. Install Java and Android Studio's SDK manager, or the official [Android command-line tools](https://developer.android.com/studio#command-tools). Install `platform-tools`, `build-tools;36.0.0` and `platforms;android-36`, reviewing the Android SDK licence when prompted.
3. Set the Java SDK and Android SDK paths in Godot's Editor Settings → Export → Android. This project's existing `export_presets.cfg` contains the Android preset.
4. Import `project.godot`, then run `godot --headless --path . --export-debug Android build/android/ASCENSION-debug.apk` after creating `build/android`.
5. Verify with the SDK's `apksigner verify --verbose --print-certs`, `zipalign -c -P 16 4`, and `aapt dump badging` / `aapt dump permissions`.

On this host Java's sdkmanager could not fetch remote manifests. The equivalent official package archives were downloaded using curl over HTTPS, matched to SHA-1 checksums in Google's `repository2-3.xml`, and extracted locally. The Godot templates were checked against the official SHA-512 release manifest. Neither TLS nor checksum verification was disabled. No Gradle dependency mirror is needed.

## Install

```bash
adb install -r build/android/ASCENSION-debug.apk
adb shell monkey -p org.ascensiongame.chapterone -c android.intent.category.LAUNCHER 1
```

The launcher is an exported MAIN/LAUNCHER activity alias. Some versions of `aapt dump badging` omit a `launchable-activity` line for an alias; `aapt dump xmltree ... AndroidManifest.xml` shows it correctly.

An existing installation signed with a different debug key cannot be updated with `-r`. Preserve its save data before intentionally replacing it. Build success and signature checks alone are not a physical-device playtest; see the development log for what was actually installed/run.
