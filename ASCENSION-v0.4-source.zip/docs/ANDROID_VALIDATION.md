# Current build: v0.2

See [v0.2 validation](VALIDATION_V02.md) for current results and [changelog](CHANGELOG_V02.md) for changes. The record below describes the superseded v0.1 build.

# Android APK handoff

Existing debug build reused; no application source changes or rebuild during resumed verification.

- APK: `build/android/ASCENSION-debug.apk`, 84,678,423 bytes, Android 7.0/API 24+, ARM64/ARMv7/x86_64.
- SHA-256: `c47abded214633d2c67d4d293835ade256793150e54ed61f0e99377977d61b78`.
- APK signature (v2/v3), 16 KiB ZIP alignment and checksum reverified successfully. No Android permissions requested.
- Engine smoke suite rerun: 128 assertions passed. Purchases, automated earnings, ranks, save/reload, bounded offline income and Legacy are covered.
- Rendered desktop pointer/UI suite rerun: passed at 420×820 and 360×800, including portrait layout, purchases, promotion, a decision, persistence and simulated pause/resume. Advanced progression uses explicit fixtures; Legacy reset itself is covered by engine assertions.
- Android 15 emulator: APK installed successfully. Launch starts a live app process; Android and Godot splash screens render on supported ANGLE/SwiftShader. Main game UI did not appear within bounded observation. Launcher ANR/Bluetooth failures were recorded; no new app fatal was observed in the captured startup window. This is not a successful Android gameplay smoke test.
- Unverified: actual Android gameplay, touch/scaling, complete Android progression/save/offline/Legacy, physical-device launch and performance.

Download the APK onto the phone, open it, and permit installation from that browser/file manager if Android prompts. Do not uninstall an existing copy to work around an update/signing error without preserving its save data. This is a debug test build, not a release-validated build.

See DEVELOPMENT_LOG.md and tests/results/android for detailed evidence.
