# v0.4 implementation record

Baseline: Godot 4.6.3, schema 2, seven working ranks, six institutions, fifteen upgrades, six contracts, three factions and Legacy. Existing source/APK copied to `.ascension/backups/v03-final`. Existing thresholds and package/signing identity remain.

Audit: enterprise multipliers and faction production traits already work. Business ownership does not scale contract capital or capacity; fixed contracts become negligible. No sector supply chain, operating margin, demand or ratified privilege exists. Prestige clears earned achievements. UI repeats tall cards; world art is a small noninteractive header.

Implement in the existing ledger/activity clock:
1. `economy.gd`: three sectors, bounded positive demand cycle, operating margin, ownership synergies, sector investment, three political privileges, safe delegation and permanent discoveries. Keep money in scientific-number bags.
2. Scale frozen contracts against actual enterprise capacity/income, with distinct civic/commercial routes. Paid repeats use safe passage; opt-in automation protects principal and cannot create debt.
3. Schema 3 migration preserves v0.3 active quotes, rank/assets/relationships and original-file backup. Prestige preserves achievements, discoveries and highest attained status; resets life-specific businesses/agreements.
4. A larger illustrated living district with contextual building controls and visible economic flow. Compact management/industry controls, actionable milestone requirements, advancement timeline and reduced motion.
5. Run retained regressions plus new cross-system integration/migration/large-number tests and strategy simulations. Test the installed Android APK and distinguish fixtures from earned play. Publish source, APK and evidence on the existing downloads branch.

Scope: deepen the seven-rank chapter first. No placeholder rank expansion. Future Tier 5 titles: Sovereign Ruler → Regional Overlord → Continental Unifier → Imperial Founder → Emperor → World Emperor.
