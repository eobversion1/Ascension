"""Continue an earned v0.3→v0.4 emulator save using actual rendered Android controls.
Requires the recorded Independent Trader checkpoint; no resources or ranks are injected.
"""
import subprocess,time
import android_qa_v04 as v
q=v.q

def run():
    s=q.document();assert s['rank']==3 and not s['activities']['negotiation']
    # Reproduce the old deep-scroll setup, then verify the corrected faction link.
    q.tap(130,783)
    for i in range(3):q.swipe(208,690,208,230)
    q.tap(290,783);time.sleep(3)
    for i in range(5):q.swipe(208,240,208,690)
    v.text_tap('Build merchants relations');time.sleep(3)
    q.capture('23-native-faction-link-corrected')
    visible=subprocess.check_output(['tesseract',str(q.OUT/'23-native-faction-link-corrected.png'),'stdout','--psm','11'],stderr=subprocess.DEVNULL).decode()
    assert 'Merchant League' in visible,visible
    v.text_tap('Open negotiations')
    s=q.wait_for(lambda d:bool(d['activities']['negotiation']),seconds=60)
    assert s['activities']['negotiation']['faction']=='merchants'
    for i in range(3):
        v.text_tap('Fund a concession',swipes=2)
        q.wait_for(lambda d:not d['activities']['negotiation'] or d['activities']['negotiation']['round']>=i+1,seconds=60)
    s=q.wait_for(lambda d:d['activities']['trust']['merchants']==2,seconds=60)
    q.record('24-native-merchant-accord',s)
    q.tap(290,783);time.sleep(3);v.text_tap('Ratify agreement',swipes=1)
    s=q.wait_for(lambda d:d['economy']['privileges'].get('open_passage'),seconds=60)
    assert s['economy']['discoveries'].get('integration')
    q.record('25-native-economic-privilege',s);q.capture('25-native-ratified-rights')
    # Requirement links open the correct productive asset, with no manual scroll reset.
    q.tap(370,783);v.text_tap('Reputation earned',swipes=1);v.text_tap('Invest',exact=True)
    s=q.wait_for(lambda d:d['generators'].get('rumour_network',0)>=1,seconds=60)
    q.record('26-native-sustainable-reputation',s)
    q.tap(370,783);v.text_tap('Trading post owned',swipes=1)
    for i in range(2):
        v.text_tap('Invest',exact=True)
        q.wait_for(lambda d:d['generators'].get('trading_post',0)>=i+1,seconds=60)
    q.tap(210,160)
    s=q.wait_for(lambda d:d['rank']==4,seconds=60);q.record('27-native-guildmaster',s);q.capture('27-native-guildmaster-ascension')
    q.continue_promotion();q.capture('28-native-guild-district')
    # The next milestone links directly to the influence-producing office.
    q.wait_for(lambda d:q.number(d['resources']['reputation'])>=75,seconds=240)
    q.tap(370,783);v.text_tap('Influence earned',swipes=1);v.text_tap('Invest',exact=True)
    s=q.wait_for(lambda d:d['generators'].get('campaign_office',0)>=1,seconds=60)
    q.record('29-native-sustainable-influence',s)
    q.shell('input keyevent 3');s=q.document();q.record('earned-progress-before-fixtures',s)
    q.start()
    s=q.wait_for(lambda d:d['saved_at']>s['saved_at']+.001,seconds=90)
    assert s['rank']==4 and s['economy']['privileges'].get('open_passage')
    q.record('30-native-save-resume',s)

if __name__=='__main__':run()
