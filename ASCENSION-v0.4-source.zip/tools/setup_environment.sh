#!/usr/bin/env bash
# Reuse the verified toolchain retained in the cloud environment snapshot.
set -euo pipefail
project_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
export ASCENSION_TOOLS_DIR="${ASCENSION_TOOLS_DIR:-$(dirname "$project_root")/.ascension}"
export XDG_DATA_HOME="${XDG_DATA_HOME:-$ASCENSION_TOOLS_DIR/data}"
export XDG_CONFIG_HOME="${XDG_CONFIG_HOME:-$ASCENSION_TOOLS_DIR/config}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-$ASCENSION_TOOLS_DIR/cache}"
mkdir -p "$XDG_DATA_HOME" "$XDG_CONFIG_HOME" "$XDG_CACHE_HOME"
command -v godot >/dev/null
command -v java >/dev/null
engine_version="$(godot --headless --version)"
if [[ "$engine_version" != 4.6.3.stable.* ]]; then
  echo "Expected Godot 4.6.3 stable matching this environment's export templates, found $engine_version" >&2
  exit 1
fi
for dependency in "$XDG_DATA_HOME/godot/export_templates/4.6.3.stable/android_debug.apk" "$ASCENSION_TOOLS_DIR/sdk/build-tools/36.0.0/apksigner" "$ASCENSION_TOOLS_DIR/sdk/platform-tools/adb"; do
  if [[ ! -f "$dependency" ]]; then
    echo "Missing $dependency. Follow docs/ANDROID_BUILD.md to install the toolchain." >&2
    exit 1
  fi
done
"$project_root/tools/godot.sh" --headless --path "$project_root" --editor --quit
export ASCENSION_JAVA_SDK="${ASCENSION_JAVA_SDK:-$(dirname "$(dirname "$(readlink -f "$(command -v java)")")")}"
python3 - <<'PY'
import os, pathlib, re
config = pathlib.Path(os.environ['XDG_CONFIG_HOME']) / 'godot/editor_settings-4.6.tres'
text = config.read_text()
settings = {
 'export/android/java_sdk_path': os.environ['ASCENSION_JAVA_SDK'],
 'export/android/android_sdk_path': os.environ['ASCENSION_TOOLS_DIR'] + '/sdk',
}
for key, value in settings.items():
 line = f'{key} = "{value}"'
 if re.search(r'^' + re.escape(key) + r' = .*$', text, flags=re.M):
  text = re.sub(r'^' + re.escape(key) + r' = .*$', lambda _: line, text, flags=re.M)
 else:
  text += '\n' + line + '\n'
key = "export/android/shutdown_adb_on_exit"
if re.search(r"^" + re.escape(key) + r" = .*$", text, flags=re.M):
 text = re.sub(r"^" + re.escape(key) + r" = .*$", key + " = false", text, flags=re.M)
else:
 text += "\n" + key + " = false\n"
config.write_text(text)
PY
printf 'ASCENSION toolchain ready: %s\n' "$engine_version"
