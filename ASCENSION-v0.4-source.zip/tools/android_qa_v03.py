"""Android v0.3 interaction evidence. Fixture injection is restricted to an emulator.
The helper never targets a physical device. All pre-injection states are backed up.
"""
import json,time,pathlib
import android_qa as q
q.OUT=q.ROOT/'tests/results/android-v03'
q.OUT.mkdir(parents=True,exist_ok=True)

def fixture(name):
    assert q.SERIAL.startswith('emulator-')
    q.shell('input keyevent 3');time.sleep(1)
    previous=q.document();(q.OUT/('before-'+name+'.json')).write_text(json.dumps(previous,indent=2))
    data=json.loads((q.ROOT/'tests/results/v03'/('fixture-'+name+'.json')).read_text())
    data['saved_at']=float(q.shell('date +%s').strip())-(86400 if name=='offline' else 0)
    data['qa_fixture_nonce']=str(time.monotonic_ns())
    local=q.OUT/('injected-'+name+'.json');local.write_text(json.dumps(data))
    remote='/data/local/tmp/ascension-v03-'+name+'.json'
    q.adb('push',str(local),remote);q.shell('chmod 644 '+remote)
    q.shell('run-as '+q.PKG+' cp '+remote+' files/ascension_save.json');q.shell('rm '+remote)
    q.start()
    state=q.wait_for(lambda d:d.get('app_version')=='0.3.0' and d.get('qa_fixture_nonce')==data['qa_fixture_nonce'] and d['saved_at']>data['saved_at']+0.001,seconds=180)
    print('FIXTURE LOADED',name,flush=True)
    return state

def offline_scenario():
    """A marked Android fixture: one opted-in clerk, no generators, 24h absent."""
    s=fixture('offline')
    count=int(s['activities']['completed'])
    assert 720 <= count <= 730, (count, 'Expected capped eight-hour/75% catch-up')
    assert abs(q.number(s['resources']['coins'])-(9982+12*count))<0.01
    assert abs(q.number(s['activities']['profits'])-12*count)<0.01
    assert len(s['activities']['orders'])==1 and s['activities']['orders'][0]['repeat']
    q.record('native-offline-paid-repeats-capped',s)
    q.capture('26-native-offline-automation')
    q.shell('input keyevent 3')
    previous=q.document()
    q.start()
    again=q.wait_for(lambda d:d['saved_at']>previous['saved_at']+0.001,seconds=90)
    assert count <= int(again['activities']['completed']) < count+10
    q.record('native-offline-resume-no-duplicate-cap',again)

def restore_natural_progress():
    """Restore earned progress after destructive emulator-only scenarios."""
    assert q.SERIAL.startswith('emulator-')
    q.shell('input keyevent 3')
    q.record('before-restoring-natural-progress',q.document())
    source=q.OUT/'before-trader.json'
    data=json.loads(source.read_text())
    data.pop('qa_fixture_nonce',None)
    data['saved_at']=float(q.shell('date +%s').strip())
    data['qa_restore_nonce']=str(time.monotonic_ns())
    local=q.OUT/'restored-natural-progress.json';local.write_text(json.dumps(data,indent=2))
    remote='/data/local/tmp/ascension-v03-natural.json'
    q.adb('push',str(local),remote);q.shell('chmod 644 '+remote)
    q.shell('run-as '+q.PKG+' cp '+remote+' files/ascension_save.json');q.shell('rm '+remote)
    q.start()
    s=q.wait_for(lambda d:d.get('qa_restore_nonce')==data['qa_restore_nonce'] and d['saved_at']>data['saved_at']+0.001,seconds=90)
    assert s['rank']==data['rank'] and s['legacy_points']==data['legacy_points']
    assert s['activities']['trust']==data['activities']['trust']
    q.record('natural-progress-restored-after-fixtures',s)
    q.tap(50,785);q.capture('30-native-final-restored-game')

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('stage',choices=['offline','restore'])
    args=parser.parse_args()
    (offline_scenario if args.stage=='offline' else restore_natural_progress)()
