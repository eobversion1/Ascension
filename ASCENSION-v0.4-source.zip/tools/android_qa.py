"""Fixture-assisted Android QA on a test emulator only; never targets a physical phone.
Use --stage fresh/reported/trader/legacy/offline. All injected saves are explicitly named.
Backups and per-step evidence stay under tests/results/android-v02 and .ascension/backups.
"""
import json, subprocess, time, pathlib, argparse
ROOT=pathlib.Path(__file__).resolve().parents[1]
ADB=ROOT.parent/'.ascension/sdk/platform-tools/adb'
OUT=ROOT/'tests/results/android-v02'
PKG='org.ascensiongame.chapterone'
SERIAL='emulator-5554'

def adb(*args, data=None, limit=30):
    result=subprocess.run([str(ADB),'-s',SERIAL,*args],input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=limit)
    if result.returncode: raise RuntimeError(result.stderr.decode(errors='replace')[-1500:])
    return result.stdout

def shell(command,limit=30): return adb('shell',command,limit=limit).decode(errors='replace')
def capture(name):
    data=adb('exec-out','screencap','-p')
    assert data.startswith(b'\x89PNG'), 'Invalid Android screenshot'
    (OUT/(name+'.png')).write_bytes(data)
    print('SCREENSHOT',name,flush=True)

def document(): return json.loads(adb('exec-out','run-as',PKG,'cat','files/ascension_save.json'))
def number(value): return float(value['m'])*10**int(value['e'])
def wait_for(predicate,seconds=45):
    until=time.monotonic()+seconds
    last=None
    while time.monotonic()<until:
        last=document()
        if predicate(last): return last
        time.sleep(.5)
    raise AssertionError('Device state did not reach expected condition; rank='+str(last.get('rank')))
def record(name,state):
    (OUT/(name+'.json')).write_text(json.dumps(state,indent=2))
    print('PASS',name,'rank',state['rank'],flush=True)
def tap(x,y,count=1):
    # Only integer test coordinates enter the device shell command.
    command='; '.join('input tap %d %d'%(int(x),int(y)) for _ in range(count))
    shell(command,limit=55)
def swipe(x1,y1,x2,y2): shell('input swipe %d %d %d %d 600'%(x1,y1,x2,y2))
def start(): shell('am start -n '+PKG+'/com.godot.game.GodotAppLauncher')
def fixture(name):
    assert SERIAL.startswith('emulator-'), 'Fixtures are prohibited on physical devices'
    shell('input keyevent 3')
    time.sleep(1)
    previous=document()
    (OUT/('before-'+name+'.json')).write_text(json.dumps(previous,indent=2))
    source=ROOT/'tests/results/v02'/('fixture-'+name+'.json')
    data=source.read_bytes()
    # Prevent weeks of unintended accrual if fixtures are reused in a later task.
    content=json.loads(data)
    content['saved_at']=float(shell('date +%s').strip())-(86400 if name=='offline' else 0)
    content['qa_fixture_nonce']=str(time.monotonic_ns())
    prepared=OUT/('injected-'+name+'.json')
    prepared.write_text(json.dumps(content))
    remote='/data/local/tmp/ascension-v02-'+name+'.json'
    adb('push',str(prepared),remote)
    shell('chmod 644 '+remote)
    shell('run-as '+PKG+' cp '+remote+' files/ascension_save.json')
    shell('rm '+remote)
    start()
    state=wait_for(lambda d: d.get('qa_fixture_nonce')==content['qa_fixture_nonce'] and d.get('app_version')=='0.2.0' and d['rank']==content['rank'] and d['saved_at']>content['saved_at']+0.001,seconds=180)
    print('FIXTURE LOADED',name,flush=True)
    return state

def continue_promotion():
    from PIL import Image
    capture('continue-target')
    image=Image.open(OUT/'continue-target.png').convert('RGB')
    bands=[]
    for y in range(image.height):
        count=sum(1 for x in range(image.width) if (lambda c:c[0]>150 and c[1]>120 and 50<c[2]<195 and c[0]>c[1])(image.getpixel((x,y))))
        if count>image.width*.65:bands.append(y)
    assert bands, 'Visible gold Continue target not found'
    # Reject one-pixel gold panel borders; merge the fill strips around button text.
    runs=[]
    for row in bands:
        if not runs or row-runs[-1][-1]>1:runs.append([row])
        else:runs[-1].append(row)
    fills=[run for run in runs if len(run)>=5]
    groups=[]
    for run in fills:
        if not groups or run[0]-groups[-1][-1]>25:groups.append(run[:])
        else:groups[-1].extend(run)
    buttons=[g for g in groups if 30<=g[-1]-g[0]<=100]
    assert buttons, 'No finger-sized gold Continue button found'
    target=buttons[-1]
    tap(image.width//2,(target[0]+target[-1])//2)
    time.sleep(1)

def run(stage):
    OUT.mkdir(parents=True,exist_ok=True)
    if stage=='fresh':
        initial=document()
        assert initial['rank']==0 and initial['generators'].get('street_stall',0)==0, 'Fresh stage requires a fresh test save'
        assert number(initial['resources']['coins'])<1
        record('initial-save',initial)
        tap(210,410,15)
        tap(210,628)
        state=wait_for(lambda d:d['generators'].get('street_stall',0)==1)
        record('fresh-stall-purchase',state)
        capture('03-stall-purchased')
        # Earn the exact original gate using input; do not adjust rank requirements.
        tap(210,410,15)
        tap(210,185,2)
        state=wait_for(lambda d:d['rank']==1)
        record('fresh-first-promotion',state)
        capture('04-first-ascension')
        continue_promotion()
        tap(210,185)
        capture('05-ineligible-next-rank')
        assert document()['rank']==1
    elif stage=='reported':
        fixture('reported')
        capture('06-reported-ready')
        tap(210,185,2)
        state=wait_for(lambda d:d['rank']==1)
        record('reported-promotion-single-tap-guard',state)
        assert state['generators']['street_stall']==20
        capture('07-reported-promoted')
        continue_promotion()
    elif stage=='trader':
        fixture('trader')
        capture('08-trader-empire')
    elif stage=='legacy':
        fixture('legacy')
        tap(210,185)
        capture('legacy-confirmation')
    elif stage=='offline':
        fixture('offline')
        state=document()
        coins=number(state['resources']['coins'])
        assert 6927<=coins<6970, '8h at75% plus bounded live frames expected, got '+str(coins)
        record('offline-capped-on-android',state)
        capture('offline-reward')
    elif stage=='capture': capture('current')
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--device',default='emulator-5554')
    parser.add_argument('--stage',choices=['fresh','reported','trader','legacy','offline','capture'],required=True)
    args=parser.parse_args()
    SERIAL=args.device
    if not SERIAL.startswith('emulator-'): raise SystemExit('QA input/fixtures may only target an emulator')
    run(args.stage)
