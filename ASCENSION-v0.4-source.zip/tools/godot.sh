#!/usr/bin/env bash
set -euo pipefail
project_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
export ASCENSION_TOOLS_DIR="${ASCENSION_TOOLS_DIR:-$(dirname "$project_root")/.ascension}"
export XDG_DATA_HOME="${XDG_DATA_HOME:-$ASCENSION_TOOLS_DIR/data}"
export XDG_CONFIG_HOME="${XDG_CONFIG_HOME:-$ASCENSION_TOOLS_DIR/config}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-$ASCENSION_TOOLS_DIR/cache}"
mkdir -p "$XDG_DATA_HOME" "$XDG_CONFIG_HOME" "$XDG_CACHE_HOME"
exec godot "$@"
