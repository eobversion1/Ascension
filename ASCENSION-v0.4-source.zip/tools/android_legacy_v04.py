"""Fixture-assisted native stewardship, layout and hybrid Legacy verification."""
import time
import android_qa_v04 as v
q=v.q

def top():
    for i in range(5):q.swipe(208,240,208,690)

def run():
    s=v.fixture('legacy');assert s['rank']==6 and s['legacy_points']==2
    initial=sum(s['economy']['sectors'].values())
    q.tap(50,783);time.sleep(3);top();v.text_tap('Sectors',exact=True)
    v.text_tap('Steward: OFF',swipes=6)
    q.wait_for(lambda d:d['economy']['steward'],seconds=60)
    q.record('32-native-steward-enabled',q.document());q.capture('32-native-estate-steward')
    top();v.text_tap('District',exact=True)
    q.shell('wm size 360x800');time.sleep(3);q.capture('33-native-narrow-district')
    v.text_tap('Upgrades',exact=True);before=q.document()['upgrades']
    for i in range(12):q.swipe(180,690,180,230)
    q.capture('34-native-narrow-long-upgrades')
    assert q.document()['upgrades']==before,'Scrolling must not purchase an upgrade'
    q.shell('wm size 420x1000');time.sleep(3)
    v.text_tap('Empire',exact=True);top();q.capture('35-native-tall-district')
    q.shell('wm size 420x820');time.sleep(3)
    s=q.wait_for(lambda d:sum(d['economy']['sectors'].values())>initial,seconds=180)
    q.record('36-native-steward-invested',s)
    # Preferences and permanent status must survive prestige, along with discoveries.
    q.tap(380,38);time.sleep(2);v.text_tap('Reduced motion: OFF',swipes=1)
    q.wait_for(lambda d:d['settings']['reduced_motion'],seconds=60)
    q.tap(370,783);time.sleep(3)
    # A page may have a remembered timeline position; deliberately scroll to its action.
    top();q.tap(210,160);time.sleep(3);q.capture('37-native-legacy-confirmation')
    before=q.document();q.tap(270,487)
    s=q.wait_for(lambda d:d['rank']==0 and d['legacy_points']==3,seconds=90)
    assert s['settings']['reduced_motion'] and s['economy']['highest_rank']==6
    assert set(before['achievements'])<=set(s['achievements'])
    assert set(before['economy']['discoveries'])<=set(s['economy']['discoveries'])
    assert not s['economy']['privileges'] and sum(s['economy']['sectors'].values())==0
    assert not s['activities']['orders'] and not s['activities']['negotiation']
    assert sum(s['activities']['trust'].values())==0
    q.record('38-native-hybrid-legacy',s);q.capture('38-native-survival-after-legacy')

if __name__=='__main__':run()
