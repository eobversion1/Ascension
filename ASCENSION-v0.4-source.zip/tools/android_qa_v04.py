"""Native touch QA helpers. Explicit fixtures target the emulator only, with backups."""
import json,time
import android_qa as q
q.OUT=q.ROOT/'tests/results/android-v04'
q.OUT.mkdir(parents=True,exist_ok=True)

def fixture(name):
    assert q.SERIAL.startswith('emulator-')
    q.shell('input keyevent 3');time.sleep(1)
    q.record('before-'+name,q.document())
    data=json.loads((q.ROOT/'tests/results/v04'/('fixture-'+name+'.json')).read_text())
    return inject(data,name,86400 if name=='offline' else 0)

def inject(data,name,absence=0):
    assert q.SERIAL.startswith('emulator-')
    data['saved_at']=float(q.shell('date +%s').strip())-absence
    data['qa_fixture_nonce']=str(time.monotonic_ns())
    local=q.OUT/('injected-'+name+'.json');local.write_text(json.dumps(data))
    remote='/data/local/tmp/ascension-v04-qa.json'
    q.adb('push',str(local),remote);q.shell('chmod 644 '+remote)
    q.shell('run-as '+q.PKG+' cp '+remote+' files/ascension_save.json');q.shell('rm '+remote)
    q.start()
    s=q.wait_for(lambda d:d.get('app_version')=='0.4.0' and d.get('qa_fixture_nonce')==data['qa_fixture_nonce'] and d['saved_at']>data['saved_at']+.001,seconds=180)
    q.record('loaded-'+name,s)
    return s

def offline():
    s=fixture('offline')
    expected=json.loads((q.ROOT/'tests/results/v04/fixture-offline-expected.json').read_text())
    count=int(s['activities']['completed']);base=int(expected['activities']['completed'])
    assert base==720 and base<=count<=725,(base,count)
    # Save is written immediately on load. If device interaction consumes a journey,
    # subsequent extra earnings are bounded by the known 20-coin maximum per trip.
    for actual,wanted in [(s['resources']['coins'],expected['resources']['coins']),(s['activities']['profits'],expected['activities']['profits'])]:
        delta=q.number(actual)-q.number(wanted)
        assert -.01<=delta<=20*(count-base)+.01,delta
    assert s['economy']['discoveries'].get('exchange')
    assert len(s['activities']['orders'])==1 and s['activities']['orders'][0]['repeat']
    q.record('offline-engine-oracle-matched',s)
    q.tap(130,783);time.sleep(3)
    for i in range(4):q.swipe(208,240,208,690)
    text_tap('Trade desk');q.capture('31-native-offline-automation')
    q.shell('input keyevent 3');previous=q.document();q.start()
    again=q.wait_for(lambda d:d['saved_at']>previous['saved_at']+.001,seconds=90)
    assert count<=int(again['activities']['completed'])<count+10
    q.record('offline-resume-no-duplicate',again)


def text_tap(label,swipes=0,exact=False):
    """Locate a rendered label by OCR and send a real Android touch; no game hooks."""
    import subprocess,csv,io
    for attempt in range(swipes+1):
        time.sleep(3)
        q.capture('interaction-target')
        tsv=subprocess.check_output(['tesseract',str(q.OUT/'interaction-target.png'),'stdout','--psm','11','tsv'],stderr=subprocess.DEVNULL).decode()
        groups={}
        for row in csv.DictReader(io.StringIO(tsv),delimiter='\t'):
            if not row.get('text','').strip():continue
            key=tuple(row[k] for k in ['page_num','block_num','par_num','line_num'])
            groups.setdefault(key,[]).append(row)
        for words in groups.values():
            text=' '.join(w['text'] for w in words)
            if (text.casefold()!=label.casefold()) if exact else (label.casefold() not in text.casefold()):continue
            x=min(int(w['left']) for w in words);y=min(int(w['top']) for w in words)
            right=max(int(w['left'])+int(w['width']) for w in words);bottom=max(int(w['top'])+int(w['height']) for w in words)
            q.tap((x+right)//2,(y+bottom)//2)
            print('TOUCH',label,flush=True);time.sleep(1)
            return
        if attempt<swipes:
            import shutil
            shutil.copyfile(q.OUT/'interaction-target.png',q.OUT/('qa-ocr-miss-'+str(time.monotonic_ns())+'.png'))
            q.swipe(208,690,208,240)
    raise AssertionError('Rendered control not found: '+label)

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['offline','legacy','restore']);args=parser.parse_args()
    if args.stage=='offline':offline()
    elif args.stage=='legacy':fixture('legacy')
    else:
        q.shell('input keyevent 3');q.record('before-restore',q.document())
        data=json.loads((q.OUT/'earned-progress-before-fixtures.json').read_text())
        data.pop('qa_fixture_nonce',None)
        s=inject(data,'restored-earned')
        assert s['rank']==data['rank'] and s['legacy_points']==data['legacy_points']
        assert s['economy']['privileges']==data['economy']['privileges']
        q.record('earned-progress-restored',s)
