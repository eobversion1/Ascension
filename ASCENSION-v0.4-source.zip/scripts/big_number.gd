## Scientific-form positive-only BigNumber for idle economy (mantissa 1 <= m < 10; exponent integer).
## Keeps values far above IEEE-754's usual max. Does not promise arbitrary decimal precision.
class_name AscensionNumber
extends RefCounted

const MAX_EXPONENT: int = 1000000000

static func zero() -> Dictionary:
	return {"m": 0.0, "e": 0}

static func one() -> Dictionary:
	return {"m": 1.0, "e": 0}

static func normalized(m: float, e: int = 0) -> Dictionary:
	if is_nan(m) or is_inf(m) or m <= 0.0:
		return zero()
	m = maxf(m, 0.0)
	while m >= 10.0:
		m /= 10.0
		e += 1
	while m < 1.0:
		m *= 10.0
		e -= 1
	if absf(m - 10.0) < 1.0e-10:
		m = 1.0
		e += 1
	if e < -MAX_EXPONENT:
		return zero()
	if e > MAX_EXPONENT:
		return {"m": 9.999999, "e": MAX_EXPONENT}
	return {"m": m, "e": e}

static func of(value: float) -> Dictionary:
	return normalized(value)

static func valid(v: Variant) -> bool:
	if not (v is Dictionary):
		return false
	if not v.has("m") or not v.has("e"):
		return false
	if not (v["m"] is float or v["m"] is int):
		return false
	if not (v["e"] is float or v["e"] is int):
		return false
	return not is_nan(float(v["m"])) and not is_inf(float(v["m"])) and float(v["m"]) >= 0.0 and is_finite(float(v["e"])) and float(v["e"]) == floor(float(v["e"])) and absf(float(v["e"])) <= float(MAX_EXPONENT)

static func sanitize(v: Variant) -> Dictionary:
	if not valid(v):
		return zero()
	return normalized(float(v["m"]), int(v["e"]))

static func compare(a: Dictionary, b: Dictionary) -> int:
	var am: float = float(a.get("m", 0.0))
	var bm: float = float(b.get("m", 0.0))
	if am == 0.0 and bm == 0.0:
		return 0
	if am == 0.0:
		return -1
	if bm == 0.0:
		return 1
	var ae: int = int(a.get("e", 0))
	var be: int = int(b.get("e", 0))
	if ae != be:
		return 1 if ae > be else -1
	if absf(am - bm) <= 1.0e-12 * maxf(am, bm):
		return 0
	return 1 if am > bm else -1

static func add(a: Dictionary, b: Dictionary) -> Dictionary:
	if float(a.get("m", 0.0)) == 0.0:
		return b.duplicate(true)
	if float(b.get("m", 0.0)) == 0.0:
		return a.duplicate(true)
	var ae: int = int(a["e"])
	var be: int = int(b["e"])
	if ae - be > 16:
		return a.duplicate(true)
	if be - ae > 16:
		return b.duplicate(true)
	if ae >= be:
		return normalized(float(a["m"]) + float(b["m"]) * pow(10.0, float(be - ae)), ae)
	return normalized(float(b["m"]) + float(a["m"]) * pow(10.0, float(ae - be)), be)

static func subtract(a: Dictionary, b: Dictionary) -> Dictionary:
	if compare(a, b) <= 0:
		return zero()
	if float(b.get("m", 0.0)) == 0.0:
		return a.duplicate(true)
	var ae: int = int(a["e"])
	var be: int = int(b["e"])
	if ae - be > 16:
		return a.duplicate(true)
	return normalized(float(a["m"]) - float(b["m"]) * pow(10.0, float(be - ae)), ae)

static func multiply(a: Dictionary, b: Dictionary) -> Dictionary:
	if float(a.get("m", 0.0)) == 0.0 or float(b.get("m", 0.0)) == 0.0:
		return zero()
	return normalized(float(a["m"]) * float(b["m"]), int(a["e"]) + int(b["e"]))

static func times(a: Dictionary, factor: float) -> Dictionary:
	if factor <= 0.0 or is_nan(factor) or is_inf(factor):
		return zero()
	return multiply(a, of(factor))

static func power_price(base: float, growth: float, owned: int) -> Dictionary:
	if not is_finite(base) or not is_finite(growth) or base <= 0.0 or growth < 1.0 or owned < 0:
		return zero()
	if owned == 0:
		return of(base)
	var log10_value: float = log(base) / log(10.0) + float(owned) * log(growth) / log(10.0)
	if log10_value >= float(MAX_EXPONENT):
		return {"m": 9.999999, "e": MAX_EXPONENT}
	var exponent: int = int(floor(log10_value))
	return normalized(pow(10.0, log10_value - float(exponent)), exponent)

static func ratio_capped(part: Dictionary, whole: Dictionary) -> float:
	if compare(whole, zero()) <= 0:
		return 1.0
	if compare(part, whole) >= 0:
		return 1.0
	var diff: int = int(part["e"]) - int(whole["e"])
	if diff < -12:
		return 0.0
	return clampf(float(part["m"]) / float(whole["m"]) * pow(10.0, float(diff)), 0.0, 1.0)

static func pretty(a: Dictionary) -> String:
	var m: float = float(a.get("m", 0.0))
	if m <= 0.0:
		return "0"
	var e: int = int(a.get("e", 0))
	if e < 3:
		var small: float = m * pow(10.0, float(e))
		return "%.2f" % small if small < 100.0 else "%.0f" % small
	var suffixes: Array[String] = ["", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc"]
	var group: int = int(floor(float(e) / 3.0))
	if group >= suffixes.size():
		return "%.3fe%d" % [m, e]
	return "%.2f%s" % [m * pow(10.0, float(e - group * 3)), suffixes[group]]
