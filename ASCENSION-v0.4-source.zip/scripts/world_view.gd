## Illustrated district with ownership-linked building controls and supply-flow feedback.
extends Control
signal business_selected(id: String)
const E=preload("res://scripts/economy.gd")
const ART=preload("res://assets/world/living-districts.png")
const PINS=[
 {"id":"workshop","title":"Craft","icon":"work","pos":Vector2(0.19,0.32),"rank":2},
 {"id":"street_stall","title":"Market","icon":"market","pos":Vector2(0.45,0.72),"rank":0},
 {"id":"trading_post","title":"Trade","icon":"routes","pos":Vector2(0.81,0.54),"rank":3},
 {"id":"campaign_office","title":"Council","icon":"citadel","pos":Vector2(0.62,0.13),"rank":4}
]
var game
var time: float=0.0
var pins: Array[Button]=[]
var texture: AtlasTexture
func _ready() -> void:
 set_process(game != null and not game.state["settings"]["reduced_motion"])
func configure(g) -> void:
 game=g
 name="LivingDistrict"
 custom_minimum_size.y=280
 mouse_filter=Control.MOUSE_FILTER_PASS
 clip_contents=true
 var era: int=0 if g.rank()<2 else 1 if g.rank()<4 else 2 if g.rank()<5 else 3
 texture=AtlasTexture.new();texture.atlas=ART
 var side: float=float(ART.get_width())/2.0
 texture.region=Rect2((era%2)*side,(era/2)*side,side,side)
 for p in PINS:
  if g.rank()<int(p["rank"]):continue
  var button:=Button.new()
  button.name="World_"+p["id"]
  button.text=p["title"]+" · "+str(g.own(p["id"]))
  button.tooltip_text="Manage "+p["id"].replace("_"," ")
  button.mouse_filter=Control.MOUSE_FILTER_PASS
  button.add_theme_font_size_override("font_size",12)
  var style:=StyleBoxFlat.new();style.bg_color=Color(0.04,0.07,0.10,0.90)
  style.border_color=Color("#d8b976") if g.own(p["id"])>0 else Color("#72849b")
  style.set_border_width_all(1);style.set_corner_radius_all(8)
  button.add_theme_stylebox_override("normal",style)
  button.icon=load("res://assets/icons/"+p["icon"]+".svg")
  button.expand_icon=true;button.add_theme_constant_override("icon_max_width",18)
  button.set_meta("pin",p)
  button.pressed.connect(func():business_selected.emit(p["id"]),CONNECT_DEFERRED)
  add_child(button);pins.append(button)
 resized.connect(_position_pins)
 _position_pins()
 set_process(not g.state["settings"]["reduced_motion"])
func _position_pins() -> void:
 for b in pins:
  var p: Dictionary=b.get_meta("pin")
  b.size=Vector2(96,48)
  b.position=Vector2(clampf(size.x*p["pos"].x-48,4,maxf(4,size.x-100)),clampf(size.y*p["pos"].y-24,8,size.y-56))
 queue_redraw()
func _process(delta: float) -> void:
 time+=delta;queue_redraw()
func _draw() -> void:
 if texture==null:return
 var side: float=texture.get_width()
 var h: float=side*size.y/maxf(1,size.x)
 draw_texture_rect_region(texture,Rect2(Vector2.ZERO,size),Rect2(0,maxf(0,(side-h)/2.0),side,minf(side,h)))
 draw_rect(Rect2(0,0,size.x,22),Color(0.03,0.05,0.09,0.52))
 for pair in [["workshop","street_stall"],["street_stall","trading_post"],["trading_post","campaign_office"]]:
  if game.own(pair[0])<1 or game.own(pair[1])<1:continue
  var a: Vector2=Vector2.ZERO;var b: Vector2=Vector2.ZERO
  for button in pins:
   var id: String=button.get_meta("pin")["id"]
   if id==pair[0]:a=button.position+button.size/2
   if id==pair[1]:b=button.position+button.size/2
  if a==Vector2.ZERO or b==Vector2.ZERO:continue
  draw_line(a,b,Color(0.94,0.75,0.38,0.45),1.5,true)
  var phase: float=0.5 if game.state["settings"]["reduced_motion"] else fmod(time*0.24,1.0)
  draw_circle(a.lerp(b,phase),3.0,Color("#ffe3a6"))
