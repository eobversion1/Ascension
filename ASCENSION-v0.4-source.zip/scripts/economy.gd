## Living economy: derived enterprise economics, finite opportunity clock and persistent discoveries.
## Operating expenses are withheld from revenue, never debited from the player's wallet.
class_name AscensionEconomy
extends RefCounted
const DATA=preload("res://scripts/content.gd")
const BN = preload("res://scripts/big_number.gd")
const SECTORS = [
 {"id":"retail","name":"Street commerce","business":"street_stall","rank":2,"price":350.0,"link":"Workshops supply the stalls; each adds 2.5% sales, up to 50%."},
 {"id":"craft","name":"Craft & industry","business":"workshop","rank":2,"price":900.0,"link":"Trading Posts widen the market; each adds 3% sales, up to 60%."},
 {"id":"commerce","name":"Merchant logistics","business":"trading_post","rank":3,"price":4500.0,"link":"Stalls and Workshops feed trade; each adds 1.5% sales, up to 60%."}
]
const PRIVILEGES = [
 {"id":"open_passage","name":"Open Passage","faction":"merchants","rank":3,"cost":{"coins":2500.0,"reputation":20.0},"effect":"10% cheaper business investment and contract capital; +15% contract profit."},
 {"id":"public_supply","name":"Public Supply Accord","faction":"commons","rank":3,"cost":{"coins":2000.0,"reputation":25.0},"effect":"Operating costs fall by 3 percentage points; +25% contract reputation."},
 {"id":"city_charter","name":"City Trading Charter","faction":"council","rank":4,"cost":{"coins":8000.0,"reputation":75.0,"influence":5.0},"effect":"+15% sector sales, +20% contract profit and access to 20-lot shipments."}
]
const DISCOVERIES = [
 {"id":"livelihood","name":"A lasting livelihood","hint":"Reach Scavenger and own three Stalls."},
 {"id":"craftsmanship","name":"The power of craft","hint":"Own a Workshop."},
 {"id":"exchange","name":"A wider exchange","hint":"Complete three contracts."},
 {"id":"diplomacy","name":"The value of a promise","hint":"Reach trust 2 with a faction."},
 {"id":"institutions","name":"Institutions endure","hint":"Own a Campaign Office."},
 {"id":"integration","name":"A living economy","hint":"Ratify a privilege and invest in a sector."},
 {"id":"legacy","name":"Beyond one lifetime","hint":"Begin a new Legacy."}
]
const PHASE_SECONDS: float = 120.0
static func fresh() -> Dictionary:
 return {"clock":0.0,"sectors":{"retail":0,"craft":0,"commerce":0},"privileges":{},"discoveries":{},"highest_rank":0,"steward":false,"focus":"balanced"}
static func sector_for(id: String) -> String:
 for s in SECTORS:
  if s["business"]==id:return s["id"]
 return ""
static func has(g,id: String) -> bool:return g.state["economy"]["privileges"].has(id)
static func phase(g) -> int:return int(float(g.state["economy"]["clock"])/PHASE_SECONDS)%3
static func next_boundary(g) -> float:return PHASE_SECONDS-fmod(float(g.state["economy"]["clock"]),PHASE_SECONDS)
static func market_title(g) -> String:return ["Market day", "Builders' season", "Caravan arrivals"][phase(g)]
static func demand(g,sector: String) -> float:
 if g.rank()<2:return 1.0
 return 1.20 if sector==SECTORS[phase(g)]["id"] else 1.0
static func capital_discount(g) -> float:return 0.90 if has(g,"open_passage") else 1.0
static func capacity(g) -> int:
 var units: float=1+g.own("street_stall")+4*g.own("workshop")+8*g.own("trading_post")
 for level in g.state["economy"]["sectors"].values():units+=4*int(level)
 return int(units*g.modifier("capacity"))
static func cost_fraction(g) -> float:
 var ratio: float=0.25
 if g.state["upgrades"].has("better_suppliers"):ratio-=0.04
 if g.state["upgrades"].has("trained_staff"):ratio-=0.04
 if has(g,"public_supply"):ratio-=0.03
 return maxf(0.10,ratio)
static func sector_factor(g,sector: String, count: int) -> float:
 var synergy: float=1.0
 if sector=="retail":synergy+=0.025*mini(20,g.own("workshop"))
 elif sector=="craft":synergy+=0.03*mini(20,g.own("trading_post"))
 elif sector=="commerce":synergy+=0.015*mini(40,g.own("street_stall")+g.own("workshop"))
 var milestones: float=1.0
 for threshold in [10,25,50]:
  if count>=threshold:milestones*=1.25
 var level: int=int(g.state["economy"]["sectors"].get(sector,0))
 return synergy*milestones*pow(1.30,level)*g.modifier("sector_"+sector)*(1.15 if has(g,"city_charter") else 1.0)
static func business_factor(g,id: String) -> float:
 var sector: String=sector_for(id)
 if sector.is_empty():return 1.0
 return sector_factor(g,sector,g.own(id))*demand(g,sector)*(1.0-cost_fraction(g))/0.75
static func business_profile(g,gen: Dictionary) -> Dictionary:
 var sector: String=sector_for(gen["id"])
 if sector.is_empty():return {}
 var base: Dictionary=g.generator_base_output(gen)["coins"]
 var revenue: Dictionary=BN.times(base,sector_factor(g,sector,g.own(gen["id"]))*demand(g,sector)/0.75)
 var expense: Dictionary=BN.times(revenue,cost_fraction(g))
 return {"sector":sector,"revenue":revenue,"cost":expense,"net":BN.subtract(revenue,expense),"margin":1.0-cost_fraction(g),"demand":demand(g,sector)}
static func sector_cost(g,id: String) -> Dictionary:
 for s in SECTORS:
  if s["id"]==id:return {"coins":BN.times(BN.power_price(s["price"],3.0,int(g.state["economy"]["sectors"][id])),capital_discount(g))}
 return {}
static func invest(g,id: String) -> bool:
 if g.state["paused"] or g.persistence_blocked:return false
 for s in SECTORS:
  if s["id"]!=id:continue
  if g.rank()<int(s["rank"]) or g.own(s["business"])<1 or int(g.state["economy"]["sectors"][id])>=4:return false
  if not g._pay(sector_cost(g,id)):return false
  g.state["economy"]["sectors"][id]+=1
  g.add_log("Expanded "+s["name"]+": ×1.30 sector sales and ×1.15 contract profit.")
  discover(g);return true
 return false
static func privilege_ready(g,p: Dictionary) -> bool:
 return g.rank()>=int(p["rank"]) and int(g.state["activities"]["trust"][p["faction"]])>=2 and not has(g,p["id"])
static func ratify(g,id: String) -> bool:
 if g.state["paused"] or g.persistence_blocked:return false
 for p in PRIVILEGES:
  if p["id"]==id and privilege_ready(g,p) and g._pay(g._fixed_cost(p["cost"])):
   g.state["economy"]["privileges"][id]=true;g.add_log("Ratified "+p["name"]+". "+p["effect"]);discover(g);return true
 return false
static func contract_sector(id: String) -> String:
 return "retail" if id in ["salvage","provisions"] else "craft" if id in ["relief","charter"] else "commerce"
static func contract_factor(g,id: String) -> float:
 var sector: String=contract_sector(id)
 var business: String="street_stall" if sector=="retail" else "workshop" if sector=="craft" else "trading_post"
 var link: float=1.0+minf(0.40,float(capacity(g)-1)*0.005)
 return link*sqrt(g.modifier("gen_"+business))*pow(1.15,int(g.state["economy"]["sectors"][sector]))*g.modifier("contract_efficiency")*demand(g,sector)*(1.15 if has(g,"open_passage") else 1.0)*(1.20 if has(g,"city_charter") else 1.0)
static func toggle_steward(g) -> bool:
 if g.persistence_blocked or not g.state["upgrades"].has("estate_steward"):return false
 g.state["economy"]["steward"]=not g.state["economy"]["steward"]
 g.add_log("Estate Steward "+("enabled; half the wallet reserved." if g.state["economy"]["steward"] else "disabled."));return true
static func delegate(g) -> void:
 if not g.state["economy"]["steward"] or not g.state["upgrades"].has("estate_steward"):return
 # One finite investment per market phase; reserve at least half the wallet. No civic currency spent.
 var order: Array=SECTORS.duplicate()
 order.sort_custom(func(a,b):return int(g.state["economy"]["sectors"][a["id"]])<int(g.state["economy"]["sectors"][b["id"]]))
 for s in order:
  var focus: String=g.state["economy"]["focus"]
  if focus!="balanced" and s["id"]!=focus:continue
  if BN.compare(g.resource("coins"),BN.times(sector_cost(g,s["id"])["coins"],2))>=0 and invest(g,s["id"]):break
static func advance_clock(g,seconds: float) -> void:
 var before: int=phase(g)
 g.state["economy"]["clock"]=fmod(float(g.state["economy"]["clock"])+seconds,PHASE_SECONDS*3)
 if phase(g)!=before:delegate(g)
static func discover(g) -> void:
 var e: Dictionary=g.state["economy"]
 e["highest_rank"]=maxi(int(e["highest_rank"]),g.rank())
 var trust: bool=false
 for v in g.state["activities"]["trust"].values():trust=trust or int(v)>=2
 var invested: bool=false
 for v in e["sectors"].values():invested=invested or int(v)>0
 var met: Array=[g.rank()>=1 and g.own("street_stall")>=3,g.own("workshop")>0,int(g.state["activities"]["completed"])>=3,trust,g.own("campaign_office")>0,invested and not e["privileges"].is_empty(),int(g.state["completed_runs"])>0]
 for i in DISCOVERIES.size():
  var id: String=DISCOVERIES[i]["id"]
  if met[i] and not e["discoveries"].has(id):
   e["discoveries"][id]=true;g.add_log("Discovery: "+DISCOVERIES[i]["name"]+". Permanent ×1.03 output, retained through Legacy.")
static func valid(e: Variant) -> bool:
 if not e is Dictionary:return false
 if not (e.get("clock") is int or e.get("clock") is float) or not is_finite(float(e["clock"])) or e["clock"]<0 or e["clock"]>=360:return false
 if not e.get("steward") is bool or e.get("focus") not in ["balanced","retail","craft","commerce"]:return false
 if not (e.get("highest_rank") is int or e.get("highest_rank") is float) or not is_finite(float(e["highest_rank"])) or float(e["highest_rank"])!=floor(float(e["highest_rank"])) or e["highest_rank"]<0 or e["highest_rank"]>=DATA.RANKS.size():return false
 for key in ["sectors","privileges","discoveries"]:
  if not e.get(key) is Dictionary:return false
 if e["sectors"].size()!=3:return false
 for s in SECTORS:
  var v: Variant=e["sectors"].get(s["id"])
  if not (v is int or v is float) or not is_finite(float(v)) or float(v)!=floor(float(v)) or v<0 or v>4:return false
 for key in ["privileges","discoveries"]:
  var allowed: Array=[]
  for d in PRIVILEGES if key=="privileges" else DISCOVERIES:allowed.append(d["id"])
  for id in e[key]:
   if id not in allowed or e[key][id]!=true:return false
 return true
