## State + economy controller: no presentation concerns. JSON persistence and bounded offline income.
class_name AscensionGame
extends RefCounted

const BN = preload("res://scripts/big_number.gd")
const DATA = preload("res://scripts/content.gd")
const SAVE_PATH: String = "user://ascension_save.json"
const BACKUP_PATH: String = "user://ascension_save.bak.json"
const VERSION: int = 3
const ECON = preload("res://scripts/economy.gd")
const ACT = preload("res://scripts/activities.gd")
const OFFLINE_LIMIT_SECONDS: float = 28800.0
const OFFLINE_EFFICIENCY: float = 0.75

var save_path: String = SAVE_PATH
var backup_path: String = BACKUP_PATH
var state: Dictionary = {}
var loaded_from_save: bool = false
var last_offline_message: String = ""
var persistence_blocked: bool = false
var load_error_message: String = ""

func _init() -> void:
	new_game()

func new_game(legacy_points: int = 0, completed_runs: int = 0) -> void:
	persistence_blocked = false
	load_error_message = ""
	var resource_bag := {}
	var total_bag := {}
	for resource in DATA.RESOURCES:
		resource_bag[resource] = BN.zero()
		total_bag[resource] = BN.zero()
	state = {
		"version": VERSION, "app_version": "0.4.0", "rank": 0, "resources": resource_bag, "totals": total_bag,
		"generators": {}, "upgrades": {}, "decisions": {}, "achievements": {},
		"legacy_points": legacy_points, "completed_runs": completed_runs,
		"economy": ECON.fresh(), "settings": {"reduced_motion":false},
		"activities": ACT.fresh(), "log": [], "paused": false, "sound_enabled": false,
		"saved_at": Time.get_unix_time_from_system()
	}
	add_log("Your journey begins. One action, one coin, one possibility.")

func add_log(message: String) -> void:
	var entries: Array = state["log"]
	entries.push_front(message)
	while entries.size() > 24:
		entries.pop_back()

func rank() -> int:
	return int(state["rank"])

func rank_name() -> String:
	return String(DATA.RANKS[rank()]["name"])

func era_name() -> String:
	return String(DATA.RANKS[rank()]["era"])

func resource(resource_name: String) -> Dictionary:
	return state["resources"].get(resource_name, BN.zero())

func total(resource_name: String) -> Dictionary:
	return state["totals"].get(resource_name, BN.zero())

func own(generator_id: String) -> int:
	return int(state["generators"].get(generator_id, 0))

func modifier(key: String) -> float:
	var factor: float = 1.0
	for level in range(1, rank() + 1):
		factor *= float(DATA.RANK_REWARDS[level]["mods"].get(key, 1.0))
	for item in DATA.UPGRADES:
		if state["upgrades"].has(item["id"]):
			factor *= float(item["mods"].get(key, 1.0))
	for decision in DATA.DECISIONS:
		var chosen: String = String(state["decisions"].get(decision["id"], ""))
		for option in decision["options"]:
			if String(option["id"]) == chosen:
				factor *= float(option["mods"].get(key, 1.0))
	var trust: Dictionary = state["activities"]["trust"]
	if key == "res_coins": factor *= 1.0 + 0.03 * int(trust["merchants"])
	if key == "res_reputation": factor *= 1.0 + 0.05 * int(trust["commons"])
	if key == "res_influence": factor *= 1.0 + 0.05 * int(trust["council"])
	if key == "global":
		factor *= (1.0 + 0.25 * float(state["legacy_points"])) * pow(1.03,state["economy"]["discoveries"].size())
	return factor

func tap_amount() -> Dictionary:
	return BN.of(modifier("tap") * modifier("global") * modifier("res_coins"))

func work() -> void:
	if bool(state["paused"]):
		return
	gain("coins", tap_amount())
	check_achievements()

func gain(resource_name: String, amount: Dictionary) -> void:
	if BN.compare(amount, BN.zero()) <= 0:
		return
	state["resources"][resource_name] = BN.add(resource(resource_name), amount)
	state["totals"][resource_name] = BN.add(total(resource_name), amount)

func income_rates() -> Dictionary:
	var income := {}
	for r in DATA.RESOURCES:
		income[r] = BN.zero()
	for gen in DATA.GENERATORS:
		var count: int = own(String(gen["id"]))
		if count <= 0:
			continue
		var output: Dictionary=generator_output(gen)
		for r in output:income[r]=BN.add(income[r],BN.times(output[r],count))
	return income

func income_of(resource_name: String) -> Dictionary:
	return income_rates()[resource_name]

func tick(seconds: float, efficiency: float = 1.0) -> void:
	if bool(state["paused"]) or seconds <= 0.0 or is_nan(seconds) or is_inf(seconds) or not is_finite(efficiency) or efficiency <= 0.0 or efficiency > 1.0:
		return
	ACT.advance(self, seconds * efficiency)
	check_achievements()

func _accrue(seconds: float) -> void:
	var rates: Dictionary = income_rates()
	for r in DATA.RESOURCES:
		gain(r, BN.times(rates[r], seconds))

func generator_cost(gen: Dictionary) -> Dictionary:
	var cost := {}
	var count: int = own(String(gen["id"]))
	for r in gen["cost"].keys():
		cost[r] = BN.power_price(float(gen["cost"][r]), float(gen["growth"]), count)
		if r=="coins": cost[r]=BN.times(cost[r],ECON.capital_discount(self))
	return cost

func can_afford(cost: Dictionary) -> bool:
	for r in cost.keys():
		if BN.compare(resource(String(r)), cost[r]) < 0:
			return false
	return true

func costs_text(cost: Dictionary) -> String:
	var strings: Array[String] = []
	for r in DATA.RESOURCES:
		if cost.has(r):
			strings.append(BN.pretty(cost[r]) + " " + r)
	return ", ".join(PackedStringArray(strings))

func _fixed_cost(raw: Dictionary) -> Dictionary:
	var c := {}
	for r in raw.keys():
		c[r] = BN.of(float(raw[r]))
	return c

func _pay(cost: Dictionary) -> bool:
	if not can_afford(cost):
		return false
	for r in cost.keys():
		state["resources"][r] = BN.subtract(resource(String(r)), cost[r])
	return true

func buy_generator(generator_id: String) -> bool:
	for gen in DATA.GENERATORS:
		if String(gen["id"]) != generator_id:
			continue
		if rank() < int(gen["rank"]):
			return false
		if own(generator_id) >= 100000000:
			return false
		if not _pay(generator_cost(gen)):
			return false
		state["generators"][generator_id] = own(generator_id) + 1
		add_log("Bought " + String(gen["name"]) + " (owned: %d)." % own(generator_id))
		check_achievements()
		return true
	return false

func buy_upgrade(upgrade_id: String) -> bool:
	for upgrade in DATA.UPGRADES:
		if String(upgrade["id"]) != upgrade_id:
			continue
		if rank() < int(upgrade["rank"]) or state["upgrades"].has(upgrade_id):
			return false
		if not _pay(_fixed_cost(upgrade["cost"])):
			return false
		state["upgrades"][upgrade_id] = true
		add_log("Upgraded: " + String(upgrade["name"]) + ".")
		return true
	return false

func choose(decision_id: String, option_id: String) -> bool:
	for decision in DATA.DECISIONS:
		if String(decision["id"]) != decision_id:
			continue
		if rank() < int(decision["rank"]) or state["decisions"].has(decision_id):
			return false
		for option in decision["options"]:
			if String(option["id"]) == option_id:
				if not _pay(_fixed_cost(option["cost"])):
					return false
				state["decisions"][decision_id] = option_id
				add_log("Decided: " + String(option["title"]) + ".")
				check_achievements()
				return true
	return false

func campaign(resource_target: String) -> bool:
	# Active conversion remains available if automation is slow; resource requirements are real.
	if resource_target == "reputation" and rank() >= 3:
		if not _pay({"coins": BN.of(750.0)}):
			return false
		gain("reputation", BN.of(8.0 * modifier("global")))
		add_log("Supported a local cause: reputation gained.")
	elif resource_target == "influence" and rank() >= 4:
		if not _pay({"coins": BN.of(2000.0), "reputation": BN.of(35.0)}):
			return false
		gain("influence", BN.of(2.0 * modifier("global")))
		add_log("Organised a local campaign: influence gained.")
	else:
		return false
	check_achievements()
	return true

func next_rank_data() -> Dictionary:
	if rank() >= DATA.RANKS.size() - 1:
		return {}
	return DATA.RANKS[rank() + 1]

func promotion_conditions() -> Array[Dictionary]:
	# One source for eligibility, display and progress; costs are lifetime milestones.
	var result: Array[Dictionary] = []
	var next: Dictionary = next_rank_data()
	if next.is_empty(): return result
	for key in next["needs"]:
		var needed: float = float(next["needs"][key])
		var met: bool = false
		var fraction: float = 0.0
		var description: String = ""
		if String(key).ends_with("_total"):
			var r: String = String(key).trim_suffix("_total")
			met = BN.compare(total(r), BN.of(needed)) >= 0
			fraction = BN.ratio_capped(total(r), BN.of(needed))
			description = "%s earned: %s / %s" % [r.capitalize(), BN.pretty(total(r)), BN.pretty(BN.of(needed))]
		elif String(key).begins_with("gen_"):
			var id: String = String(key).trim_prefix("gen_")
			var title: String = id.replace("_", " ").capitalize()
			met = own(id) >= int(needed)
			fraction = minf(1.0, float(own(id)) / needed)
			description = "%s owned: %d / %d" % [title, own(id), int(needed)]
		elif key == "choices":
			met = state["decisions"].size() >= int(needed)
			fraction = minf(1.0, float(state["decisions"].size()) / needed)
			description = "Strategic decisions: %d / %d" % [state["decisions"].size(), int(needed)]
		else:
			description = "Unknown requirement: " + str(key)
		result.append({"key":key, "met":met, "fraction":fraction, "description":description})
	return result

func requirement_lines() -> Array[String]:
	var lines: Array[String] = []
	for condition in promotion_conditions():
		lines.append(("[DONE] " if condition["met"] else "[NEED] ") + condition["description"])
	return lines

func can_promote() -> bool:
	if next_rank_data().is_empty(): return false
	for condition in promotion_conditions():
		if not condition["met"]: return false
	return true

func promote(expected_rank: int = -1) -> bool:
	# A stale UI action may never apply to a later rank, even with surplus resources.
	if expected_rank >= 0 and rank() != expected_rank: return false
	if not can_promote(): return false
	state["rank"] = rank() + 1
	add_log("ASCENDED: " + rank_name() + " — " + era_name() + ".")
	check_achievements()
	return true

func milestone_progress() -> float:
	if next_rank_data().is_empty(): return 1.0
	var conditions: Array[Dictionary] = promotion_conditions()
	var progress: float = 0.0
	for condition in conditions: progress += float(condition["fraction"])
	return progress / float(maxi(1, conditions.size()))

func milestone_percent() -> int:
	# Never display 100% for a nearly met but still blocked requirement.
	return 100 if can_promote() or next_rank_data().is_empty() else mini(99, int(floor(milestone_progress() * 100.0)))

func generator_base_output(gen: Dictionary) -> Dictionary:
	var output: Dictionary = {}
	for r in gen["output"]:
		output[r] = BN.of(float(gen["output"][r]) * modifier("gen_" + String(gen["id"])) * modifier("res_" + String(r)) * modifier("global"))
	return output

func generator_output(gen: Dictionary) -> Dictionary:
	var output: Dictionary=generator_base_output(gen)
	if output.has("coins"):output["coins"]=BN.times(output["coins"],ECON.business_factor(self,gen["id"]))
	return output

func generator_improvement(gen: Dictionary) -> Dictionary:
	var before: Dictionary=income_rates()
	var id: String=gen["id"]
	var count: int=own(id)
	state["generators"][id]=count+1
	var after: Dictionary=income_rates()
	state["generators"][id]=count
	for r in DATA.RESOURCES:after[r]=BN.subtract(after[r],before[r])
	return after

func generator_payback(gen: Dictionary) -> float:
	var costs: Dictionary = generator_cost(gen)
	if costs.size() != 1 or not costs.has("coins"): return -1.0
	var rate: Dictionary = generator_improvement(gen).get("coins", BN.zero())
	if float(rate["m"]) <= 0.0: return -1.0
	var price: Dictionary = costs["coins"]
	var difference: int = int(price["e"]) - int(rate["e"])
	if difference > 12: return -1.0
	return float(price["m"]) / float(rate["m"]) * pow(10.0, float(difference))

func legacy_reset() -> bool:
	if rank() < DATA.RANKS.size() - 1 or persistence_blocked:
		return false
	var previous: Dictionary = state.duplicate(true)
	var points: int = int(state["legacy_points"]) + 1
	var runs: int = int(state["completed_runs"]) + 1
	new_game(points, runs)
	state["achievements"]=previous["achievements"].duplicate(true)
	state["economy"]["discoveries"]=previous["economy"]["discoveries"].duplicate(true)
	state["economy"]["highest_rank"]=maxi(rank(),int(previous["economy"]["highest_rank"]))
	state["settings"]=previous["settings"].duplicate(true)
	ECON.discover(self)
	state["achievements"]["legacy"] = true
	add_log("Legacy gained! Permanent global production +25% per Legacy point.")
	if not save_game():
		state = previous
		return false
	return true

func check_achievements() -> void:
	ECON.discover(self)
	for a in DATA.ACHIEVEMENTS:
		var id: String = String(a["id"])
		if state["achievements"].has(id):
			continue
		var ok: bool = false
		match id:
			"first_coin": ok = BN.compare(total("coins"), BN.of(1.0)) >= 0
			"first_stall": ok = own("street_stall") >= 1
			"workshop": ok = own("workshop") >= 1
			"first_reputation": ok = BN.compare(total("reputation"), BN.of(1.0)) >= 0
			"influence": ok = BN.compare(total("influence"), BN.of(1.0)) >= 0
			"first_choice": ok = not state["decisions"].is_empty()
			"civic_leader": ok = rank() >= 6
			"legacy": ok = int(state["legacy_points"]) >= 1
		if ok:
			state["achievements"][id] = true
			add_log("Achievement unlocked: " + String(a["title"]) + "!")

func save_game() -> bool:
	if persistence_blocked:
		return false
	state["saved_at"] = Time.get_unix_time_from_system()
	var file := FileAccess.open(save_path + ".tmp", FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(JSON.stringify(state))
	file.flush()
	file.close()
	var target: String = ProjectSettings.globalize_path(save_path)
	var temp: String = ProjectSettings.globalize_path(save_path + ".tmp")
	var backup: String = ProjectSettings.globalize_path(backup_path)
	if FileAccess.file_exists(save_path):
		if DirAccess.copy_absolute(target, backup) != OK:
			return false
	return DirAccess.rename_absolute(temp, target) == OK

func load_or_new() -> void:
	persistence_blocked = false
	load_error_message = ""
	loaded_from_save = false
	last_offline_message = ""
	var primary_loaded: bool = _load_from_path(save_path)
	var backup_loaded: bool = false
	if not primary_loaded and not persistence_blocked:
		backup_loaded = _load_from_path(backup_path)
	if primary_loaded or backup_loaded:
		# Preserve the pre-update file once, before offline accrual/autosave touches it.
		var original_path: String = backup_path if backup_loaded else save_path
		var migration_backup: String = save_path + (".pre-v03.json" if String(state.get("app_version","0.1.0")) in ["0.1.0","0.2.0"] else ".pre-v04.json")
		if String(state.get("app_version", "0.1.0")) != "0.4.0" and not FileAccess.file_exists(migration_backup):
			if DirAccess.copy_absolute(ProjectSettings.globalize_path(original_path), ProjectSettings.globalize_path(migration_backup)) != OK:
				persistence_blocked = true
				load_error_message = "Could not create the update backup. Saving disabled; original progress preserved."
		state["app_version"] = "0.4.0"
		loaded_from_save = true
		if backup_loaded and FileAccess.file_exists(save_path):
			# Preserve the surviving backup instead of copying corrupted primary over it.
			DirAccess.remove_absolute(ProjectSettings.globalize_path(save_path))
		var now: float = Time.get_unix_time_from_system()
		var then: float = float(state.get("saved_at", now))
		var elapsed: float = clampf(now - then, 0.0, OFFLINE_LIMIT_SECONDS)
		if elapsed >= 1.0 and not bool(state["paused"]):
			tick(elapsed, OFFLINE_EFFICIENCY)
			last_offline_message = "While away: %s of production at 75%% efficiency (8h max)." % _duration(elapsed)
			add_log(last_offline_message)
		save_game() # prevents multiple offline awards on reloading
	else:
		var existing: bool = FileAccess.file_exists(save_path) or FileAccess.file_exists(backup_path)
		new_game()
		if existing:
			persistence_blocked = true
			load_error_message = "Save could not be read. Original files preserved; saving disabled. Restore a backup or use Reset to start over."

func _duration(seconds: float) -> String:
	var hours: int = int(floor(seconds / 3600.0))
	var minutes: int = int(floor(float(int(seconds) % 3600) / 60.0))
	return "%dh %dm" % [hours, minutes]

func _load_from_path(path: String) -> bool:
	if not FileAccess.file_exists(path):
		return false
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if not (parsed is Dictionary):
		return false
	if not _integer_field(parsed.get("version")):
		return false
	if int(parsed["version"]) > VERSION:
		persistence_blocked = true
		return false
	if int(parsed["version"]) not in [1, 2, VERSION]:
		return false
	if not (parsed.get("resources") is Dictionary and parsed.get("totals") is Dictionary):
		return false
	var clean: Dictionary = parsed.duplicate(true)
	for r in DATA.RESOURCES:
		if not BN.valid(clean["resources"].get(r)) or not BN.valid(clean["totals"].get(r)):
			return false
		clean["resources"][r] = BN.sanitize(clean["resources"][r])
		clean["totals"][r] = BN.sanitize(clean["totals"][r])
	if not (clean.get("generators") is Dictionary and clean.get("upgrades") is Dictionary and clean.get("decisions") is Dictionary):
		return false
	if not (clean.get("achievements") is Dictionary and clean.get("log") is Array):
		return false
	for field in ["rank", "legacy_points", "completed_runs"]:
		if not _integer_field(clean.get(field, 0)):
			return false
	if not _number_field(clean.get("saved_at")):
		return false
	if not (clean.get("paused", false) is bool):
		return false
	clean["rank"] = clampi(int(clean.get("rank", 0)), 0, DATA.RANKS.size() - 1)
	clean["legacy_points"] = clampi(int(clean.get("legacy_points", 0)), 0, 1000000)
	clean["completed_runs"] = clampi(int(clean.get("completed_runs", 0)), 0, 1000000)
	clean["paused"] = bool(clean.get("paused", false))
	clean["sound_enabled"] = bool(clean.get("sound_enabled", false))
	for gen in DATA.GENERATORS:
		var id: String = String(gen["id"])
		if not _integer_field(clean["generators"].get(id, 0)):
			return false
		clean["generators"][id] = clampi(int(clean["generators"].get(id, 0)), 0, 100000000)
	for upgrade in DATA.UPGRADES:
		if clean["upgrades"].has(upgrade["id"]):
			clean["upgrades"][upgrade["id"]] = true
	for decision in DATA.DECISIONS:
		var did: String = String(decision["id"])
		if not clean["decisions"].has(did):
			continue
		var valid_option: bool = false
		for option in decision["options"]:
			if clean["decisions"][did] == option["id"]:
				valid_option = true
		if not valid_option:
			clean["decisions"].erase(did)
	# Keep only known content; unknown keys must not satisfy decision milestones.
	for category in ["generators", "upgrades", "decisions", "achievements"]:
		var definitions: Array = DATA.GENERATORS if category == "generators" else DATA.UPGRADES if category == "upgrades" else DATA.DECISIONS if category == "decisions" else DATA.ACHIEVEMENTS
		var allowed: Dictionary = {}
		for item in definitions:
			allowed[item["id"]] = true
		for key in clean[category].keys():
			if not allowed.has(key):
				clean[category].erase(key)
	if int(clean["version"]) == 1:
		clean["activities"] = ACT.fresh()
	elif not ACT.valid(clean.get("activities")):
		return false
	if int(clean["version"])<3:
		clean["economy"]=ECON.fresh()
		clean["economy"]["highest_rank"]=DATA.RANKS.size()-1 if clean["legacy_points"]>0 else clean["rank"]
		clean["settings"]={"reduced_motion":false}
	elif not ECON.valid(clean.get("economy")) or not clean.get("settings") is Dictionary or not clean["settings"].get("reduced_motion") is bool:
		return false
	clean["version"] = VERSION
	clean["log"] = clean["log"].filter(func(entry): return entry is String).slice(0, 24)
	state = clean
	ECON.discover(self)
	return true

func _number_field(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))

func _integer_field(value: Variant) -> bool:
	return _number_field(value) and absf(float(value)) < 9.0e15 and float(value) == floor(float(value))


func upgrade_payback(upgrade_id: String) -> float:
	# A coin-only estimate for the current asset mix; reputation costs have no fixed exchange price.
	for upgrade in DATA.UPGRADES:
		if upgrade["id"] != upgrade_id or state["upgrades"].has(upgrade_id):
			continue
		if upgrade["cost"].size() != 1 or not upgrade["cost"].has("coins"):
			return -1.0
		var before: Dictionary = income_of("coins")
		state["upgrades"][upgrade_id] = true
		var after: Dictionary = income_of("coins")
		state["upgrades"].erase(upgrade_id)
		var delta: Dictionary = BN.subtract(after, before)
		if float(delta["m"]) <= 0.0 or int(delta["e"]) > 300:
			return -1.0
		return float(upgrade["cost"]["coins"]) / (float(delta["m"]) * pow(10.0, float(delta["e"])))
	return -1.0

func resource_path(r: String) -> String:
	if r == "coins": return "WORK and Street Stalls earn coins. Trade commits capital temporarily; only its profit counts toward milestones."
	if r == "reputation":
		if rank() < 2: return "Reputation begins with Market Provisions and negotiations at Street Vendor."
		if rank() < 3: return "Market Provisions and the Assembly earn reputation. Independent Trader unlocks the permanent Rumour Network."
		return "Buy a Rumour Network with coins alone for permanent reputation. Relief contracts and Assembly talks offer another route."
	if rank()<4: return "Influence unlocks at Guildmaster. No influence is required to become Guildmaster."
	return "Campaign Offices produce influence and reputation. Fund them with coins and Rumour Network reputation; Council talks and guild contracts also help."

func milestone_eta() -> String:
	if can_promote():return "Ready to ascend now."
	if next_rank_data().is_empty():return "Chapter complete. Build your Legacy."
	if state["paused"]:return "Production is paused. Resume in Settings to advance the income estimate."
	var wait: float=0.0
	var actions: Array[String]=[]
	for c in promotion_conditions():
		if c["met"]:continue
		var key: String=c["key"]
		if key.ends_with("_total"):
			var r: String=key.trim_suffix("_total")
			var rate: Dictionary=income_of(r)
			if float(rate["m"])<=0:actions.append("start "+r+" production")
			else:
				var need: Dictionary=BN.subtract(BN.of(float(next_rank_data()["needs"][key])),total(r))
				var delta: int=int(need["e"])-int(rate["e"])
				if delta>12:return "Income gates exceed the planning horizon. Improve production first."
				wait=maxf(wait, float(need["m"])/float(rate["m"])*pow(10.0,float(delta)))
		else:actions.append("buy required assets" if key.begins_with("gen_") else "make strategic decisions")
	var estimate: String="Income gates: ~%ds at current passive rates" % int(ceil(wait)) if wait<60 else "Income gates: ~%dm at current passive rates" % int(ceil(wait/60.0))
	return (estimate+". " if wait>0 else "")+("Action needed: "+", ".join(actions)+"." if not actions.is_empty() else "No further purchases assumed; trade, taps and spending may change this.")
