## Native portrait presentation; the existing economy remains in AscensionGame.
extends Control
const ECON = preload("res://scripts/economy.gd")
const WorldView = preload("res://scripts/world_view.gd")
const ACT = preload("res://scripts/activities.gd")
const GameScript = preload("res://scripts/game.gd")
const DATA = preload("res://scripts/content.gd")
const BN = preload("res://scripts/big_number.gd")
const SERIF = preload("res://assets/fonts/Regal.ttf")
const BODY = preload("res://assets/fonts/Readable.ttf")
const BG = Color("#10121a")
const PANEL = Color("#1c202b")
const PANEL_DARK = Color("#151923")
const GOLD = Color("#e1c18b")
const WHITE = Color("#f1ede6")
const MUTED = Color("#b0b4c1")
const GOOD = Color("#a2dac1")
const BLUE = Color("#aebfef")
const RED = Color("#f0aaaa")
var game: AscensionGame
var atmosphere: TextureRect
var header_crest: TextureRect
var header_rank: Label
var header_title: Label
var header_details: Label
var header_toggle: Button
var resource_values: Array[Label] = []
var resource_rates: Array[Label] = []
var goal_button: Button
var goal_rank: int = 0
var work_button: Button
var pause_button: Button
var page_refresh: Array[Callable] = []
var content: VBoxContainer
var scroller: ScrollContainer
var outer_margin: MarginContainer
var nav_buttons: Array[Button] = []
var current_tab: int = 0
var scroll_positions: Dictionary = {}
var page_generation: int = 0
var compact_header: bool = true
var backgrounded: bool = false
var skip_frame: bool = false
var refresh_seconds: float = 0.0
var autosave_seconds: float = 0.0
var feedback: Label
var save_status: Label
var feedback_seconds: float = 0.0
var save_notice_seconds: float = 0.0
var last_save_failed: bool = false
var promotion_busy: bool = false
var promotion_overlay: Control
var promotion_panel: PanelContainer
var celebration_body: VBoxContainer
var legacy_confirmation: ConfirmationDialog
var reset_confirmation: ConfirmationDialog
var resource_names: Array[Control] = []
var upgrade_filter: String = "available"
var upgrade_sort: bool = false
var venture_mode: String = "trade"
var trade_route: String = "safe"
var trade_lots: int = 1
var activity_revision: int = -1
var previous_scroll: float = 0.0
var empire_mode: String = "district"
var focused_business: String = ""
var last_market_phase: int = -1
var expanded_rank: int = -1
var show_future: bool = false
var target_faction: String = ""

func _ready() -> void:
	game = GameScript.new()
	if OS.is_debug_build(): print("ASCENSION 0.4: loading saved progress")
	game.load_or_new()
	if OS.is_debug_build(): print("ASCENSION 0.4: loaded rank ", game.rank())
	var theme := Theme.new()
	theme.default_font = BODY
	theme.default_font_size = 15
	self.theme = theme
	_build_layout()
	_render_all()
	get_viewport().size_changed.connect(_apply_safe_area)
	_apply_safe_area()
	if OS.is_debug_build(): print("ASCENSION 0.4: interface ready")
	if not game.load_error_message.is_empty(): _notify(game.load_error_message, false)
	elif not game.last_offline_message.is_empty(): _notify(game.last_offline_message)

func _process(delta: float) -> void:
	if backgrounded: return
	if skip_frame:
		skip_frame = false
		return
	game.tick(delta)
	if ECON.phase(game)!=last_market_phase:
		last_market_phase=ECON.phase(game)
		_render_page.call_deferred()
	var revision: int = int(game.state["activities"]["revision"])
	if revision != activity_revision:
		activity_revision = revision
		if current_tab == 1: _render_page.call_deferred()
	save_notice_seconds = maxf(0.0, save_notice_seconds-delta)
	refresh_seconds += delta
	autosave_seconds += delta
	if refresh_seconds >= 0.25:
		refresh_seconds = 0.0
		_refresh_live()
	if feedback_seconds > 0.0:
		feedback_seconds -= delta
		if feedback_seconds <= 0.0: feedback.text = ""
	if autosave_seconds >= 15.0:
		autosave_seconds = 0.0
		_save()

func _notification(what: int) -> void:
	if game == null: return
	if what == NOTIFICATION_WM_CLOSE_REQUEST: game.save_game()
	elif what == NOTIFICATION_APPLICATION_PAUSED:
		game.save_game()
		backgrounded = true
	elif what == NOTIFICATION_APPLICATION_RESUMED and backgrounded:
		backgrounded = false
		skip_frame = true
		game.load_or_new()
		_render_all()
		if not game.last_offline_message.is_empty(): _notify(game.last_offline_message)
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if promotion_overlay != null and promotion_overlay.visible: _dismiss_promotion()
		elif current_tab != 0: _select_tab(0)

func _style(color: Color, border: Color = Color.TRANSPARENT, radius: int = 13) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_corner_radius_all(radius)
	style.set_content_margin_all(12.0)
	if border.a > 0.0: style.set_border_width_all(1)
	style.shadow_color = Color(0.0, 0.0, 0.0, 0.20)
	style.shadow_size = 5
	style.shadow_offset = Vector2(0, 3)
	return style

func _label(message: String, font_size: int = 15, color: Color = WHITE, elegant: bool = false) -> Label:
	var label := Label.new()
	label.text = message
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_color_override("font_color", color)
	label.add_theme_font_size_override("font_size", font_size)
	if elegant: label.add_theme_font_override("font", SERIF)
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label

func _icon(id: String, pixels: int = 28) -> TextureRect:
	var image := TextureRect.new()
	image.texture = load("res://assets/icons/" + id + ".svg")
	image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	image.custom_minimum_size = Vector2(pixels, pixels)
	image.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return image

func _button(title: String, action: Callable, enabled: bool = true, primary: bool = false) -> Button:
	var button := Button.new()
	button.text = title
	button.mouse_filter = Control.MOUSE_FILTER_PASS
	button.tooltip_text = title
	button.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	button.clip_text = true
	button.disabled = not enabled
	button.custom_minimum_size = Vector2(0, 52 if primary else 48)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.add_theme_font_size_override("font_size", 14)
	button.add_theme_color_override("font_color", BG if primary else WHITE)
	button.add_theme_color_override("font_disabled_color", MUTED)
	button.add_theme_stylebox_override("normal", _style(GOLD if primary else Color("#292e3d"), Color("#b59661") if primary else Color("#424655"), 9))
	button.add_theme_stylebox_override("hover", _style(GOLD.lightened(0.08) if primary else Color("#343b4b"), GOLD, 9))
	button.add_theme_stylebox_override("pressed", _style(Color("#b69a66") if primary else Color("#161b29"), GOLD, 9))
	button.add_theme_stylebox_override("disabled", _style(Color("#222530"), Color("#373b46"), 9))
	# Purchases may rebuild their own page. Finish input dispatch first,
	# so Godot never continues processing a control removed by its callback.
	button.pressed.connect(action, CONNECT_DEFERRED)
	return button

func _card(outline: Color = Color("#393b48")) -> VBoxContainer:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _style(PANEL, outline))
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.mouse_filter = Control.MOUSE_FILTER_PASS
	content.add_child(panel)
	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 5)
	panel.add_child(inner)
	return inner

func _build_layout() -> void:
	var backdrop := TextureRect.new()
	atmosphere = backdrop
	backdrop.texture = preload("res://assets/atmosphere.svg")
	backdrop.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	backdrop.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	backdrop.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(backdrop)
	outer_margin = MarginContainer.new()
	outer_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(outer_margin)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 5)
	outer_margin.add_child(column)
	var brand := HBoxContainer.new()
	brand.add_theme_constant_override("separation", 8)
	column.add_child(brand)
	header_crest = _icon("embers",36)
	brand.add_child(header_crest)
	var identity := VBoxContainer.new()
	identity.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	identity.add_theme_constant_override("separation", 0)
	brand.add_child(identity)
	header_title = _label("A S C E N S I O N", 19, GOLD, true)
	identity.add_child(header_title)
	header_rank = _label("", 14, WHITE)
	identity.add_child(header_rank)
	header_toggle = _button("Stats", _toggle_header)
	header_toggle.size_flags_horizontal = Control.SIZE_SHRINK_END
	header_toggle.custom_minimum_size.x = 64
	header_toggle.tooltip_text = "Expand or collapse status"
	brand.add_child(header_toggle)
	var settings := _button("", _select_tab.bind(5))
	settings.icon = load("res://assets/icons/settings.svg")
	settings.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	settings.size_flags_horizontal = Control.SIZE_SHRINK_END
	settings.custom_minimum_size.x = 48
	settings.tooltip_text = "Settings"
	settings.name = "SettingsButton"
	brand.add_child(settings)
	header_details = _label("", 13, MUTED)
	header_details.visible = false
	column.add_child(header_details)
	var treasury := HBoxContainer.new()
	treasury.add_theme_constant_override("separation", 5)
	column.add_child(treasury)
	for resource in DATA.RESOURCES:
		var panel := PanelContainer.new()
		panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var style := _style(Color("#191d29"), Color("#3a3945"), 9)
		style.set_content_margin_all(8.0)
		panel.add_theme_stylebox_override("panel", style)
		treasury.add_child(panel)
		var stack := VBoxContainer.new()
		stack.add_theme_constant_override("separation", 1)
		panel.add_child(stack)
		var row := HBoxContainer.new()
		row.add_child(_icon(resource, 16))
		var amount := _label("0", 16)
		row.add_child(amount)
		stack.add_child(row)
		resource_values.append(amount)
		var resource_name := _label(String(resource).capitalize(), 11, GOLD)
		resource_names.append(resource_name)
		stack.add_child(resource_name)
		var rate := _label("+0/s", 11, MUTED)
		stack.add_child(rate)
		resource_rates.append(rate)
	goal_button = _button("", _on_goal)
	goal_button.name = "PrimaryAscendButton"
	column.add_child(goal_button)
	scroller = ScrollContainer.new()
	scroller.name = "MainScroll"
	scroller.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroller.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroller.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroller.scroll_deadzone = 10
	scroller.follow_focus = false
	scroller.get_v_scroll_bar().value_changed.connect(_scroll_status)
	column.add_child(scroller)
	content = VBoxContainer.new()
	content.name = "PageContent"
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 10)
	scroller.add_child(content)
	var notice := HBoxContainer.new()
	column.add_child(notice)
	feedback = _label("", 12, GOOD)
	feedback.max_lines_visible = 2
	feedback.custom_minimum_size.y = 20
	notice.add_child(feedback)
	save_status = _label("Autosave active", 12, MUTED)
	save_status.autowrap_mode = TextServer.AUTOWRAP_OFF
	save_status.size_flags_horizontal = Control.SIZE_SHRINK_END
	notice.add_child(save_status)
	var navigation := HBoxContainer.new()
	navigation.add_theme_constant_override("separation", 4)
	column.add_child(navigation)
	var titles := ["Empire", "Ventures", "Upgrades", "Council", "Ascend"]
	var icons := ["market", "routes", "upgrades", "decisions", "crown"]
	for i in titles.size():
		var nav := _button("", _select_tab.bind(i))
		nav.name = titles[i] + "Tab"
		nav.tooltip_text = titles[i]
		nav.custom_minimum_size.y = 56
		var stack := VBoxContainer.new()
		stack.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		stack.offset_top = 6
		stack.offset_bottom = -5
		stack.mouse_filter = Control.MOUSE_FILTER_IGNORE
		stack.add_theme_constant_override("separation", 2)
		nav.add_child(stack)
		stack.add_child(_icon(icons[i], 23))
		var label := _label(titles[i], 11, MUTED)
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		stack.add_child(label)
		navigation.add_child(nav)
		nav_buttons.append(nav)
	reset_confirmation = ConfirmationDialog.new()
	reset_confirmation.title = "Erase this journey?"
	reset_confirmation.dialog_text = "This erases resources, ranks, choices and Legacy. A local backup is made before reset."
	reset_confirmation.confirmed.connect(_reset_all)
	add_child(reset_confirmation)
	legacy_confirmation = ConfirmationDialog.new()
	legacy_confirmation.title = "Begin a new Legacy?"
	legacy_confirmation.dialog_text = "Restart the chapter with +25% permanent output per Legacy point. Current resources and choices reset; all Legacy points remain."
	legacy_confirmation.confirmed.connect(_legacy_reset)
	add_child(legacy_confirmation)
	for dialog in [reset_confirmation, legacy_confirmation]:
		dialog.get_label().autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		dialog.get_label().custom_minimum_size.x = 270
		var dialog_theme := Theme.new()
		dialog_theme.default_font = BODY
		dialog_theme.default_font_size = 15
		dialog_theme.set_constant("buttons_min_height", "AcceptDialog", 48)
		dialog.theme = dialog_theme
	legacy_confirmation.get_ok_button().text = "Begin Legacy"
	reset_confirmation.get_ok_button().text = "Erase progress"
	promotion_overlay = Control.new()
	promotion_overlay.name = "AscensionCelebration"
	promotion_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	promotion_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(promotion_overlay)
	var dim := ColorRect.new()
	dim.color = Color(0.025, 0.03, 0.055, 0.94)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	promotion_overlay.add_child(dim)
	var center := Control.new()
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	promotion_overlay.add_child(center)
	promotion_panel = PanelContainer.new()
	promotion_panel.add_theme_stylebox_override("panel", _style(Color("#20212e"), GOLD, 18))
	center.add_child(promotion_panel)
	celebration_body = VBoxContainer.new()
	celebration_body.add_theme_constant_override("separation", 12)
	promotion_panel.add_child(celebration_body)
	promotion_overlay.hide()

func _refresh_live() -> void:
	_render_header()
	for refresh in page_refresh: refresh.call()

func _render_all() -> void:
	_render_header()
	_render_page()
	_render_header()

func _render_header() -> void:
	header_rank.text = game.rank_name()
	header_title.visible = not compact_header
	for resource_name in resource_names: resource_name.visible = not compact_header
	header_crest.texture = load("res://assets/icons/" + DATA.RANK_REWARDS[game.rank()]["icon"] + ".svg")
	atmosphere.modulate = Color(1.0,0.94,0.87) if game.rank()<3 else Color(0.88,0.94,1.0) if game.rank()<5 else Color(0.96,0.87,1.0)
	save_status.text = "Save failed" if last_save_failed else "✓ Saved" if save_notice_seconds>0.0 else "Autosave on"
	save_status.add_theme_color_override("font_color", RED if last_save_failed else GOOD if save_notice_seconds>0.0 else MUTED)
	header_details.text = "%s · Legacy %d\n%s" % [game.era_name(), int(game.state["legacy_points"]), DATA.RANK_REWARDS[game.rank()]["benefit"]]
	header_details.visible = not compact_header
	var rates: Dictionary = game.income_rates()
	for i in DATA.RESOURCES.size():
		resource_values[i].text = BN.pretty(game.resource(DATA.RESOURCES[i]))
		resource_rates[i].text = ("At Guildmaster" if i == 2 and game.rank()<4 else "At Vendor" if i == 1 and game.rank()<2 else "+%s/s" % BN.pretty(rates[DATA.RESOURCES[i]]))
	goal_rank = game.rank()
	var next: Dictionary = game.next_rank_data()
	var ready: bool = game.can_promote() and not game.persistence_blocked
	goal_button.disabled = promotion_busy
	goal_button.text = "CLAIM YOUR LEGACY" if next.is_empty() else ("ASCEND NOW · " if ready else "NEXT · ") + String(next["name"]) + ("" if ready else " · %d%%" % game.milestone_percent())
	goal_button.add_theme_color_override("font_color", BG if ready else GOLD)
	goal_button.add_theme_stylebox_override("normal", _style(GOLD if ready else Color("#272632"), GOLD if ready else Color("#67604e"), 9))
	goal_button.tooltip_text = "Promote now. No resource cost." if ready else "Inspect every requirement for the next rank."
	if is_instance_valid(work_button):
		work_button.text = "WORK · +%s coins" % BN.pretty(game.tap_amount())
		work_button.disabled = bool(game.state["paused"])
	if is_instance_valid(pause_button): pause_button.text = "Resume production" if game.state["paused"] else "Pause production"
	for i in nav_buttons.size():
		nav_buttons[i].add_theme_stylebox_override("normal", _style(Color("#35303a") if current_tab == i else Color("#171b26"), GOLD if current_tab == i else Color("#383b48"), 11))

func _render_page() -> void:
	if content == null: return
	activity_revision = int(game.state["activities"]["revision"])
	page_generation += 1
	page_refresh.clear()
	var position: int = scroller.scroll_vertical
	for child in content.get_children():
		content.remove_child(child)
		child.queue_free()
	work_button = null
	pause_button = null
	match current_tab:
		0: _empire_page()
		1: _ventures_page()
		2: _upgrades_page()
		3: _decisions_page()
		4: _ascension_page()
		5: _settings_page()
	for refresh in page_refresh: refresh.call()
	_restore_scroll.call_deferred(position, page_generation)

func _restore_scroll(position: int, generation: int) -> void:
	# New content needs its final scrollbar range before a saved offset is applied.
	await get_tree().process_frame
	await get_tree().process_frame
	if generation == page_generation: scroller.scroll_vertical = position

func _page_intro(title: String, subtitle: String) -> void:
	content.add_child(_label(title, 26, GOLD, true))
	content.add_child(_label(subtitle, 13, MUTED))

func _asset_heading(card: VBoxContainer, title: String, subtitle: String, icon_id: String, color: Color = WHITE) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	row.add_child(_icon(icon_id, 34))
	var text := VBoxContainer.new()
	text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text.add_theme_constant_override("separation", 1)
	row.add_child(text)
	text.add_child(_label(title, 19, color, true))
	text.add_child(_label(subtitle, 12, MUTED))
	card.add_child(row)

func _empire_page() -> void:
	var modes:=HBoxContainer.new();content.add_child(modes)
	for mode in ["district","businesses","sectors"]:
		var button:=_button(mode.capitalize(),_empire_mode.bind(mode),true,empire_mode==mode)
		button.name="Empire_"+mode;modes.add_child(button)
	if empire_mode=="sectors":
		_sectors_page();return
	if empire_mode=="district":
		_world_panel()
		var headline:=_label("",13,GOLD);content.add_child(headline)
		page_refresh.append(func():headline.text=ECON.market_title(game)+" · "+("demand awakens at Vendor" if game.rank()<2 else "+20% "+ECON.SECTORS[ECON.phase(game)]["name"]+" sales"))
		content.add_child(_label(DATA.RANK_REWARDS[game.rank()]["unlocks"],13,MUTED))
		if game.rank()>=3 and float(game.income_of("reputation")["m"])<=0:_resource_guide("reputation","rumour_network")
		elif game.rank()>=4 and float(game.income_of("influence")["m"])<=0:_resource_guide("influence","campaign_office")
		work_button=_button("WORK",_on_work,not game.state["paused"],true)
		work_button.name="WorkButton";content.add_child(work_button)
		if game.rank()>=1:
			var context:=HBoxContainer.new();content.add_child(context)
			context.add_child(_button("Trade & diplomacy",_select_tab.bind(1)))
			context.add_child(_button("Grow businesses",_empire_mode.bind("businesses")))
	else:
		_page_intro("The engines of prosperity","Net income includes operating costs. Purchases also strengthen supply chains and contract capacity.")
		if not focused_business.is_empty():content.add_child(_button("Show all businesses",_focus_business.bind("")))
	for gen in DATA.GENERATORS:
		if game.rank()<int(gen["rank"]):continue
		var id: String=gen["id"]
		if empire_mode=="district" and id!="street_stall":continue
		if empire_mode=="businesses" and not focused_business.is_empty() and id!=focused_business:continue
		var card:=_card()
		_asset_heading(card,gen["name"],"OWNED %d" % game.own(id),"market" if gen["rank"]<3 else "routes" if gen["rank"]==3 else "citadel")
		var output:=_label("",13,GOOD);card.add_child(output)
		var cost_text:=_label("",13,GOLD);card.add_child(cost_text)
		var buy:=_button("Invest",_buy_generator.bind(id));buy.name="Buy_"+id;card.add_child(buy)
		page_refresh.append(func():
			var cost: Dictionary=game.generator_cost(gen)
			var parts: Array[String]=[]
			for r in game.generator_output(gen):parts.append("+"+BN.pretty(game.generator_output(gen)[r])+" "+r+"/s per unit")
			output.text=" · ".join(parts)
			cost_text.text=game.costs_text(cost)
			buy.disabled=not game.can_afford(cost) or game.persistence_blocked or game.state["paused"]
		)
		if empire_mode=="businesses":
			var marginal: Array[String]=[]
			var improvement: Dictionary=game.generator_improvement(gen)
			for r in improvement:
				if float(improvement[r]["m"])>0:marginal.append("+"+BN.pretty(improvement[r])+" "+r+"/s")
			card.add_child(_label("Next purchase across holdings: "+" · ".join(marginal),12,GOOD))
			var profile: Dictionary=ECON.business_profile(game,gen)
			if not profile.is_empty():
				card.add_child(_label("Per unit: revenue "+BN.pretty(profile["revenue"])+" − costs "+BN.pretty(profile["cost"])+" = net "+BN.pretty(profile["net"])+"/s",12,BLUE))
				card.add_child(_label("Capacity +%d · owned milestones 10 / 25 / 50 grant ×1.25 each" % (1 if id=="street_stall" else 4 if id=="workshop" else 8),12,MUTED))
			else:card.add_child(_label(gen["description"],12,MUTED))
			var payoff: float=game.generator_payback(gen)
			if payoff>0:card.add_child(_label("Marginal payback ~"+_duration(payoff)+" including supply effects",12,BLUE))
	if empire_mode=="businesses":
		if game.rank()>=3:_conversion_card("Community patronage","An immediate alternative when a milestone is close.","Patronage · 750 coins","reputation",{"coins":BN.of(750.0)})
		if game.rank()>=4:_conversion_card("Council campaign","Networks preserve long-term civic income.","Campaign · 2K coins + 35 reputation","influence",{"coins":BN.of(2000.0),"reputation":BN.of(35.0)})

func _empire_mode(mode: String) -> void:
	empire_mode=mode;focused_business="";scroller.scroll_vertical=0;_render_page()
func _focus_business(id: String) -> void:
	current_tab=0;empire_mode="businesses";focused_business=id;scroller.scroll_vertical=0;_render_all()
func _invest_sector(id: String) -> void:_after_action(ECON.invest(game,id))
func _ratify(id: String) -> void:_after_action(ECON.ratify(game,id),"Build trust 2, reach the required rank and fund the agreement.")
func _steward() -> void:_after_action(ECON.toggle_steward(game))
func _focus_sector(id: String) -> void:
	game.state["economy"]["focus"]=id;_save();_render_page()
func _sectors_page() -> void:
	_page_intro("One city. One economy.","Producers supply markets. Markets feed trade. Political rights improve every next investment.")
	content.add_child(_label("Productive capacity %d · %d-lot shipments · %d active trade slots" % [ECON.capacity(game),ACT.lots_limit(game),ACT.capacity(game)],14,GOLD))
	content.add_child(_label("Operating margin %.0f%% · permanent discoveries ×%.2f" % [(1.0-ECON.cost_fraction(game))*100,pow(1.03,game.state["economy"]["discoveries"].size())],13,GOOD))
	for sector in ECON.SECTORS:
		var id: String=sector["id"]
		var level: int=game.state["economy"]["sectors"][id]
		var card:=_card()
		_asset_heading(card,sector["name"],"EXPANSION %d / 4 · ×%.2f SALES" % [level,pow(1.30,level)],"market" if id=="retail" else "work" if id=="craft" else "routes")
		card.add_child(_label(sector["link"],13,MUTED))
		card.add_child(_label("Next: ×1.30 sector sales · ×1.15 linked contract profit · +4 capacity",13,GOOD))
		var cost: Dictionary=ECON.sector_cost(game,id)
		card.add_child(_label(game.costs_text(cost) if level<4 else "Fully developed this life",13,GOLD))
		var allowed: bool=game.rank()>=sector["rank"] and game.own(sector["business"])>0
		var invest:=_button("Expand sector" if allowed else "Own "+sector["business"].replace("_"," "),_invest_sector.bind(id),allowed and level<4 and game.can_afford(cost))
		invest.name="Sector_"+id;card.add_child(invest)
	var steward:=_card()
	_asset_heading(steward,"The Estate Steward","AUTOMATION WITH RESERVES","seal")
	steward.add_child(_label("One sector expansion per two-minute market phase. Keeps at least half your coins; never spends reputation or influence. Works offline, stops at level 4.",13,MUTED))
	var switcher:=_button("Steward: ON" if game.state["economy"]["steward"] else "Steward: OFF",_steward,game.state["upgrades"].has("estate_steward"));switcher.name="StewardToggle";steward.add_child(switcher)
	if not game.state["upgrades"].has("estate_steward"):steward.add_child(_button("Inspect Steward upgrade",_select_tab.bind(2)))
	var focus:=GridContainer.new();focus.columns=2;steward.add_child(focus)
	for id in ["balanced","retail","craft","commerce"]:focus.add_child(_button(id.capitalize(),_focus_sector.bind(id),true,game.state["economy"]["focus"]==id))

func _conversion_card(title: String, description: String, action: String, target: String, cost: Dictionary) -> void:
	var card := _card()
	_asset_heading(card, title, "RESOURCE CONVERSION", "influence")
	card.add_child(_label(description, 13, MUTED))
	var reward: float = (8.0 if target == "reputation" else 2.0) * game.modifier("global")
	card.add_child(_label("Receive %s %s immediately" % [BN.pretty(BN.of(reward)), target], 14, GOOD))
	var button := _button(action, _on_campaign.bind(target), game.can_afford(cost))
	card.add_child(button)
	_track_affordability(button, cost)

func _upgrades_page() -> void:
	_page_intro("The art of compounding", "Permanent gains for this life. Production bonuses need an active source.")
	var filters := HBoxContainer.new()
	content.add_child(filters)
	for mode in ["available", "all", "owned"]:
		filters.add_child(_button(mode.capitalize(), _set_upgrade_filter.bind(mode), true, mode==upgrade_filter))
	content.add_child(_button("Sort: payback first" if upgrade_sort else "Sort: progression", _toggle_upgrade_sort))
	var upgrades: Array = DATA.UPGRADES.duplicate()
	upgrades.sort_custom(func(a,b):return int(a["rank"])<int(b["rank"]))
	if upgrade_sort:
		upgrades.sort_custom(func(a,b):
			var x: float=game.upgrade_payback(a["id"])
			var y: float=game.upgrade_payback(b["id"])
			return (x if x>0 else INF)<(y if y>0 else INF))
	var shown: int=0
	for upgrade in upgrades:
		var id: String = upgrade["id"]
		var bought: bool = game.state["upgrades"].has(id)
		var unlocked: bool = game.rank() >= int(upgrade["rank"])
		if upgrade_filter=="available" and (not unlocked or bought): continue
		if upgrade_filter=="owned" and not bought: continue
		shown+=1
		var cost: Dictionary = game._fixed_cost(upgrade["cost"])
		var card := _card(Color("#4f6a5e") if bought else Color("#393b48"))
		_asset_heading(card, upgrade["name"], "ACQUIRED" if bought else "RANK LOCKED" if not unlocked else "INVESTMENT", "check" if bought else "upgrades" if unlocked else "lock", GOOD if bought else WHITE if unlocked else MUTED)
		card.add_child(_label(upgrade["description"], 13, MUTED))
		if not unlocked: card.add_child(_label("Requires " + DATA.RANKS[int(upgrade["rank"])]["name"], 13, GOLD))
		if not bought:card.add_child(_label(game.costs_text(cost),13,GOLD))
		var button := _button("Acquired" if bought else "Invest in upgrade", _buy_upgrade.bind(id), not bought and unlocked and game.can_afford(cost))
		button.name = "Upgrade_" + id
		card.add_child(button)
		if not bought and unlocked:
			_track_affordability(button, cost)
			var payoff: float = game.upgrade_payback(id)
			if payoff > 0.0: card.add_child(_label("Coin payback ~" + _duration(payoff) + " at your current holdings", 12, BLUE))
			elif not upgrade["mods"].has("tap") and id not in ["trade_clerk","mutual_assurance","estate_steward"]:
				card.add_child(_label("Includes civic costs or output; compare the stated effects with your current production sources.", 12, BLUE))
			elif upgrade["mods"].has("tap"):
				var extra: float = float(game.tap_amount()["m"]) * pow(10.0, float(game.tap_amount()["e"])) * (float(upgrade["mods"]["tap"]) - 1.0)
				if extra > 0.0: card.add_child(_label("Pays back in ~%d WORK taps; passive income is unchanged" % int(ceil(float(upgrade["cost"]["coins"]) / extra)), 12, BLUE))

	if shown==0: content.add_child(_label("No upgrades in this view. Switch to All to inspect future unlocks.", 14, MUTED))

func _decisions_page() -> void:
	_page_intro("Wealth opens doors", "Trust earns rights. Ratified privileges change real costs, margins and commercial opportunities.")
	for p in ECON.PRIVILEGES:
		var owned: bool=ECON.has(game,p["id"])
		var card:=_card(GOOD if owned else Color("#655744"))
		_asset_heading(card,p["name"],("RATIFIED" if owned else "%s TRUST %d / 2" % [String(p["faction"]).to_upper(),int(game.state["activities"]["trust"][p["faction"]])]),"seal",GOOD if owned else GOLD)
		card.add_child(_label(p["effect"],13,GOOD))
		if not owned:
			card.add_child(_label(game.costs_text(game._fixed_cost(p["cost"])),13,GOLD))
			if not ECON.privilege_ready(game,p):card.add_child(_button("Build "+p["faction"]+" relations",_open_faction.bind(p["faction"])))
			var ratify:=_button("Ratify agreement",_ratify.bind(p["id"]),ECON.privilege_ready(game,p) and game.can_afford(game._fixed_cost(p["cost"])))
			ratify.name="Ratify_"+p["id"];card.add_child(ratify)
	content.add_child(_label("Strategic priorities",22,GOLD,true))
	for decision in DATA.DECISIONS:
		var unlocked: bool = game.rank() >= int(decision["rank"])
		var card := _card(Color("#655744"))
		_asset_heading(card, decision["title"], "STRATEGIC CROSSROADS", "decisions", GOLD)
		card.add_child(_label(decision["description"], 14, MUTED))
		if not unlocked:
			card.add_child(_label("Unlocks at " + DATA.RANKS[int(decision["rank"])]["name"], 14, GOLD))
			continue
		var chosen: String = game.state["decisions"].get(decision["id"], "")
		for option in decision["options"]:
			if chosen != "" and chosen != option["id"]: continue
			card.add_child(_label(option["title"] + (" · CHOSEN" if chosen == option["id"] else ""), 17, GOOD if chosen != "" else WHITE, true))
			card.add_child(_label(option["description"], 14, MUTED))
			if chosen == "":
				var cost: Dictionary = game._fixed_cost(option["cost"])
				var button := _button("Choose · " + game.costs_text(cost), _choose.bind(String(decision["id"]), String(option["id"])), game.can_afford(cost))
				button.name = "Choose_" + String(option["id"])
				card.add_child(button)
				_track_affordability(button, cost)

func _ascension_page() -> void:
	_page_intro("Claim your next life", "Milestones use lifetime earnings. Promotion never spends your resources.")
	var next: Dictionary = game.next_rank_data()
	var card := _card(GOLD if game.can_promote() else Color("#655744"))
	if next.is_empty():
		_asset_heading(card, "A name that will remain", "CHAPTER COMPLETE", "crown", GOLD)
		card.add_child(_label("Begin another life with a permanent +25% output per Legacy point. Legacy, achievements, discoveries and remembered status survive; enterprises, sector investments, agreements and choices reset.", 15))
		card.add_child(_button("BEGIN NEW LEGACY · +25% output", _show_legacy, true, true))
	else:
		_asset_heading(card, next["name"], "NEXT RANK · " + String(next["era"]).to_upper(), DATA.RANK_REWARDS[game.rank()+1]["icon"], GOLD)
		# Place the real action before all detailed requirements/roadmap: never buried.
		var expected_rank: int = game.rank()
		var ascend := _button("ASCEND NOW" if game.can_promote() else "Requirements not yet complete", _promote.bind(expected_rank), game.can_promote() and not game.persistence_blocked, true)
		ascend.name = "DetailAscendButton"
		card.add_child(ascend)
		var progress := ProgressBar.new()
		progress.custom_minimum_size.y = 7
		progress.show_percentage = false
		progress.add_theme_stylebox_override("background", _style(Color("#30323e"), Color.TRANSPARENT, 3))
		progress.add_theme_stylebox_override("fill", _style(GOLD, Color.TRANSPARENT, 3))
		card.add_child(progress)
		page_refresh.append(func():
			ascend.disabled = not game.can_promote() or promotion_busy or game.persistence_blocked
			ascend.text = "ASCEND NOW" if game.can_promote() else "Requirements not yet complete"
			progress.value = game.milestone_percent()
		)
		var lines: Array[Button] = []
		for condition in game.promotion_conditions():
			var label := _button("",_requirement_action.bind(String(condition["key"])))
			label.name="Requirement_"+condition["key"]
			card.add_child(label)
			lines.append(label)
		page_refresh.append(func():
			var conditions: Array[Dictionary] = game.promotion_conditions()
			for i in lines.size():
				lines[i].text = ("✓ " if conditions[i]["met"] else "○ ") + conditions[i]["description"]+("" if conditions[i]["met"] else "  ›")
				lines[i].add_theme_color_override("font_color", GOOD if conditions[i]["met"] else MUTED)
		)
		var eta := _label(game.milestone_eta(), 13, BLUE)
		card.add_child(eta)
		page_refresh.append(func(): eta.text=game.milestone_eta())
		for resource in ["reputation", "influence"]:
			card.add_child(_label(game.resource_path(resource), 13, MUTED))
		card.add_child(_label("ON ASCENSION", 12, GOLD))
		card.add_child(_label(DATA.RANK_REWARDS[game.rank()+1]["unlocks"], 14))
		card.add_child(_label(DATA.RANK_REWARDS[game.rank()+1]["benefit"], 14, GOOD))
	content.add_child(_label("The ascent of a name",24,GOLD,true))
	content.add_child(_label("Remembered status: "+DATA.RANKS[int(game.state["economy"]["highest_rank"])]["name"]+" · survives Legacy",13,BLUE))
	for i in DATA.RANKS.size():
		var row:=HBoxContainer.new();content.add_child(row)
		row.add_child(_icon(DATA.RANK_REWARDS[i]["icon"],38))
		var reached: bool=i<=game.rank()
		var state_name: String="NOW" if i==game.rank() else "EARNED" if reached else "NEXT" if i==game.rank()+1 else "FUTURE"
		var node:=_button("%02d  %s · %s" % [i+1,DATA.RANKS[i]["name"],state_name],_expand_rank.bind(i),true,i==game.rank())
		node.name="RankNode_"+str(i);row.add_child(node)
		if i==expanded_rank:
			content.add_child(_label(DATA.RANK_REWARDS[i]["narrative"],14,WHITE))
			content.add_child(_label(DATA.RANK_REWARDS[i]["unlocks"]+" "+DATA.RANK_REWARDS[i]["benefit"],13,BLUE))
		if i<DATA.RANKS.size()-1:
			var line:=ColorRect.new();line.color=GOOD.darkened(0.45) if reached else Color("#3d4656");line.custom_minimum_size=Vector2(2,8);line.size_flags_horizontal=Control.SIZE_SHRINK_CENTER;line.mouse_filter=Control.MOUSE_FILTER_IGNORE;content.add_child(line)
	content.add_child(_label("Discoveries that endure",22,GOLD,true))
	content.add_child(_label("Each discovery permanently multiplies all output by 1.03. Collected once; retained through every Legacy.",13,BLUE))
	for discovery in ECON.DISCOVERIES:
		var earned: bool=game.state["economy"]["discoveries"].has(discovery["id"])
		content.add_child(_label(("✦ " if earned else "◇ ")+discovery["name"]+" · "+("PERMANENT ×1.03" if earned else discovery["hint"]),14,GOOD if earned else MUTED))
	content.add_child(_button("Beyond the city · roadmap " + ("−" if show_future else "+"),_future))
	if show_future:
		content.add_child(_label("Survival → Commerce → Industry → Civic Power → Sovereignty → Planetary & Stellar Dominion → Universal Dominion → Divine & Metaphysical Power",14,BLUE))
		content.add_child(_label("Future Sovereignty hierarchy: Sovereign Ruler → Regional Overlord → Continental Unifier → Imperial Founder → Emperor → World Emperor. These are planned eras, not playable nodes in this chapter.",13,MUTED))

func _expand_rank(index: int) -> void:
	expanded_rank=-1 if expanded_rank==index else index;_render_page()
func _future() -> void:
	show_future=not show_future;_render_page()
func _open_faction(id: String) -> void:
	target_faction=id;venture_mode="talk";_select_tab(1)
	scroll_positions[1]=0
	_restore_scroll.call_deferred(0,page_generation)
func _requirement_action(key: String) -> void:
	if key.begins_with("gen_"):_focus_business(key.trim_prefix("gen_"))
	elif key=="choices":_select_tab(3)
	elif key=="reputation_total" and game.rank()<3:_open_faction("commons")
	elif key=="reputation_total":_focus_business("rumour_network")
	elif key=="influence_total":_focus_business("campaign_office")
	else:_focus_business("")

func _settings_page() -> void:
	_page_intro("The quiet chamber", "Your journey saves every 15 seconds, after important actions and when backgrounded.")
	var card := _card()
	_asset_heading(card, "Journey settings", "VERSION 0.4.0 · OFFLINE FIRST", "settings")
	pause_button = _button("Pause production", _toggle_pause)
	card.add_child(pause_button)
	card.add_child(_button("Save a checkpoint now", _save))
	var motion:=_button("Reduced motion: ON" if game.state["settings"]["reduced_motion"] else "Reduced motion: OFF",_reduced_motion)
	motion.name="ReducedMotion";card.add_child(motion)
	card.add_child(_label("Pause also suspends offline earnings. Offline production is capped at 8 hours at 75% efficiency.", 14, MUTED))
	card.add_child(_label("Legacy %d · +%d%% permanent output" % [int(game.state["legacy_points"]), int(game.state["legacy_points"])*25], 15, BLUE))
	card.add_child(_button("Reset all progress…", _confirm_reset))
	content.add_child(_label("Your chronicle", 23, GOLD, true))
	for entry in game.state["log"].slice(0, 12): content.add_child(_label("• " + str(entry), 13, MUTED))
	content.add_child(_label("Achievements", 23, GOLD, true))
	for achievement in DATA.ACHIEVEMENTS:
		content.add_child(_label(("✓ " if game.state["achievements"].has(achievement["id"]) else "○ ") + achievement["title"] + " · " + achievement["hint"], 13, MUTED))
	content.add_child(_button("Return to your empire", _select_tab.bind(0)))

func _select_tab(index: int) -> void:
	if promotion_busy: return
	scroller.set_process_internal(false) # Stop a previous page's touch inertia before switching.
	scroll_positions[current_tab] = scroller.scroll_vertical
	current_tab = index
	_render_all()
	_restore_scroll.call_deferred(int(scroll_positions.get(index, 0)), page_generation)

func _toggle_header() -> void:
	compact_header = not compact_header
	header_toggle.text = "Stats" if compact_header else "Close"
	_render_header()

func _on_goal() -> void:
	if promotion_busy: return
	if game.next_rank_data().is_empty(): _show_legacy()
	elif game.can_promote(): _promote(goal_rank)
	else: _select_tab(4)

func _promote(expected_rank: int = -1) -> void:
	if promotion_busy: return
	var previous: Dictionary = game.state.duplicate(true)
	if game.persistence_blocked:
		_notify("Saving is unavailable. Restore your save before ascending.", false)
		return
	if not game.promote(expected_rank):
		_notify("Complete every displayed requirement before ascending.", false)
		_refresh_live()
		return
	# Persist first. Never show a promotion that will silently vanish after restart.
	if not game.save_game():
		game.state = previous
		_notify("Could not save your ascension. Rank unchanged; check storage.", false)
		_render_all()
		return
	promotion_busy = true
	_save_notice()
	_render_all()
	_show_promotion()

func _show_promotion() -> void:
	for child in celebration_body.get_children():
		celebration_body.remove_child(child)
		child.queue_free()
	var reward: Dictionary = DATA.RANK_REWARDS[game.rank()]
	var vista := TextureRect.new()
	vista.texture=_era_texture(game.rank())
	vista.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
	vista.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_COVERED
	vista.custom_minimum_size.y=88
	vista.mouse_filter=Control.MOUSE_FILTER_IGNORE
	celebration_body.add_child(vista)
	var overline := _label("A S C E N S I O N", 12, GOLD)
	overline.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	celebration_body.add_child(overline)
	var title := _label(game.rank_name(), 30, GOLD, true)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	celebration_body.add_child(title)
	celebration_body.add_child(_label(reward["narrative"], 14))
	celebration_body.add_child(_label(reward["benefit"], 14, GOOD))
	celebration_body.add_child(_label("NEW OPPORTUNITIES\n" + reward["unlocks"], 14, BLUE))
	var next: Dictionary = game.next_rank_data()
	celebration_body.add_child(_label("Next: " + String(next.get("name", "Build a lasting Legacy")), 13, MUTED))
	var continue_button := _button("Continue your ascent", _dismiss_promotion, true, true)
	continue_button.name = "ContinueAscension"
	celebration_body.add_child(continue_button)
	# Give wrapping labels their final width before the first minimum-size pass.
	var width: float = minf(368.0, size.x-36.0)
	for child in celebration_body.get_children():
		if child is Label:
			child.custom_minimum_size.x = width-24.0
			child.size.x = width-24.0
	promotion_panel.size = Vector2(width, 0)
	promotion_overlay.show()
	_layout_promotion.call_deferred()
	promotion_overlay.modulate.a = 0.0
	if game.state["settings"]["reduced_motion"]:promotion_overlay.modulate.a=1.0
	else:create_tween().tween_property(promotion_overlay, "modulate:a", 1.0, 0.18)
	_notify("Ascension saved · " + game.rank_name())

func _layout_promotion() -> void:
	var width: float = minf(368.0, size.x-36.0)
	promotion_panel.size = Vector2(width, celebration_body.get_combined_minimum_size().y+24.0)
	promotion_panel.position = Vector2((size.x-promotion_panel.size.x)*0.5, maxf(12.0,(size.y-promotion_panel.size.y)*0.5))

func _dismiss_promotion() -> void:
	promotion_overlay.hide()
	promotion_busy = false
	# A new district and its income guide must not inherit the old page's deep scroll.
	current_tab = 0
	empire_mode="district"
	focused_business=""
	scroll_positions[0] = 0
	scroller.scroll_vertical = 0
	_render_all()

func _after_action(success: bool, failure_message: String = "Not enough resources or this action is still locked.") -> void:
	if success:
		_notify(str(game.state["log"][0]))
		_save()
	else: _notify(failure_message, false)
	_render_all()

func _on_work() -> void:
	game.work()
	_refresh_live()

func _buy_generator(id: String) -> void: _after_action(game.buy_generator(id))
func _buy_upgrade(id: String) -> void: _after_action(game.buy_upgrade(id))
func _choose(id: String, option: String) -> void: _after_action(game.choose(id, option))
func _on_campaign(target: String) -> void: _after_action(game.campaign(target))

func _show_legacy() -> void:
	if game.rank() < DATA.RANKS.size()-1: return
	legacy_confirmation.popup_centered(Vector2i(mini(360, int(size.x)-24), 0))

func _legacy_reset() -> void:
	_after_action(game.legacy_reset())
	current_tab = 0
	scroll_positions.clear()
	_render_all()

func _save() -> void:
	if game.save_game(): _save_notice()
	else:
		last_save_failed = true
		save_status.text = "Save failed"
		_notify("Progress is not saved. Check storage or restore a backup.", false)

func _save_notice() -> void:
	save_notice_seconds = 2.0
	last_save_failed = false
	save_status.text = "✓ Saved"
	save_status.add_theme_color_override("font_color", GOOD)

func _notify(message: String, success: bool = true) -> void:
	feedback.text = message
	feedback.add_theme_color_override("font_color", GOOD if success else RED)
	feedback_seconds = 5.0

func _toggle_pause() -> void:
	game.state["paused"] = not bool(game.state["paused"])
	_save()
	_notify("Production paused, including offline income." if game.state["paused"] else "Production resumed.")
	_refresh_live()

func _confirm_reset() -> void:
	reset_confirmation.popup_centered(Vector2i(mini(360, int(size.x)-24), 0))

func _reset_all() -> void:
	var backup: String = game.save_path + ".before-reset-" + str(int(Time.get_unix_time_from_system())) + ".json"
	if FileAccess.file_exists(game.save_path):
		if DirAccess.copy_absolute(ProjectSettings.globalize_path(game.save_path), ProjectSettings.globalize_path(backup)) != OK:
			_notify("Could not create a reset backup. Progress preserved.", false)
			return
	game.new_game()
	game.save_game()
	current_tab = 0
	scroll_positions.clear()
	_notify("A new journey begins. Previous save backed up locally.")
	_render_all()

func _track_affordability(button: Button, cost: Dictionary) -> void:
	page_refresh.append(func(): button.disabled = not game.can_afford(cost))

func _duration(seconds: float) -> String:
	if seconds < 60.0: return "%ds" % int(ceil(seconds))
	if seconds < 3600.0: return "%dm %ds" % [int(seconds)/60, int(seconds)%60]
	return "%.1fh" % (seconds/3600.0)

func _apply_safe_area() -> void:
	if outer_margin == null: return
	var inset := Vector4(0, 0, 0, 0)
	if OS.get_name() == "Android":
		var safe: Rect2i = DisplayServer.get_display_safe_area()
		var screen: Vector2i = DisplayServer.screen_get_size()
		if screen.x > 0 and screen.y > 0 and safe.size.x > 0:
			var ratio := Vector2(size) / Vector2(screen)
			inset = Vector4(safe.position.x*ratio.x, safe.position.y*ratio.y, (screen.x-safe.end.x)*ratio.x, (screen.y-safe.end.y)*ratio.y)
	outer_margin.add_theme_constant_override("margin_left", 12 + int(inset.x))
	outer_margin.add_theme_constant_override("margin_top", 10 + int(inset.y))
	outer_margin.add_theme_constant_override("margin_right", 12 + int(inset.z))
	outer_margin.add_theme_constant_override("margin_bottom", 8 + int(inset.w))
	if promotion_panel != null: promotion_panel.custom_minimum_size.x = minf(368.0, maxf(280.0, size.x-36.0))

func _world_panel() -> void:
	var world:=WorldView.new()
	world.configure(game)
	world.business_selected.connect(_focus_business)
	content.add_child(world)

func _resource_guide(resource: String,id: String) -> void:
	var card := _card(GOLD)
	card.add_child(_label("Start your "+resource+" income",19,GOLD,true))
	card.add_child(_label(game.resource_path(resource),13))
	for gen in DATA.GENERATORS:
		if gen["id"]==id:
			var cost: Dictionary=game.generator_cost(gen)
			card.add_child(_label("Investment: "+game.costs_text(cost),13,GOLD))
			var button:=_button("Build "+gen["name"],_buy_generator.bind(id),game.can_afford(cost))
			button.name="Guide_"+id
			card.add_child(button)
			_track_affordability(button,cost)

func _set_upgrade_filter(mode: String) -> void:
	upgrade_filter=mode
	scroller.scroll_vertical=0
	_render_page()
func _toggle_upgrade_sort() -> void:
	upgrade_sort=not upgrade_sort
	_render_page()
func _set_venture_mode(mode: String) -> void:
	venture_mode=mode
	scroller.scroll_vertical=0
	_render_page()
func _set_trade_route(route: String) -> void:
	trade_route=route
	_render_page()
func _set_trade_lots(lots: int) -> void:
	trade_lots=lots
	_render_page()
func _dispatch_trade(id: String,serial: int,quote: Dictionary={}) -> void:
	_after_action(ACT.start_trade(game,id,trade_route,trade_lots,serial,quote),"Terms changed, capacity is full or capital is missing. Review the current quote.")
func _repeat_trade(serial: int) -> void:
	_after_action(ACT.toggle_repeat(game,serial))
func _begin_talk(faction: String) -> void:
	_after_action(ACT.begin_talk(game,faction),"Your delegates are resting, talks are already active, or production is paused.")
func _respond_talk(id: String,round_expected: int,serial: int) -> void:
	_after_action(ACT.respond(game,id,round_expected,serial),"That round has ended, funds are missing, or production is paused.")

func _ventures_page() -> void:
	_page_intro("Fortune favours a choice", "Commit capital. Read the room. Build relationships that compound.")
	var tabs := HBoxContainer.new()
	content.add_child(tabs)
	var trade:=_button("Trade desk",_set_venture_mode.bind("trade"),true,venture_mode=="trade")
	trade.name="TradeDesk";tabs.add_child(trade)
	var diplomacy:=_button("Negotiate",_set_venture_mode.bind("talk"),true,venture_mode=="talk")
	diplomacy.name="DiplomacyDesk";tabs.add_child(diplomacy)
	if venture_mode=="talk":_negotiation_page()
	else:_trade_page()

func _trade_page() -> void:
	var a: Dictionary=game.state["activities"]
	if game.rank()<1:
		content.add_child(_label("Reach Street Scavenger to open a salvage route.",15,GOLD))
		return
	trade_lots=mini(trade_lots,ACT.lots_limit(game))
	content.add_child(_label("%d / %d routes sailing · %d deliveries" % [a["orders"].size(),ACT.capacity(game),int(a["completed"])],14,GOLD))
	for order in a["orders"]:
		var card:=_card(Color("#59626d"))
		_asset_heading(card,ACT.definition(order["id"])["name"],"UNDER WAY · %d LOTS · %s" % [int(order["lots"]),String(order["route"]).to_upper()],"routes",GOLD)
		var timer:=_label("",14,GOOD)
		card.add_child(timer)
		var progress:=ProgressBar.new()
		progress.show_percentage=false;progress.custom_minimum_size.y=8
		card.add_child(progress)
		page_refresh.append(func():
			timer.text=("Paused · " if game.state["paused"] else "Delivery in ")+_duration(float(order["remaining"]))
			progress.value=100.0*(1.0-float(order["remaining"])/float(order["duration"]))
		)
		card.add_child(_label("Capital committed: "+BN.pretty(order["cost"])+" coins. Arrival settles automatically.",12,MUTED))
		if game.state["upgrades"].has("trade_clerk"):
			var repeat_button:=_button("Auto-repeat: ON" if order["repeat"] else "Auto-repeat: OFF",_repeat_trade.bind(int(order["serial"])))
			repeat_button.name="Repeat_"+str(order["serial"])
			card.add_child(repeat_button)
	var routes:=HBoxContainer.new()
	content.add_child(routes)
	routes.add_child(_button("Safe passage",_set_trade_route.bind("safe"),true,trade_route=="safe"))
	routes.add_child(_button("Risky shortcut",_set_trade_route.bind("venture"),true,trade_route=="venture"))
	if ACT.lots_limit(game)>1:
		var lots:=GridContainer.new();lots.columns=2;content.add_child(lots)
		for count in [1,5,20,100]:
			if count<=ACT.lots_limit(game):lots.add_child(_button("×%d lots" % count,_set_trade_lots.bind(count),true,count==trade_lots))
	content.add_child(_label("Safe: guaranteed delivery. Shortcut: faster, double profit but half civic rewards on success; on failure lose 15% capital unless insured; rewards are lost. Quotes scale with businesses and freeze at dispatch.",12,MUTED))
	for offer in ACT.OFFERS:
		if game.rank()<int(offer["rank"]):continue
		var q: Dictionary=ACT.quote(game,offer["id"],trade_route,trade_lots)
		var card:=_card()
		_asset_heading(card,offer["name"],"%s · %d LOTS" % [_duration(q["duration"]),trade_lots],"routes")
		card.add_child(_label(offer["story"],13,MUTED))
		card.add_child(_label("Linked sector: "+ECON.contract_sector(offer["id"])+" · capacity %d" % ECON.capacity(game),12,BLUE))
		card.add_child(_label("Profit "+BN.pretty(q["profit"])+" coins · "+BN.pretty(q["reputation"])+" reputation · "+BN.pretty(q["influence"])+" influence",13,GOOD))
		if float(q["risk"])>0:
			var expected: Dictionary=BN.subtract(BN.times(q["profit"],1.0-float(q["risk"])),BN.times(q["cost"],float(q["risk"])*(0.0 if q["insured"] else 0.15)))
			card.add_child(_label("%.0f%% failure risk · expected net %s coins (not guaranteed)" % [float(q["risk"])*100.0,BN.pretty(expected)],12,BLUE))
		var serial: int=int(a["serial"])
		var button:=_button("Dispatch · "+BN.pretty(q["cost"])+" coins",_dispatch_trade.bind(String(offer["id"]),serial,q))
		button.name="Dispatch_"+offer["id"]
		card.add_child(button)
		page_refresh.append(func():button.disabled=game.state["paused"] or game.persistence_blocked or a["orders"].size()>=ACT.capacity(game) or not game.can_afford({"coins":q["cost"]}))
	content.add_child(_label("Trade chronicle",21,GOLD,true))
	content.add_child(_label(a["report"],14))
	content.add_child(_label("Offline: up to 8h at 75% speed. Auto-repeat unlocks with the Guildmaster's Trade Clerk. Delegation protects capital and uses safe passage for repeats. Capacity, trust or charter unlock larger shipments.",12,MUTED))

func _negotiation_page() -> void:
	var a: Dictionary=game.state["activities"]
	var n: Dictionary=a["negotiation"]
	if not n.is_empty():
		var card:=_card(GOLD)
		_asset_heading(card,"At the bargaining table","ROUND %d / 3 · %s" % [int(n["round"])+1,String(n["faction"]).capitalize()],"decisions",GOLD)
		card.add_child(_label("Agreement %d / 6 · tension %d / 3" % [int(n["score"]),int(n["tension"])],16,GOOD))
		card.add_child(_label(ACT.PROMPTS[ACT.talk_need(game)],15))
		card.add_child(_label("Reach 6 agreement in three rounds. Tension 3 ends talks without a reward. A cordial 3–5 earns 25% rewards without trust.",12,MUTED))
		for option in ACT.talk_options(game):
			card.add_child(_label("+%d agreement · %+d tension · %s" % [int(option["score"]),int(option["tension"]),"no cost" if option["cost"].is_empty() else game.costs_text(option["cost"])],12,BLUE))
			var button:=_button(option["title"],_respond_talk.bind(String(option["id"]),int(n["round"]),int(n["serial"])),not game.state["paused"] and game.can_afford(option["cost"]))
			button.name="Talk_"+option["id"]
			card.add_child(button)
		return
	var cooldown:=_label("",13,GOLD);content.add_child(cooldown)
	page_refresh.append(func():cooldown.text="Delegates ready" if float(a["cooldown"])<=0 else "Delegates resting · "+_duration(float(a["cooldown"])))
	var factions: Array=ACT.FACTIONS.duplicate()
	if not target_faction.is_empty():factions.sort_custom(func(a,b):return a["id"]==target_faction and b["id"]!=target_faction)
	for faction in factions:
		var card:=_card()
		_asset_heading(card,faction["name"],"TRUST %d / 5" % int(a["trust"][faction["id"]]),"decisions")
		card.add_child(_label(faction["scene"],13,MUTED))
		card.add_child(_label(faction["trait"],13,GOOD))
		card.add_child(_label("Full accord: "+game.costs_text(ACT.talk_reward(game,faction["id"]))+". Three rounds; concessions cost coins.",12,BLUE))
		var unlocked: bool=game.rank()>=int(faction["rank"])
		var button:=_button("Open negotiations" if unlocked else "Unlocks at "+DATA.RANKS[int(faction["rank"])]["name"],_begin_talk.bind(String(faction["id"])),unlocked)
		button.name="Negotiate_"+faction["id"]
		card.add_child(button)
		page_refresh.append(func():button.disabled=not unlocked or game.state["paused"] or game.persistence_blocked or float(a["cooldown"])>0.001)
	content.add_child(_label(a["report"],14,GOLD))

func _scroll_status(value: float) -> void:
	if not compact_header and value > previous_scroll+12.0:
		compact_header=true
		header_toggle.text="Stats"
		_render_header()
	previous_scroll=value

func _era_texture(rank_value: int) -> AtlasTexture:
	var texture:=AtlasTexture.new()
	texture.atlas=preload("res://assets/world/living-districts.png")
	var side: float=texture.atlas.get_width()/2.0
	var index: int=0 if rank_value<2 else 1 if rank_value<4 else 2 if rank_value<5 else 3
	texture.region=Rect2((index%2)*side,(index/2)*side,side,side)
	return texture

func _reduced_motion() -> void:
	game.state["settings"]["reduced_motion"]=not game.state["settings"]["reduced_motion"];_save();_render_page()
