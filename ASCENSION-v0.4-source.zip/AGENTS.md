# Codex agent instructions — ASCENSION

This repository is a Godot 4.x GDScript idle/incremental Android game. Work on the existing files, **do not start a replacement project**.

## Immediate priorities
1. Open/import the Godot project, compile it and fix every GDScript parse or runtime error. Current source was statically inspected but never executed in Godot. Record the exact Godot version used.
2. Run `godot --headless --path . --editor --quit` and then `godot --headless --path . --script res://tests/smoke_tests.gd`. Fix failures, and add regression tests for any bugs found.
3. Run the main scene and interact with its controls. Verify a new player can purchase a Street Stall, automate coins, buy upgrades, unlock decisions, promote ranks, save/reload, and claim bounded offline rewards.
4. Perform deterministic balance simulations at 5/20/45/120/1440 minutes for economy-heavy and influence-heavy play. Rebalance based on measured outcomes. Verify meaningful choices and no unavoidable dead ends.
5. Export a real Android **debug APK** if the host has Android SDK, Java, matching Godot export templates and signing tools. Inspect APK metadata/size. If impossible, document exactly what is missing, without claiming an APK was built.

## Product decisions
- Keep portrait, offline-first, no ads or in-app purchases, no proprietary dependencies.
- The delivered first chapter is Survival → Enterprise → Local Influence (seven ranks). Later monarchy, planetary, galactic and divine gameplay is only planned.
- Preserve compounding growth plus resource trade-offs: coins, reputation, influence, generators, upgrades, and exclusive decisions. Each new era must unlock mechanics, not merely larger figures.
- Upgrade the existing UI to a premium and legible mobile experience, not a static mock-up.
- Do not silently delete user save data or prestige progress. Keep save migrations/versioning in mind.
- Do not mark tests as run, performance verified, APK exported, or device playtested unless the specific action actually succeeded.

## Files
- Gameplay: `scripts/game.gd`, `scripts/content.gd`, `scripts/big_number.gd`
- UI: `scripts/main.gd`, `scenes/main.tscn`
- Tests: `tests/smoke_tests.gd`, `tests/static_review.py`
- User's vision and targets: `docs/ASCENSION_Codex_Build_Brief.md`
- Progress and known limitations: `docs/DEVELOPMENT_LOG.md`

First give a brief report on the project's current build/test state, then **work through the above priorities**, making real code and build changes. Ask the user only for a blocker that cannot be resolved from the local environment.
