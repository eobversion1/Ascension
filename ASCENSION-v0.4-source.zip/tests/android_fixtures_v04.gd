## Explicit emulator-only state fixtures and offline oracle; not a fresh-player playthrough.
extends SceneTree
const G=preload("res://scripts/game.gd")
const A=preload("res://scripts/activities.gd")
const E=preload("res://scripts/economy.gd")
const BN=preload("res://scripts/big_number.gd")
func write(name: String,state: Dictionary) -> void:
 var f=FileAccess.open("res://tests/results/v04/fixture-"+name+".json",FileAccess.WRITE)
 f.store_string(JSON.stringify(state,"  "));f.close()
func _initialize() -> void:
 var g=G.new();g.state["rank"]=4;g.gain("coins",BN.of(10000))
 g.state["upgrades"]["trade_clerk"]=true
 g.check_achievements()
 A.start_trade(g,"salvage","safe",1);A.toggle_repeat(g,1)
 write("offline",g.state)
 g.tick(28800,0.75);write("offline-expected",g.state)
 g=G.new();g.state["rank"]=6;g.state["legacy_points"]=2;g.state["completed_runs"]=2
 g.gain("coins",BN.of(1000000));g.gain("reputation",BN.of(10000));g.gain("influence",BN.of(1000))
 g.state["generators"]={"street_stall":25,"workshop":20,"trading_post":20,"campaign_office":1}
 g.state["activities"]["trust"]={"merchants":2,"commons":2,"council":2}
 E.invest(g,"craft");E.ratify(g,"city_charter");g.buy_upgrade("estate_steward")
 g.check_achievements();A.start_trade(g,"envoy","safe",1);A.begin_talk(g,"council");A.respond(g,"concede")
 write("legacy",g.state)
 print("Wrote explicit offline oracle and late-chapter fixture.");quit()
