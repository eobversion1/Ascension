extends "res://tests/ui_tests.gd"
const E=preload("res://scripts/economy.gd")
const A=preload("res://scripts/activities.gd")
const D=preload("res://scripts/content.gd")
func run() -> void:
 root.size=Vector2i(420,820);root.content_scale_size=root.size
 ui=Main.instantiate();root.add_child(ui);await settle();ui.set_process(false)
 ui.game.save_path="user://v04-economy-ui.json";ui.game.backup_path="user://v04-economy-ui.bak.json"
 ui.game.new_game();ui.game.state["rank"]=3
 for r in D.RESOURCES:ui.game.gain(r,BN.of(1000000))
 ui.game.state["generators"]={"street_stall":3,"workshop":2,"trading_post":2}
 ui.game.check_achievements();ui._render_all();await settle()
 await shot("10-living-district")
 await click(named("World_workshop"))
 expect(ui.empire_mode=="businesses" and ui.focused_business=="workshop","World building opens contextual business management")
 var capacity: int=E.capacity(ui.game)
 await click(named("Buy_workshop"))
 expect(ui.game.own("workshop")==3 and E.capacity(ui.game)>capacity,"Context investment changes ownership and productive capacity")
 await shot("11-business-operating-statement")
 await click(named("Empire_sectors"))
 var rate: Dictionary=ui.game.income_of("coins")
 await click(named("Sector_craft"))
 expect(ui.game.state["economy"]["sectors"]["craft"]==1 and BN.compare(ui.game.income_of("coins"),rate)>0,"Sector control compounds actual income")
 await shot("12-sector-investment")
 await click(ui.nav_buttons[2]);await click(named("Upgrade_supply_chain"))
 expect(ui.game.state["upgrades"].has("supply_chain"),"Connected upgrade purchased by real pointer")
 await click(ui.nav_buttons[1]);await click(named("Dispatch_relief"))
 var order: Dictionary=ui.game.state["activities"]["orders"][0].duplicate(true)
 expect(order["sector"]=="craft" and order["capacity"]==E.capacity(ui.game),"Dispatch uses real sector and owned capacity")
 ui.game.tick(90);ui._render_all();await settle()
 expect(ui.game.state["activities"]["completed"]==1,"Integrated contract settles")
 # Cross-screen links must override the old tab's deferred scroll restoration.
 ui.scroller.scroll_vertical=10000;await settle()
 await click(ui.nav_buttons[3]);ui._open_faction("merchants");await settle()
 expect(ui.scroller.scroll_vertical==0,"Faction link resets a previously long-scrolled Ventures page")
 expect(ui.scroller.get_global_rect().intersects(named("Negotiate_merchants").get_global_rect()),"Linked faction is visible before any click helper scrolls to it")
 for session in 2:
  ui.game.tick(120);ui._open_faction("merchants");await settle()
  await click(named("Negotiate_merchants"))
  for round_index in 3:
   var need: String=A.talk_need(ui.game)
   await click(named("Talk_"+("bargain" if need=="profit" else "listen" if need=="recognition" else "concede")))
 expect(ui.game.state["activities"]["trust"]["merchants"]==2,"Two rendered-control negotiation sequences earn ratification trust")
 await click(ui.nav_buttons[3]);await shot("13-earned-trading-rights")
 var cost: Dictionary=ui.game.generator_cost(D.GENERATORS[0])["coins"]
 await click(named("Ratify_open_passage"))
 expect(E.has(ui.game,"open_passage") and BN.compare(ui.game.generator_cost(D.GENERATORS[0])["coins"],cost)<0,"Ratification control lowers real investment cost")
 expect(ui.game.state["economy"]["discoveries"].has("integration"),"Interactive economic chain earns a permanent discovery")
 # An explicit missing-asset fixture tests actionable requirement navigation.
 ui.game.state["generators"]["trading_post"]=0
 await click(ui.nav_buttons[4]);await click(named("Requirement_gen_trading_post"))
 expect(ui.current_tab==0 and ui.focused_business=="trading_post","Incomplete requirement navigates to correct business")
 await click(named("Buy_trading_post"));await click(named("Buy_trading_post"))
 await click(ui.goal_button);expect(ui.game.rank()==4,"Connected investment fulfils original Guildmaster gate")
 await click(named("ContinueAscension"));expect(ui.empire_mode=="district","Promotion returns to new world")
 await shot("14-guild-district")
 ui.game.state["rank"]=5;ui.game.check_achievements();await click(ui.nav_buttons[2]);await click(named("Upgrade_estate_steward"))
 await click(ui.nav_buttons[0]);await click(named("Empire_sectors"));await click(named("StewardToggle"))
 expect(ui.game.state["economy"]["steward"],"Steward is actually enabled through input")
 var levels_before: int=0
 for v in ui.game.state["economy"]["sectors"].values():levels_before+=int(v)
 ui.game.tick(121)
 var levels_after: int=0
 for v in ui.game.state["economy"]["sectors"].values():levels_after+=int(v)
 expect(levels_after>levels_before,"Enabled steward purchases real development")
 ui._select_tab(5);await settle();await click(named("ReducedMotion"))
 expect(ui.game.state["settings"]["reduced_motion"],"Reduced motion preference works")
 await click(ui.nav_buttons[0]);await click(named("Empire_district"))
 expect(not ui.find_child("LivingDistrict",true,false).is_processing(),"Reduced motion disables environmental animation processing")
 # Explicit high-capacity fixture exposes all four shipment controls on a narrow screen.
 ui.game.state["generators"]["street_stall"]=60;ui.game.state["generators"]["workshop"]=20;ui.game.state["generators"]["trading_post"]=20
 ui.game.state["economy"]["privileges"]["city_charter"]=true
 root.size=Vector2i(360,640);root.content_scale_size=root.size
 ui.venture_mode="trade";await click(ui.nav_buttons[1]);await click(prefixed("×100 lots"))
 expect(ui.trade_lots==100,"Largest unlocked shipment can be selected on a narrow portrait screen")
 await click(named("Dispatch_caravan"))
 expect(ui.game.state["activities"]["orders"][0]["lots"]==100,"100-lot control commits an actual scaled contract")
 for viewport_size in [Vector2i(360,640),Vector2i(360,800),Vector2i(420,1000)]:
  root.size=viewport_size;root.content_scale_size=viewport_size;await settle()
  for mode in ["district","businesses","sectors"]:
   ui._empire_mode(mode);await settle()
   for b in ui.find_children("*","Button",true,false):
    if not b.is_visible_in_tree() or b.get_parent() is Window:continue
    expect(b.size.y>=48,"Living economy maintains 48px touch height")
    expect(b.get_global_rect().end.x<=ui.size.x+1,"Living economy fits narrow width")
  ui.expanded_rank=-1;await click(ui.nav_buttons[4]);await click(named("RankNode_5"))
  expect(ui.expanded_rank==5,"Advancement node expands its actual unlocks")
  await shot("tree-%dx%d" % [viewport_size.x,viewport_size.y])
  await click(ui.nav_buttons[0]);await click(named("Empire_district"));await shot("world-%dx%d" % [viewport_size.x,viewport_size.y])
 ui.game.save_game()
 var restored=load("res://scripts/game.gd").new();restored.save_path=ui.game.save_path;restored.backup_path=ui.game.backup_path;restored.load_or_new()
 expect(restored.state["economy"]["privileges"].has("open_passage") and restored.state["economy"]["discoveries"].has("integration") and restored.state["settings"]["reduced_motion"],"UI-earned rights, discoveries and settings survive restart")
 for path in [ui.game.save_path,ui.game.backup_path]:
  if FileAccess.file_exists(path):DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
 ui.queue_free();await process_frame
 for failure in failures:push_error(failure)
 print("%s: %d living-economy UI checks; %d failures." % ["PASS" if failures.is_empty() else "FAIL",checks,failures.size()])
 quit(0 if failures.is_empty() else 1)
