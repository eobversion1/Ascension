"""Environment-independent structural sanity checks; NOT a Godot parser/runtime."""
from pathlib import Path
import re
import math

ROOT=Path(__file__).resolve().parents[1]
content=(ROOT/'scripts/content.gd').read_text()
game=(ROOT/'scripts/game.gd').read_text()
main=(ROOT/'scripts/main.gd').read_text()
for f in ['project.godot','scenes/main.tscn','scripts/big_number.gd','scripts/content.gd','scripts/game.gd','scripts/main.gd','tests/smoke_tests.gd']:
    assert (ROOT/f).is_file(), f'Missing {f}'
assert content.count('"id":"') >= 30, 'Insufficient defined content'
assert len(re.findall(r'"description":',content)) >= 22
assert content.count('"options":[') == 4, 'Four meaningful decisions needed'
assert all(s in game for s in ['income_rates','load_or_new','save_game','legacy_reset','check_achievements','OFFLINE_LIMIT_SECONDS'])
assert all(s in main for s in ['_empire_page','_upgrades_page','_decisions_page','_ascension_page'])
assert math.isfinite(2400 * math.pow(1.19,10)), 'Basic pricing'
print('PASS: Structural files/content check only. Run Godot tests for runtime verification.')
