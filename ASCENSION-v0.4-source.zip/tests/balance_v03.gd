## Actual economy, deterministic 15-second visits. Only the first 15 coins are tapped.
## Two policies value production differently and select opposite strategic decisions.
extends SceneTree
const Game = preload("res://scripts/game.gd")
const DATA = preload("res://scripts/content.gd")
const ACT = preload("res://scripts/activities.gd")
const BN = preload("res://scripts/big_number.gd")
const CHECKPOINTS = [300, 1200, 2700, 7200, 86400]
var failures: Array[String] = []

func _initialize() -> void:
	var report: Dictionary = {"engine": Engine.get_version_info()["string"], "step_seconds":15, "initial_taps":15, "profiles":{}}
	for profile in ["economy", "influence", "economy_engaged", "influence_engaged"]:
		report["profiles"][profile] = simulate(profile)
	var path: String = "res://tests/results/v03/balance.json"
	if OS.get_cmdline_user_args().size() > 0:
		path = OS.get_cmdline_user_args()[0]
	var file := FileAccess.open(path, FileAccess.WRITE)
	file.store_string(JSON.stringify(report, "  "))
	file.close()
	print(JSON.stringify(report, "  "))
	for failure in failures:
		push_error(failure)
	quit(0 if failures.is_empty() else 1)

func number(value: Dictionary) -> float:
	return float(value["m"]) * pow(10.0, float(value["e"]))

func value(bag: Dictionary, weights: Dictionary) -> float:
	var result: float = 0.0
	for r in bag:
		result += number(bag[r]) * float(weights.get(r, 1.0))
	return result

func simulate(profile: String) -> Dictionary:
	var g = Game.new()
	for i in 15:
		g.work()
	assert(g.buy_generator("street_stall"))
	var weights: Dictionary = {"coins":1.0, "reputation":100.0, "influence":1000.0} if profile.begins_with("economy") else {"coins":1.0, "reputation":120.0, "influence":1600.0}
	var choices: Array = ["profit", "independent", "factories", "establishment"] if profile.begins_with("economy") else ["patrons", "coalition", "housing", "grassroots"]
	var milestones: Dictionary = {}
	var snapshots: Dictionary = {}
	var duration: int = 86400
	if OS.get_cmdline_user_args().size() > 1: duration = int(OS.get_cmdline_user_args()[1])
	for seconds in range(15, duration + 1, 15):
		g.tick(15.0)
		while g.can_promote():
			g.promote()
			milestones[g.rank_name()] = seconds
		# A visit allows up to three purchases; no free resources, conversions or resets.
		for action in 3:
			for index in DATA.DECISIONS.size():
				g.choose(String(DATA.DECISIONS[index]["id"]), choices[index])
			var target: String = ""
			var upgrade_target: bool = false
			var best: float = INF
			var before: float = value(g.income_rates(), weights)
			for gen in DATA.GENERATORS:
				var id: String = gen["id"]
				if g.rank() < int(gen["rank"]): continue
				var cost: Dictionary = g.generator_cost(gen)
				# Ensure currencies and required assets can never be starved by a pure ROI policy.
				var required: bool = (id == "street_stall" and g.own(id) < 3) or (id == "workshop" and g.own(id) < 2) or (id == "trading_post" and g.own(id) < (5 if g.rank() >= 4 else 2)) or (id == "rumour_network" and g.own(id) < 1) or (id == "campaign_office" and g.own(id) < 1)
				g.state["generators"][id] = g.own(id) + 1
				var improvement: float = value(g.income_rates(), weights) - before
				g.state["generators"][id] = g.own(id) - 1
				var score: float = value(cost, weights) / maxf(0.001, improvement)
				if required: score *= 0.1
				if score < best:
					best = score
					target = id
					upgrade_target = false
			for u in DATA.UPGRADES:
				var id: String = u["id"]
				if g.rank() < int(u["rank"]) or g.state["upgrades"].has(id): continue
				g.state["upgrades"][id] = true
				var improvement: float = value(g.income_rates(), weights) - before
				g.state["upgrades"].erase(id)
				if improvement <= 0.0: continue
				var score: float = value(g._fixed_cost(u["cost"]), weights) / improvement
				if score < best:
					best = score
					target = id
					upgrade_target = true
			if upgrade_target: g.buy_upgrade(target)
			else: g.buy_generator(target)
		if profile.ends_with("engaged"): manage_activities(g, profile)
		if seconds in CHECKPOINTS:
			snapshots[str(seconds / 60)] = {"rank":g.rank_name(), "coins_earned":number(g.total("coins")), "reputation_earned":number(g.total("reputation")), "influence_earned":number(g.total("influence")), "income":g.income_rates(), "generators":g.state["generators"].duplicate(), "decisions":g.state["decisions"].duplicate(), "deliveries":g.state["activities"]["completed"], "negotiations":g.state["activities"]["talks"], "trust":g.state["activities"]["trust"].duplicate()}
			for r in DATA.RESOURCES:
				if not BN.valid(g.resource(r)): failures.append("Invalid balance: " + profile)
	if not milestones.has("Civic Leader"):
		failures.append(profile + " failed to complete chapter")
	return {"milestones_seconds":milestones, "checkpoints_minutes":snapshots}

func manage_activities(g, profile: String) -> void:
	var a: Dictionary = g.state["activities"]
	var commercial: bool=profile.begins_with("economy")
	if g.rank()>=2 and float(a["cooldown"])<=0.001:
		var faction: String="merchants" if commercial else "commons"
		if int(a["trust"][faction])>=5: faction="council" if g.rank()>=4 else "commons" if commercial else "merchants"
		ACT.begin_talk(g,faction)
		for round_index in 3:
			if a["negotiation"].is_empty():break
			var need: String=ACT.talk_need(g)
			var action: String="concede" if need=="security" else "bargain" if need=="profit" else "listen"
			if not ACT.respond(g,action):ACT.respond(g,"listen")
	if g.rank()>=4:g.buy_upgrade("trade_clerk")
	var offer_id: String="salvage" if g.rank()==1 else "provisions" if g.rank()==2 else "caravan" if commercial else "relief"
	if g.rank()>=4:offer_id="charter"
	if g.rank()>=5 and not commercial:offer_id="envoy"
	if g.rank()<1:return
	var lots: int=5 if g.rank()>=3 else 1
	# Reserve half the wallet for permanent assets; activity capital competes for funds.
	var q: Dictionary=ACT.quote(g,offer_id,"safe",lots)
	if not q.is_empty() and BN.compare(g.resource("coins"),BN.times(q["cost"],2))>=0:
		ACT.start_trade(g,offer_id,"safe",lots)
	for order in a["orders"]:
		if not order["repeat"] and g.state["upgrades"].has("trade_clerk"):ACT.toggle_repeat(g,int(order["serial"]))
