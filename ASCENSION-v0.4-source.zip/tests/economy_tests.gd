extends SceneTree
const G=preload("res://scripts/game.gd")
const E=preload("res://scripts/economy.gd")
const A=preload("res://scripts/activities.gd")
const D=preload("res://scripts/content.gd")
const BN=preload("res://scripts/big_number.gd")
var checks: int=0
var failures: Array[String]=[]
func expect(ok: bool,msg: String) -> void:
 checks+=1
 if not ok:failures.append(msg)
func number(v: Dictionary) -> float:return v["m"]*pow(10.0,v["e"])
func funded(r: int=4):
 var g=G.new();g.state["rank"]=r;g.gain("coins",BN.of(1e7));g.gain("reputation",BN.of(1e5));g.gain("influence",BN.of(1000));return g
func accord(g,faction: String) -> void:
 g.tick(120)
 expect(A.begin_talk(g,faction),"Begin paid faction negotiation")
 for i in 3:expect(A.respond(g,"concede"),"Concession changes round")
func write(path: String,state: Dictionary) -> void:
 var f=FileAccess.open(path,FileAccess.WRITE);f.store_string(JSON.stringify(state));f.close()
func _initialize() -> void:
 seed(404)
 var g=G.new()
 expect(E.valid(g.state["economy"]),"Fresh living economy validates")
 expect(not E.invest(g,"retail") and not E.ratify(g,"open_passage"),"New player cannot bypass economic gates")
 # Complete business → upgrade → capacity → venture → relationships → privilege → advancement chain.
 g=funded(3)
 g.state["totals"]["reputation"]=BN.zero()
 expect(g.buy_generator("street_stall"),"Business purchased")
 var before: Dictionary=g.income_of("coins")
 var q_before: Dictionary=A.quote(g,"relief","safe",1)
 expect(g.buy_generator("workshop"),"Workshop joins the supply chain")
 expect(BN.compare(g.income_of("coins"),before)>0,"Workshop increases actual production")
 expect(BN.compare(A.quote(g,"relief","safe",1)["profit"],q_before["profit"])>0,"Ownership improves contract opportunity")
 var capacity_before: int=E.capacity(g)
 q_before=A.quote(g,"relief","safe",1)
 expect(g.buy_upgrade("sturdy_tools"),"Productive upgrade purchased")
 expect(E.capacity(g)>capacity_before,"Tools expand real productive capacity")
 expect(not A.start_trade(g,"relief","safe",1,-1,q_before),"A stale displayed quote cannot silently charge changed terms")
 expect(BN.compare(A.quote(g,"relief","safe",1)["profit"],q_before["profit"])>0,"Tools improve actual craft contract profitability")
 before=g.income_of("coins")
 expect(E.invest(g,"craft"),"Sector investment pays capital")
 expect(BN.compare(g.income_of("coins"),before)>0,"Sector investment compounds production")
 expect(g.buy_generator("trading_post") and g.buy_generator("trading_post"),"Trade assets fulfil ownership milestone")
 for i in 2:
  expect(A.start_trade(g,"relief","safe",5),"Commercial capacity funds relief contract")
  g.tick(90)
 expect(BN.compare(g.total("reputation"),BN.of(65))>=0,"Commercial activity supplies promotion reputation")
 accord(g,"merchants");accord(g,"merchants")
 var gen_cost: Dictionary=g.generator_cost(D.GENERATORS[0])["coins"]
 q_before=A.quote(g,"caravan","safe",5)
 expect(E.ratify(g,"open_passage"),"Earned relationship ratifies economic privilege")
 expect(not E.ratify(g,"open_passage"),"Privilege cannot charge twice")
 expect(BN.compare(g.generator_cost(D.GENERATORS[0])["coins"],gen_cost)<0,"Politics reduces actual business investment price")
 var q_after: Dictionary=A.quote(g,"caravan","safe",5)
 expect(BN.compare(q_after["cost"],q_before["cost"])<0 and BN.compare(q_after["profit"],q_before["profit"])>0,"Privilege lowers committed capital and raises venture returns")
 expect(g.can_promote() and g.promote(),"Integrated chain reaches Guildmaster without changing original gate")
 expect(g.state["economy"]["discoveries"].has("integration"),"Interconnected investment earns permanent discovery")
 # Revenue/cost/net are an identity, costs never debit reserves and demand never destroys income.
 for gen in D.GENERATORS.slice(0,3):
  var p: Dictionary=E.business_profile(g,gen)
  expect(BN.compare(BN.subtract(p["revenue"],p["cost"]),p["net"])==0,"Revenue minus operating costs equals real net")
  expect(p["margin"]>=0.75 and p["margin"]<=0.9,"Operating margin remains positive")
 var clone=G.new();clone.state=g.state.duplicate(true)
 g.tick(360)
 for i in 360:clone.tick(1)
 for r in D.RESOURCES:expect(absf(number(g.resource(r))-number(clone.resource(r)))<0.01,"Market integration independent of tick partition: "+r)
 accord(g,"commons");accord(g,"commons")
 var cost_ratio: float=E.cost_fraction(g)
 expect(E.ratify(g,"public_supply") and E.cost_fraction(g)<cost_ratio,"Public agreement reduces operating expense")
 accord(g,"council");accord(g,"council")
 before=g.income_of("coins")
 expect(E.ratify(g,"city_charter"),"Influence funds city trading rights")
 expect(BN.compare(g.income_of("coins"),before)>0 and A.lots_limit(g)>=20,"Political influence expands commerce and production")
 # Frozen quote and large-value scaling: never cast a wallet or enterprise rate to native float.
 g=funded(5);g.state["generators"]["trading_post"]=1000000
 g.state["legacy_points"]=1000000
 var q: Dictionary=A.quote(g,"caravan","safe",20)
 expect(BN.compare(q["cost"],BN.of(16000))>0 and BN.valid(q["profit"]),"Large businesses receive scaled opportunities")
 g.state["resources"]["coins"]={"m":1.0,"e":1000}
 expect(A.start_trade(g,"caravan","safe",20),"Scientific wallet above IEEE range can invest")
 var frozen: Dictionary=g.state["activities"]["orders"][0].duplicate(true)
 g.state["generators"]["trading_post"]+=1000000
 expect(BN.compare(g.state["activities"]["orders"][0]["profit"],frozen["profit"])==0,"Dispatched terms never retroactively reprice")
 g.tick(120)
 expect(BN.valid(g.resource("coins")) and int(g.resource("coins")["e"])==1000,"Large-value completion stays finite and valid")
 expect(BN.valid(g.generator_cost(D.GENERATORS[2])["coins"]),"Very large price exponents remain valid")
 # Manual risk, assurance, safe delegation and sufficient reserves.
 for insured in [false,true]:
  g=funded(3)
  if insured:expect(g.buy_upgrade("mutual_assurance"),"Insurance is a purchased capability")
  var wallet: Dictionary=g.resource("coins").duplicate()
  expect(A.start_trade(g,"caravan","venture",1),"Risky opportunity starts")
  var order: Dictionary=g.state["activities"]["orders"][0]
  order["loss"]=true
  var expected: Dictionary=BN.subtract(wallet,BN.times(order["cost"],0.0 if insured else 0.15))
  g.tick(96)
  expect(absf(number(g.resource("coins"))-number(expected))<0.01,"Risk loss matches chosen protection")
 g=funded(4);g.state["upgrades"]["trade_clerk"]=true
 expect(A.start_trade(g,"salvage","venture",1) and A.toggle_repeat(g,1),"Clerk opts into safe delegation")
 g.state["activities"]["orders"][0]["loss"]=true
 g.tick(24)
 expect(g.state["activities"]["orders"].size()==1 and g.state["activities"]["orders"][0]["route"]=="safe","Delegated risk returns principal and repeats safely")
 var first: int=g.state["activities"]["completed"]
 g.tick(28800,0.75)
 expect(g.state["activities"]["completed"]==first+720,"Bounded offline clerk settles exact effective time")
 g=funded(5);g.buy_generator("workshop");g.buy_upgrade("estate_steward")
 var sector_before: int=g.state["economy"]["sectors"]["craft"]
 expect(E.toggle_steward(g),"Steward is explicit opt-in")
 g.state["economy"]["focus"]="craft"
 before=g.resource("reputation").duplicate();g.tick(120)
 expect(int(g.state["economy"]["sectors"]["craft"])==sector_before+1,"Steward makes real sector investment")
 expect(BN.compare(before,g.resource("reputation"))==0,"Steward never consumes civic resources")
 g.tick(28800,0.75)
 expect(g.state["economy"]["sectors"]["craft"]==4 and E.valid(g.state["economy"]),"Delegation is finite and caps at completed sector")
 # Schema 2 active-order migration, untouched backup, settings and permanent prestige record.
 g=funded(4);g.state["upgrades"]["trade_clerk"]=true
 A.start_trade(g,"salvage","safe",1);A.toggle_repeat(g,1)
 clone=G.new();clone.state=g.state.duplicate(true)
 g.tick(720)
 for second in 720:clone.tick(1)
 expect(g.state["economy"]["discoveries"].has("exchange"),"Delivery unlocks its discovery at the event boundary")
 expect(absf(number(g.resource("coins"))-number(clone.resource("coins")))<0.01,"Discovery and repeated-contract rewards agree online and offline")
 g=funded(6);g.buy_generator("workshop");g.check_achievements()
 A.start_trade(g,"envoy","venture",1);A.begin_talk(g,"council");A.respond(g,"concede")
 var old: Dictionary=g.state.duplicate(true);old["version"]=2;old["app_version"]="0.3.0";old.erase("economy");old.erase("settings")
 old["activities"]["orders"][0].erase("insured")
 g.save_path="user://economy-v04.json";g.backup_path="user://economy-v04.bak.json"
 for path in [g.save_path,g.backup_path,g.save_path+".pre-v04.json"]:
  if FileAccess.file_exists(path):DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
 write(g.save_path,old);g.load_or_new()
 expect(g.loaded_from_save and g.state["version"]==3 and g.rank()==6,"v0.3 schema migrates without resetting rank")
 expect(FileAccess.file_exists(g.save_path+".pre-v04.json"),"Original v0.3 save backed up")
 var backed: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(g.save_path+".pre-v04.json"))
 expect(backed["version"]==2 and not backed.has("economy"),"Migration backup is untouched")
 expect(g.state["activities"]["orders"][0]["loss"]==old["activities"]["orders"][0]["loss"] and g.state["activities"]["negotiation"]["round"]==1,"Active quote outcome and negotiation preserved")
 var earned: Dictionary=g.state["achievements"].duplicate(true)
 var discoveries: Dictionary=g.state["economy"]["discoveries"].duplicate(true)
 g.state["settings"]["reduced_motion"]=true
 expect(g.legacy_reset(),"Hybrid Legacy persists")
 for id in earned:expect(g.state["achievements"].has(id),"Achievement retained: "+id)
 for id in discoveries:expect(g.state["economy"]["discoveries"].has(id),"Discovery retained: "+id)
 expect(g.state["economy"]["highest_rank"]==6 and g.state["settings"]["reduced_motion"],"Historical status and accessibility preference survive prestige")
 expect(g.state["activities"]["orders"].is_empty() and g.state["economy"]["privileges"].is_empty(),"Life-specific operations reset")
 var factor: float=g.modifier("global")
 g.load_or_new();expect(is_equal_approx(g.modifier("global"),factor),"Permanent multipliers cannot duplicate on reload")
 for key in ["clock","highest_rank"]:
  var bad: Dictionary=g.state["economy"].duplicate(true);bad[key]=-1
  expect(not E.valid(bad),"Malformed economy rejected: "+key)
 for path in [g.save_path,g.backup_path,g.save_path+".pre-v04.json"]:
  if FileAccess.file_exists(path):DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
 for failure in failures:push_error(failure)
 print("%s: %d living-economy assertions; %d failures." % ["PASS" if failures.is_empty() else "FAIL",checks,failures.size()])
 quit(0 if failures.is_empty() else 1)
