extends SceneTree
const Game=preload("res://scripts/game.gd")
const ACT=preload("res://scripts/activities.gd")
const BN=preload("res://scripts/big_number.gd")
var checks: int=0
var failures: Array[String]=[]
func expect(ok: bool,message: String) -> void:
 checks+=1
 if not ok:failures.append(message)
func number(v: Dictionary) -> float:return float(v["m"])*pow(10.0,int(v["e"]))
func close(a: float,b: float) -> bool:return absf(a-b)<0.001
func funded(rank_value: int=3):
 var g=Game.new();g.state["rank"]=rank_value;g.gain("coins",BN.of(100000));return g
func write(path: String,doc: Dictionary) -> void:
 var f=FileAccess.open(path,FileAccess.WRITE);f.store_string(JSON.stringify(doc));f.close()
func _initialize() -> void:
 seed(301)
 var g=Game.new()
 expect(ACT.valid(g.state["activities"]),"Fresh activity state validates")
 expect(not ACT.start_trade(g,"salvage","safe",1),"Rank locks trade")
 g.state["rank"]=1
 expect(not ACT.start_trade(g,"salvage","safe",1),"Cannot trade without capital")
 g.gain("coins",BN.of(18));var total_before: float=number(g.total("coins"))
 expect(ACT.start_trade(g,"salvage","safe",1,0),"Affordable trade dispatches")
 expect(close(number(g.resource("coins")),0),"Capital actually leaves wallet")
 expect(not ACT.start_trade(g,"salvage","safe",1,0),"Stale dispatch rejected")
 expect(not ACT.start_trade(g,"salvage","safe",1),"Capacity enforced")
 expect(not ACT.toggle_repeat(g,1),"Automation requires clerk")
 g.tick(29)
 expect(g.state["activities"]["orders"].size()==1 and number(g.resource("coins"))==0,"Trade cannot pay early")
 g.tick(1)
 expect(close(number(g.resource("coins")),30),"Safe arrival returns principal plus profit")
 expect(close(number(g.total("coins"))-total_before,12),"Principal is not counted as lifetime earnings")
 g.tick(30)
 expect(close(number(g.resource("coins")),30),"Settled order cannot pay twice")
 expect(int(g.state["activities"]["completed"])==1,"One delivered order counted")
 g=funded(4)
 var safe_q: Dictionary=ACT.quote(g,"relief","safe",1)
 var risk_q: Dictionary=ACT.quote(g,"relief","venture",1)
 expect(close(number(risk_q["reputation"]),number(safe_q["reputation"])*0.5),"Shortcut trades civic credit for commercial return")
 expect(number(risk_q["profit"])>number(safe_q["profit"]),"Risk route offers a distinct coin strategy")
 expect(not ACT.start_trade(g,"bad","safe",1),"Unknown contracts rejected")
 expect(not ACT.start_trade(g,"salvage","bad",1),"Unknown routes rejected")
 expect(not ACT.start_trade(g,"salvage","safe",0),"Zero lots rejected")
 expect(not ACT.start_trade(g,"salvage","safe",20),"Large lots require merchant relationships")
 g.state["activities"]["trust"]["merchants"]=2
 expect(ACT.start_trade(g,"caravan","safe",20),"Merchant trust enables large shipment")
 expect(ACT.start_trade(g,"relief","safe",5),"Trader supports concurrent routes")
 expect(not ACT.start_trade(g,"salvage","safe",1),"Third route locked before Advocate")
 expect(ACT.valid(g.state["activities"]),"Paid frozen quotes validate")
 var income: float=number(g.income_of("reputation"))
 expect(income==0,"Bonuses do not invent passive reputation")
 expect(g.buy_generator("rumour_network"),"Reputation engine is coin funded")
 expect(number(g.income_of("reputation"))>0,"Network sustainably generates reputation")
 g.tick(120)
 expect(number(g.total("reputation"))>40,"Contract delivery earns real reputation")
 expect(g.state["activities"]["orders"].is_empty(),"Both differently timed routes settle")
 # Explicitly fixed loss outcome verifies worst-case accounting independently of random sampling.
 g=funded(3);var capital: float=number(g.resource("coins"));total_before=number(g.total("coins"))
 expect(ACT.start_trade(g,"caravan","venture",1),"Risk route launches")
 g.state["activities"]["orders"][0]["loss"]=true
 g.tick(96)
 expect(close(number(g.resource("coins")),capital-120),"Failed route loses exactly 15 percent of principal")
 expect(close(number(g.total("coins")),total_before),"Failed principal return never advances lifetime gate")
 expect(number(g.total("reputation"))==0,"Failed route grants no civic reward")
 expect(int(g.state["activities"]["losses"])==1,"Loss is recorded")
 # Pause, automatic reinvestment, and offline-effective time.
 g=funded(4);g.gain("reputation",BN.of(20))
 expect(g.buy_upgrade("trade_clerk"),"Clerk upgrade purchases real capability")
 expect(ACT.start_trade(g,"salvage","safe",1),"Automation route starts")
 expect(ACT.toggle_repeat(g,int(g.state["activities"]["orders"][0]["serial"])),"Repeat opts in per route")
 g.state["paused"]=true;g.tick(600)
 expect(g.state["activities"]["completed"]==0,"Pause freezes contracts")
 g.state["paused"]=false;g.tick(120,0.75)
 expect(g.state["activities"]["completed"]==3,"Offline-effective time completes three deliveries")
 expect(g.state["activities"]["orders"].size()==1,"Clerk genuinely re-dispatches")
 expect(ACT.valid(g.state["activities"]),"Repeated state remains valid")
 # Opted-in delegation now protects capital and switches to safe passage.
 g=funded(4);g.state["resources"]["coins"]=BN.of(18);g.state["upgrades"]["trade_clerk"]=true
 ACT.start_trade(g,"salvage","venture",1);ACT.toggle_repeat(g,1);g.state["activities"]["orders"][0]["loss"]=true;g.tick(24)
 expect(g.state["activities"]["orders"].size()==1 and g.state["activities"]["orders"][0]["route"]=="safe","Protected capital funds safe repeat")
 expect(close(number(g.resource("coins")),0),"Clerk never creates debt")
 # Negotiation requires funded concessions or settles for lower rewards; pressure can break talks.
 g=funded(2)
 expect(not ACT.begin_talk(g,"council"),"Council locked until political era")
 expect(ACT.begin_talk(g,"merchants"),"Vendor can negotiate")
 expect(not ACT.begin_talk(g,"commons"),"Only one negotiation at a time")
 expect(ACT.respond(g,"concede",0,1),"Funded first round accepted")
 expect(not ACT.respond(g,"concede",0,1),"Duplicate round event cannot spend again")
 expect(ACT.respond(g,"listen",1,1),"Listening cools tension")
 expect(ACT.respond(g,"bargain",2,1),"Reading profit motivation yields agreement")
 expect(g.state["activities"]["trust"]["merchants"]==1,"Success builds merchant trust")
 expect(close(g.modifier("res_coins"),1.03),"Trust affects actual production")
 expect(g.state["activities"]["negotiation"].is_empty(),"Finished negotiation clears once")
 expect(not ACT.respond(g,"bargain",2,1),"Final-round duplicate cannot pay again")
 expect(not ACT.begin_talk(g,"commons"),"Delegate cooldown prevents unlimited activity spam")
 g.tick(120);expect(ACT.begin_talk(g,"commons"),"Delegates recover with elapsed time")
 ACT.respond(g,"bargain");ACT.respond(g,"bargain")
 expect(g.state["activities"]["negotiation"].is_empty() and g.state["activities"]["trust"]["commons"]==0,"Excess pressure actually fails")
 g.tick(120);ACT.begin_talk(g,"commons")
 for i in 3:ACT.respond(g,"listen")
 expect(g.state["activities"]["trust"]["commons"]==0 and number(g.total("reputation"))>4,"Free cordial hearing grants small reward without trust")
 # All factions, all content, bounded trust, and trait distinctions.
 g=funded(6)
 for f in ACT.FACTIONS:
  var before: float=number(g.total("influence" if f["id"]=="council" else "reputation"))
  for session in 6:
   g.tick(120);expect(ACT.begin_talk(g,f["id"]),"Faction begins: "+f["id"])
   for i in 3:expect(ACT.respond(g,"concede"),"Concession progresses round")
  expect(g.state["activities"]["trust"][f["id"]]==5,"Trust capped at five")
  expect(number(g.total("influence" if f["id"]=="council" else "reputation"))>before,"Faction reward reaches economy")
 expect(g.modifier("res_reputation")>1.25 and g.modifier("res_influence")>1.25,"Distinct reputation and influence relationships stack with ranks")
 for offer in ACT.OFFERS:
  expect(ACT.start_trade(g,offer["id"],"safe",5),"Offer dispatches: "+offer["id"])
  g.tick(float(offer["seconds"]))
  expect(ACT.valid(g.state["activities"]),"Offer settles to valid state")
 # Persistence and version-1 migration.
 g=funded(3);g.save_path="user://v03-activities.json";g.backup_path="user://v03-activities.bak.json"
 for suffix in ["", ".pre-v03.json"]:
  if FileAccess.file_exists(g.save_path+suffix):DirAccess.remove_absolute(ProjectSettings.globalize_path(g.save_path+suffix))
 var old: Dictionary=g.state.duplicate(true);old["version"]=1;old["app_version"]="0.2.0";old.erase("activities");old["legacy_points"]=3
 write(g.save_path,old);g.load_or_new()
 expect(g.rank()==3 and g.state["legacy_points"]==3 and int(g.state["version"])==3,"Migration preserves rank, resources and Legacy")
 expect(FileAccess.file_exists(g.save_path+".pre-v03.json"),"Migration creates original-file backup")
 var original: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(g.save_path+".pre-v03.json"))
 expect(int(original["version"])==1 and not original.has("activities"),"Backup retains untouched old schema")
 ACT.start_trade(g,"relief","venture",1);ACT.begin_talk(g,"commons");ACT.respond(g,"concede")
 expect(g.save_game(),"Active activities save")
 var snapshot: Dictionary=g.state.duplicate(true);g.load_or_new()
 expect(g.state["activities"]["orders"][0]["loss"]==snapshot["activities"]["orders"][0]["loss"],"Reload cannot reroll outcome")
 expect(g.state["activities"]["negotiation"]["round"]==1,"Negotiation round persists")
 snapshot=g.state.duplicate(true);snapshot["saved_at"]=Time.get_unix_time_from_system()-86400;write(g.save_path,snapshot);g.load_or_new()
 expect(g.state["activities"]["orders"].is_empty() and g.state["activities"]["completed"]==1,"Offline arrival settles stored contract")
 var after: float=number(g.resource("coins"));g.load_or_new()
 expect(close(number(g.resource("coins")),after),"Reload cannot duplicate delivery")
 var invalid: Dictionary=g.state["activities"].duplicate(true);invalid["cooldown"]=-1
 expect(not ACT.valid(invalid),"Negative clock rejected")
 invalid=g.state["activities"].duplicate(true);invalid["trust"]["commons"]=6
 expect(not ACT.valid(invalid),"Out-of-range trust rejected")
 invalid=g.state["activities"].duplicate(true);invalid["negotiation"]["round"]=999
 expect(not ACT.valid(invalid),"Invalid round rejected")
 g.state["rank"]=6;expect(g.legacy_reset(),"Prestige still works with active diplomacy")
 expect(g.state["activities"]["orders"].is_empty() and g.state["activities"]["trust"]["merchants"]==0,"Legacy resets chapter relationships and contracts")
 for path in [g.save_path,g.backup_path,g.save_path+".pre-v03.json"]:
  if FileAccess.file_exists(path):DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
 for failure in failures:push_error(failure)
 print("%s: %d activity/migration assertions; %d failures." % ["PASS" if failures.is_empty() else "FAIL",checks,failures.size()])
 quit(0 if failures.is_empty() else 1)
