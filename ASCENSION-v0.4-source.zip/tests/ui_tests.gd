## Rendered input regression suite. Android adb interaction is recorded separately.
extends SceneTree
const Main = preload("res://scenes/main.tscn")
const BN = preload("res://scripts/big_number.gd")
var ui: Control
var failures: Array[String] = []
var checks: int = 0
func _initialize() -> void: call_deferred("run")
func expect(ok: bool, message: String) -> void:
	checks += 1
	if not ok: failures.append(message)
func settle() -> void:
	for i in 4: await process_frame
func named(id: String) -> Button:
	return ui.find_child(id, true, false) as Button
func prefixed(prefix: String) -> Button:
	for node in ui.find_children("*", "Button", true, false):
		if node.text.begins_with(prefix): return node
	return null
func click(target: Button, held: bool = false) -> void:
	expect(target != null, "Button exists")
	if target == null: return
	if ui.content.is_ancestor_of(target):
		ui.scroller.ensure_control_visible(target)
		await settle()
	await settle()
	var position: Vector2 = target.get_global_rect().get_center()
	var event := InputEventMouseButton.new()
	event.button_index = MOUSE_BUTTON_LEFT
	event.position = position
	event.pressed = true
	Input.parse_input_event(event)
	await process_frame
	if held:
		ui._process(0.3)
		await settle()
		expect(is_instance_valid(target), "Held control survives periodic refresh")
	event = InputEventMouseButton.new()
	event.button_index = MOUSE_BUTTON_LEFT
	event.position = position
	event.pressed = false
	Input.parse_input_event(event)
	await settle()
func shot(id: String) -> void:
	if DisplayServer.get_name() != "headless":
		await create_timer(0.22).timeout
		await RenderingServer.frame_post_draw
		expect(root.get_texture().get_image().save_png("res://tests/results/v04/"+id+".png") == OK, "Screenshot captured")
func drag_up(start_override: Vector2 = Vector2(-1,-1)) -> void:
	Input.emulate_touch_from_mouse = true
	var bounds: Rect2 = ui.scroller.get_global_rect()
	var start := Vector2(bounds.position.x+bounds.size.x*0.5, bounds.end.y-35)
	if start_override.x >= 0: start = start_override
	var press := InputEventMouseButton.new()
	press.button_index = MOUSE_BUTTON_LEFT
	press.position = start
	press.pressed = true
	Input.parse_input_event(press)
	await process_frame
	var previous: Vector2 = start
	for step in range(1, 13):
		var current: Vector2 = start - Vector2(0, minf(220.0, bounds.size.y-60.0)*float(step)/12.0)
		var motion := InputEventMouseMotion.new()
		motion.position = current
		motion.relative = current-previous
		motion.button_mask = MOUSE_BUTTON_MASK_LEFT
		Input.parse_input_event(motion)
		previous = current
		await process_frame
	press = InputEventMouseButton.new()
	press.button_index = MOUSE_BUTTON_LEFT
	press.position = previous
	press.pressed = false
	Input.parse_input_event(press)
	await settle()
	Input.emulate_touch_from_mouse = false
func run() -> void:
	root.size = Vector2i(420, 820)
	root.content_scale_size = root.size
	ui = Main.instantiate()
	root.add_child(ui)
	await settle()
	ui.set_process(false)
	ui.game.save_path = "user://ui-v04.json"
	ui.game.backup_path = "user://ui-v04.bak.json"
	ui.game.new_game()
	ui._render_all()
	await settle()
	await shot("01-survival")
	expect(ui.scroller.size.y >= 400.0, "Compact header leaves a useful main scroll viewport")
	for i in 15: await click(ui.work_button)
	expect(BN.compare(ui.game.resource("coins"), BN.of(15.0)) == 0, "15 WORK pointer taps earn initial stall")
	await click(named("Buy_street_stall"), true)
	expect(ui.game.own("street_stall") == 1, "Stall purchase through actual input")
	ui.game.tick(60.0)
	ui._refresh_live()
	expect(ui.game.can_promote(), "Automation earns the original promotion gate")
	await click(ui.goal_button)
	expect(ui.game.rank() == 1 and ui.promotion_overlay.visible, "Primary ASCEND input promotes directly and celebrates")
	await shot("02-first-ascension")
	await click(ui.goal_button)
	expect(ui.game.rank() == 1, "Repeated tap behind celebration cannot promote again")
	await click(named("ContinueAscension"))
	expect(not ui.promotion_busy, "Celebration is immediately skippable")
	var restored = load("res://scripts/game.gd").new()
	restored.save_path = ui.game.save_path
	restored.backup_path = ui.game.backup_path
	restored.load_or_new()
	expect(restored.rank() == 1 and restored.own("street_stall") == 1, "Promotion persists before closing celebration")
	ui.upgrade_filter="all"
	await click(ui.nav_buttons[2])
	await click(named("Upgrade_warm_clothes"))
	expect(ui.game.state["upgrades"].has("warm_clothes"), "Upgrade purchase responds to pointer input")
	ui.scroller.scroll_vertical = 0
	await settle()
	var before: int = ui.scroller.scroll_vertical
	await drag_up()
	expect(ui.scroller.scroll_vertical > before + 30, "Touch-emulated drag scrolls long upgrade menu")
	ui.scroller.set_process_internal(false)
	var remembered: int = ui.scroller.scroll_vertical
	await click(ui.nav_buttons[3])
	await click(ui.nav_buttons[2])
	expect(abs(ui.scroller.scroll_vertical-remembered) < 30, "Each tab restores its own scroll position")
	ui.game.gain("coins", BN.of(500.0))
	ui._refresh_live()
	var route_button: Button = named("Upgrade_route_scouting")
	ui.scroller.ensure_control_visible(route_button)
	await settle()
	var before_drag: Dictionary = ui.game.resource("coins").duplicate()
	await drag_up(route_button.get_global_rect().get_center())
	expect(not ui.game.state["upgrades"].has("route_scouting"), "Dragging from an affordable upgrade never purchases it")
	expect(BN.compare(before_drag,ui.game.resource("coins"))==0, "Touch scrolling never spends resources")
	# Exact user report, using a save fixture with surplus for multiple rank gates.
	ui.game.new_game()
	ui.game.gain("coins", BN.of(2350.0))
	ui.game.state["generators"]["street_stall"] = 20
	ui._render_all()
	await settle()
	await click(ui.goal_button)
	expect(ui.game.rank() == 1, "Reported 2350 coins / 20 stalls fixture promotes")
	await shot("03-reported-save-promotion")
	ui._promote(0)
	expect(ui.game.rank() == 1, "Stale duplicate callback rejected")
	await click(named("ContinueAscension"))
	# Preserve state on a real persistence failure.
	ui.game.new_game()
	ui.game.gain("coins", BN.of(2350.0))
	ui.game.state["generators"]["street_stall"] = 20
	ui.game.save_path = "user://no-such-v03-directory/save.json"
	ui._render_all()
	await click(ui.goal_button)
	expect(ui.game.rank() == 0 and not ui.promotion_overlay.visible, "Failed promotion save rolls rank back")
	ui.game.save_path = "user://ui-v04.json"
	# Advanced fixture exercises unlock wiring without pretending this is organic play.
	for resource in ["coins", "reputation", "influence"]: ui.game.gain(resource, BN.of(1000000.0))
	for generator in ["workshop", "trading_post", "campaign_office"]: ui.game.state["generators"][generator] = 2
	for target_rank in range(1, 4):
		ui._render_all()
		await click(ui.goal_button)
		expect(ui.game.rank() == target_rank, "Subsequent rank transaction")
		await click(named("ContinueAscension"))
	await click(ui.nav_buttons[3])
	await click(named("Choose_profit"))
	await click(named("Choose_coalition"))
	expect(ui.game.state["decisions"].size() == 2, "Two strategic decisions through pointer input")
	for target_rank in range(4, 7):
		await click(ui.goal_button)
		expect(ui.game.rank() == target_rank, "Late rank transaction")
		await click(named("ContinueAscension"))
	for viewport_size in [Vector2i(420,820), Vector2i(360,800), Vector2i(360,640), Vector2i(420,1000)]:
		root.size = viewport_size
		root.content_scale_size = viewport_size
		await settle()
		for tab in 5:
			await click(ui.nav_buttons[tab])
			ui.scroller.scroll_vertical = 0
			await settle()
			expect(ui.get_global_rect().size.x <= viewport_size.x+1, "Main layout fits portrait width")
			expect(ui.scroller.size.y > 200, "Scrolling area remains usable on short portrait")
			for nav in ui.nav_buttons:
				for text in nav.find_children("*","Label",true,false):
					var width: float = text.get_theme_font("font").get_string_size(text.text,HORIZONTAL_ALIGNMENT_LEFT,-1,text.get_theme_font_size("font_size")).x
					expect(width<=text.size.x, "Bottom navigation label remains readable without truncation")
			for node in ui.find_children("*", "Button", true, false):
				if not node.is_visible_in_tree() or node.get_parent() is Window: continue
				expect(node.size.y >= 48.0, "48px minimum touch target: " + node.name)
				expect(node.get_global_rect().end.x <= ui.size.x+1, "No horizontal button clipping: " + node.name)
			if viewport_size.y != 640 and viewport_size.y != 1000: await shot("%dx%d-tab-%d" % [viewport_size.x,viewport_size.y,tab])
	# Controller-level lifecycle, capped offline and no duplicate resumed frame.
	ui.game.state["paused"] = false
	ui._notification(Control.NOTIFICATION_APPLICATION_PAUSED)
	var document: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(ui.game.save_path))
	document["saved_at"] = Time.get_unix_time_from_system()-100000.0
	var file := FileAccess.open(ui.game.save_path, FileAccess.WRITE)
	file.store_string(JSON.stringify(document)); file.close()
	var original: Dictionary = ui.game.resource("coins").duplicate()
	ui._process(100000.0)
	expect(BN.compare(original,ui.game.resource("coins")) == 0, "Background frames do not simulate")
	ui._notification(Control.NOTIFICATION_APPLICATION_RESUMED)
	var rewarded: Dictionary = ui.game.resource("coins").duplicate()
	expect(BN.compare(rewarded,original)>0, "Resume awards offline production")
	ui._process(100000.0)
	expect(BN.compare(rewarded,ui.game.resource("coins"))==0, "First resumed frame cannot double pay")
	ui._show_legacy()
	await settle()
	expect(ui.legacy_confirmation.get_ok_button().size.y>=48, "Legacy confirm has a finger-sized touch target")
	expect(ui.legacy_confirmation.get_cancel_button().size.y>=48, "Legacy cancel has a finger-sized touch target")
	expect(ui.legacy_confirmation.visible, "Legacy is confirmed separately")
	ui.legacy_confirmation.confirmed.emit()
	ui.legacy_confirmation.hide()
	expect(ui.game.rank()==0 and int(ui.game.state["legacy_points"])==1, "Legacy confirmation callback actually resets and grants prestige")
	restored.load_or_new()
	expect(int(restored.state["legacy_points"])==1, "Legacy persists after UI confirmation")
	for path in [ui.game.save_path,ui.game.backup_path]:
		if FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	ui.queue_free()
	await process_frame
	for failure in failures: push_error(failure)
	print(("PASS" if failures.is_empty() else "FAIL")+": %d rendered UI checks; %d failures." % [checks,failures.size()])
	quit(0 if failures.is_empty() else 1)
