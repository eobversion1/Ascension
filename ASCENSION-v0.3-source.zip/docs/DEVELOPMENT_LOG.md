# Development and verification log

## Current: v0.3.0

Complete trade and diplomacy activities, schema-2 migration, compact navigation and world artwork are implemented. See [v0.3 validation](VALIDATION_V03.md), [economy audit](ECONOMY_V03.md) and [changelog](CHANGELOG_V03.md).

## Previous: v0.2.0

Progression, mobile UI and rank rewards have been implemented in the existing project. See [v0.2 validation](VALIDATION_V02.md) and [changelog](CHANGELOG_V02.md). Earlier entries below are historical and describe superseded artifacts and emulator limitations.

## 2026-10-18 — Existing starter developed and verified

The uploaded `Ascension_Godot_Project` was extracted into the existing empty checkout without replacing `.git`. The original gameplay, data model and native UI were retained and extended. No remote push or publication was performed.

### Initial state

Godot **4.6.3.stable.official.7d41c59c4** imported the starter without parser errors after directing data/config/cache to writable workspace paths. The existing smoke suite failed its `10^502` exponent assertion: logarithm rounding left a mantissa just below 10. Android SDK/export templates were initially absent. The starter README's unverified-runtime statements described that earlier state and have been replaced with actual results.

### Changes

- Fixed scientific-number boundary normalisation and reduced overly permissive equality tolerance that could permit slightly underfunded purchases. Added finite/integer exponent validation and invalid-time/efficiency guards.
- Hardened version-1 save validation, numeric field handling, unknown content IDs and corrupt log entries. A valid backup restores progress and Legacy. Unreadable or future-version saves remain intact and cannot be overwritten by automatic saving. Schema remains version 1; no existing save migration/reset is required.
- Save replacement uses a temporary file and direct rename after backing up the primary. Tests cover backup recovery, newer versions, paused offline income, backward clocks, eight-hour caps and duplicate reload awards.
- Added Android pause/resume handling. Backgrounded frames do not simulate income; resume restores a bounded offline award and skips the first resumed frame so a long delta cannot pay again.
- Replaced periodic full-page rebuilding with live affordability/progress bindings. A held purchase control survives refresh. Added separate resource cards, a persistent next goal, coin-upgrade payback estimates, minimum 48-pixel touch controls, safe-area margins and confirmed Legacy reset. Narrow-screen navigation titles remain fully visible.
- Tuned base production and civic-choice bonuses using actual-engine simulations. Final commercial/civic policies complete the seven-rank chapter in **21m15s / 37m30s**. Full evidence and assumptions are in `BALANCE.md`.
- Added the Android preset, original icon, engine/third-party licence assets, reusable setup/export helpers and accurate run/build documentation.

### Executed checks

- `./tools/godot.sh --headless --path . --editor --quit`: successful import with Godot 4.6.3, no GDScript parse errors.
- `./tools/godot.sh --headless --path . --script res://tests/smoke_tests.gd`: **128 assertions passed**. Covers large numbers, purchases, all six generators and fourteen upgrades, all four mutually exclusive decisions, rank gates, pause/time semantics, corruption recovery, save/load, Legacy preservation and bounded offline income.
- Main scene launched headlessly without runtime errors.
- `DISPLAY=:99 ./tools/godot.sh --audio-driver Dummy --path . --script res://tests/ui_tests.gd`: **passed** under Xvfb/Mesa. Actual injected pointer events work, buy the first Stall, buy an upgrade, promote, make a decision, save/reload and open the Legacy confirmation. A held purchase survives a refresh. Layout/touch/title-fit checks and PNG captures cover **420×820 and 360×800**. Advanced screenshot states use a test fixture; full cold-start progression is covered separately by simulation.
- `./tools/godot.sh --headless --path . --script res://tests/balance_simulation.gd`: **passed**, two policies at **5/20/45/120/1440 minutes**, all seven ranks, all four decisions and valid balances. Original-content baseline was run with the same final policy harness. Both final completions were checked against the 20–45 minute target.
- `python3 tests/static_review.py`: passed structural check; distinct from executing the engine.
- `./tools/setup_environment.sh` and `./tools/build_android.sh`: completed successfully using the retained local toolchain. Setup also prevents editor exit from shutting down an active ADB session.

### Android artifact

**Compiled and signed:** `build/android/ASCENSION-debug.apk`, **84,678,423 bytes** (80.76 MiB).

SHA-256: `c47abded214633d2c67d4d293835ade256793150e54ed61f0e99377977d61b78`.

Package `org.ascensiongame.chapterone`, version **0.1.0 / 1**, minimum **API 24**, target **API 36**, ARM64/ARMv7/x86_64. Application category is Game; the manifest requests **no permissions**. The exported MAIN/LAUNCHER activity alias is present. `apksigner` verifies v2/v3 signing, and `zipalign -c -P 16 4` succeeds. `metadata.txt`, `permissions.txt`, `signature.txt` and `SHA256SUMS` are alongside the artifact. Independent review repeated signature, alignment and manifest checks.

The build uses OpenJDK **21.0.12.1**, Android build-tools **36.0.0**, SDK platform **36 revision 2**, platform-tools **37.0.1**, and verified matching Godot templates. See `ANDROID_BUILD.md` for exact paths, fresh-machine instructions and official download/checksum sources.

### Device/runtime status

Android emulator **37.2.12**, AOSP **Android 15/API 35 x86_64 revision 2**, 420×820 software display, no KVM acceleration. Boot completed after about seven minutes. The APK installed successfully. The original software graphics backend and Android OS then failed; see the resumed verification below for the subsequent launch checks. A successful APK export alone does not establish gameplay or physical-device playtesting.

**No physical Android device has been tested.** No mobile frame-rate, memory, battery or OEM process-eviction performance claim is made. Desktop Xvfb produced an expected unsupported-VSync warning and used the Dummy audio driver. There is no audio feature, backend, ad SDK or later cosmic chapter in this delivery.

### Handoff

`build/ASCENSION-source.zip` contains editable source, content, tests, screenshots and documentation, excluding `.git`, `.godot`, SDKs, signing keys and APK build files. The APK is a separate deliverable. Next priorities are physical-device QA, contextual onboarding with first-time human playtests, then an administrative era with new gameplay rather than larger-number reskins.

## Resumed verification — 2026-10-18

Reused the existing APK and project. Re-ran the engine smoke suite: **128 assertions passed**, exit 0. Re-ran rendered pointer, portrait layout, lifecycle and persistence tests at **420×820 and 360×800**: passed, exit 0. Rechecked APK v2/v3 signatures, 16 KiB ZIP alignment and recorded SHA-256: all passed. No gameplay source changes or APK rebuild were needed for those checks.

The original Android emulator was left in a failed OS state: `system_server` aborted, SystemUI reported `DeadSystemException`, and the game later encountered that dead Android service while saving. The original partial save was preserved. Relaunching the installed APK started a live application process but produced black frames. Logs also identify both 2D CanvasShader and 3D shader linking failures on the deprecated `swiftshader_indirect` backend (fragment-uniform limit). These are unresolved Android rendering evidence, not a successful gameplay test.

A clean reboot did not complete within three minutes. The same AVD and installed APK were then retained and relaunched with the supported `-gpu swangle` backend, 4096 MiB RAM and four virtual cores; no wipe, reinstall or APK rebuild was performed. Final recovery outcome is recorded below.

**Final recovery outcome:** the supported ANGLE/SwiftShader backend booted in 268.723 seconds with the existing AVD, installed APK and data preserved. Android and Godot engine splash screens rendered, and the application process remained alive. The main game interface did not appear within the bounded observation. No new app fatal was observed in the captured crash buffer, while the Android launcher reported an ANR and Bluetooth processes crashed. The earlier uniform-link failures did not recur in captured startup logs; full Canvas rendering remains unverified. No Android gameplay inputs, purchase/earnings, progression, save/reload, offline or Legacy checks succeeded on this attempt. Those systems passed the separately executed engine/desktop UI tests. Physical-device behavior, mobile performance and touchscreen behavior remain untested.

Evidence is in `tests/results/android/recovery-notes.txt`, `failure-extract.txt`, `godot-graphics-extract.txt`, `swangle-game.png`, `swangle-engine-progress.txt` and `swangle-final-crash.txt`. Original partial save and full diagnostic logs remain in the workspace. The source archive excludes large raw logs and the preserved private save. No application source change, reinstall or APK rebuild was performed during resumed validation.
