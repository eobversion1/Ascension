# ASCENSION — From Beggar to God-Emperor

A playable Godot 4.6.3 portrait idle strategy game. The first chapter spans **Survival → Enterprise → Local Influence**, with seven ranks, six automated enterprises, fifteen upgrades, four exclusive strategic policies, six repeatable trade contracts, three negotiating factions and a repeatable Legacy system. Later cosmic eras remain a roadmap.

**Version 0.3:** timed trade contracts, three-round faction negotiations, optional trade automation, changing world artwork and compact mobile navigation. See [v0.3 validation](docs/VALIDATION_V03.md), [economy audit](docs/ECONOMY_V03.md) and [changelog](docs/CHANGELOG_V03.md).

**Android debug APK:** `build/android/ASCENSION-debug.apk` (Android 7.0/API 24 or newer; ARM64, ARMv7 and x86_64). The build is signed and its signature, alignment and manifest are verified. See [verification record](docs/DEVELOPMENT_LOG.md) for the precise runtime/device testing status.

## Play

Open `project.godot` with **Godot 4.6.3 stable**, then press F5. No external assets, services or dependencies are needed for desktop gameplay.

1. Tap **WORK** fifteen times and buy a **Street Stall** in Empire. It immediately earns coins automatically.
2. Follow the persistent **NEXT** milestone button. Eligible **ASCEND NOW** promotes directly. Ascend shows cumulative requirements and an estimated passive wait; promotion does not consume your resources.
3. At Street Scavenger, open **Ventures** and dispatch a salvage route. Capital is committed until arrival; safe routes guarantee profit, while shortcuts trade risk and civic rewards for more coins.
4. At Street Vendor, use **Ventures → Negotiate**. Read each round, keep tension below three and reach six agreement for trust. Delegates rest between sessions.
5. Reinvest in stalls, Workshops and production upgrades. Decisions unlock at Street Vendor. Enterprise introduces reputation networks and resource conversions; Guildmaster unlocks influence campaigns.
6. Complete Civic Leader and confirm **Begin New Legacy** to restart with another permanent +25% output. Reset is a separate, confirmed action that also erases Legacy.

There are no ads, in-app payments, accounts or Android permissions. Closing or backgrounding the app awards up to eight hours of idle production at 75% efficiency on return. **Pause** intentionally suspends both active and offline earnings. Autosave runs every fifteen seconds and on purchases, promotion and backgrounding.

## Cloud workspace

The supplied environment retains a verified Android toolchain beside the project at `/workspace/.ascension`:

```bash
cd /workspace/Ascension
./tools/setup_environment.sh
./tools/godot.sh --headless --path . --script res://tests/smoke_tests.gd
./tools/godot.sh --headless --path . --script res://tests/activities_tests.gd
./tools/godot.sh --headless --path . --script res://tests/balance_v03.gd
./tools/build_android.sh
```

`tools/godot.sh` places writable Godot data/config/cache outside the repository. Set `ASCENSION_TOOLS_DIR` to relocate this directory. `setup_environment.sh` reuses the retained tools and configures the editor; it reports missing tools instead of pretending to install them. Fresh-machine installation and APK verification are documented in [ANDROID_BUILD.md](docs/ANDROID_BUILD.md).

Rendered UI checks use an X11 display:

```bash
DISPLAY=:99 ./tools/godot.sh --audio-driver Dummy --path . --script res://tests/ui_tests.gd
```

The environment's optional Xvfb binary is `/workspace/.ascension/xserver/usr/bin/Xvfb`. Start it with `:99 -screen 0 1080x1920x24 -nolisten tcp` if the display is absent. This test injects real pointer events, checks layouts at 420×820, 360×800, 360×640 and 420×1000, tests background/resume and writes PNG captures into `tests/results`. These automated tests are distinct from a human phone playtest.

## Verified progression

The actual GDScript economy was simulated from zero, with fifteen initial WORK taps and investment visits every fifteen seconds. Without activities, the economy policy reaches Civic Leader in **20m15s** and the influence policy in **38m**. With trade and diplomacy, those policies finish in **19m** and **34m15s**, respectively. Both complete all seven ranks and remain finite at five minutes, twenty minutes, forty-five minutes, two hours and one day. These are deterministic policy results, not predicted completion times for every player. See [the v0.3 economy audit](docs/ECONOMY_V03.md) and the JSON evidence in `tests/results/v03`.

Save schema 2 migrates version-1 progress with a one-time `.pre-v03.json` backup. Active orders, their fixed risk outcomes, negotiation rounds and relationships persist. Malformed saves recover from a valid backup; unreadable or newer-version saves are preserved and saving is blocked until recovery or an explicit Reset. The game displays that condition. Local device time is trusted within the eight-hour cap; it is not tamper-proof.

## Project map

- `scripts/game.gd`: economy, progression, versioned saves and offline accrual.
- `scripts/content.gd`: ranks, generators, upgrades, decisions and achievements.
- `scripts/big_number.gd`: nonnegative scientific numbers beyond `1e308`.
- `scripts/activities.gd`: trade, negotiation, relationships and chronological activity time.
- `scripts/main.gd`, `scenes/main.tscn`: native mobile UI and application lifecycle.
- `tests/`: engine smoke/regression tests, balance simulation and rendered UI tests.
- `docs/GAME_DESIGN.md`: current chapter design, scope and next improvements.

Remaining work: physical-device ergonomics/performance and OEM lifecycle testing; guided first-session teaching; the next administrative gameplay layer. There is no sound system or later monarchy/space/divine gameplay in this chapter.

Engine and bundled third-party licence notices are included in `assets/licenses` and the APK. The three world scenes were generated for this project; original vector icons and licensed fonts remain bundled. See `assets/world/README.md`.
