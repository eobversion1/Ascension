## Optional chapter activities. State is plain JSON; all time enters through advance().
## Principal returns never count as lifetime earnings. Quotes/outcomes freeze at dispatch.
class_name AscensionActivities
extends RefCounted
const BN = preload("res://scripts/big_number.gd")
const OFFERS = [
 {"id":"salvage","name":"Lantern salvage","rank":1,"cost":18.0,"profit":12.0,"seconds":30.0,"reputation":0.0,"influence":0.0,"story":"Recover brass and glass before the market opens."},
 {"id":"provisions","name":"Market provisions","rank":2,"cost":120.0,"profit":75.0,"seconds":60.0,"reputation":2.0,"influence":0.0,"story":"Supply the night market. Reliable deliveries make your name."},
 {"id":"caravan","name":"River caravan","rank":3,"cost":800.0,"profit":420.0,"seconds":120.0,"reputation":6.0,"influence":0.0,"story":"Commit working capital to a profitable route beyond the walls."},
 {"id":"relief","name":"Winter relief","rank":3,"cost":450.0,"profit":45.0,"seconds":90.0,"reputation":18.0,"influence":0.0,"story":"Accept a modest margin to earn lasting public trust."},
 {"id":"charter","name":"Guild commission","rank":4,"cost":3500.0,"profit":1500.0,"seconds":180.0,"reputation":25.0,"influence":2.0,"story":"Provision the guild's public works and gain a voice in its affairs."},
 {"id":"envoy","name":"Civic delegation","rank":5,"cost":10000.0,"profit":2500.0,"seconds":240.0,"reputation":60.0,"influence":12.0,"story":"Finance a delegation that carries your authority beyond the city."}
]
const FACTIONS = [
 {"id":"merchants","name":"Merchant League","rank":2,"trait":"Each trust: +3% coin production and +5% contract profit.","scene":"A ledger closes. The League asks what your word is worth."},
 {"id":"commons","name":"Neighbourhood Assembly","rank":2,"trait":"Each trust: +5% reputation production.","scene":"Lanterns gather in the square. The neighbourhood wants to be heard."},
 {"id":"council","name":"City Council","rank":4,"trait":"Each trust: +5% influence production.","scene":"Behind carved doors, councillors weigh your growing authority."}
]
const NEEDS = ["security", "recognition", "profit"]
const PROMPTS = {
 "security":"They fear a broken promise. A funded concession reassures them.",
 "recognition":"They want public respect. A concession earns more than pressure.",
 "profit":"They want a profitable agreement. A firm bargain can win ground, but raises tension."
}
static func fresh() -> Dictionary:
 return {"serial":0,"revision":0,"orders":[],"completed":0,"profits":BN.zero(),"losses":0,"trust":{"merchants":0,"commons":0,"council":0},"negotiation":{},"cooldown":0.0,"talks":0,"report":"Trade routes and delegates await your orders."}
static func definition(id: String) -> Dictionary:
 for offer in OFFERS:
  if offer["id"]==id:return offer
 return {}
static func capacity(g) -> int:
 return 3 if g.rank()>=5 else 2 if g.rank()>=3 else 1
static func lots_limit(g) -> int:
 return 20 if g.rank()>=4 and int(g.state["activities"]["trust"]["merchants"])>=2 else 5 if g.rank()>=3 else 1
static func quote(g, id: String, route: String, lots: int) -> Dictionary:
 var offer: Dictionary = definition(id)
 if offer.is_empty() or route not in ["safe","venture"] or lots not in [1,5,20] or lots>lots_limit(g):return {}
 var trust: int = int(g.state["activities"]["trust"]["merchants"])
 var profit: float = float(offer["profit"])*lots*g.modifier("global")*g.modifier("res_coins")*(1.0+0.05*trust)
 var risk: float = maxf(0.10,0.25-0.03*trust) if route=="venture" else 0.0
 return {"id":id,"route":route,"lots":lots,"cost":BN.of(float(offer["cost"])*lots),"profit":BN.of(profit*(2.0 if route=="venture" else 1.0)),"reputation":BN.of(float(offer["reputation"])*sqrt(float(lots))*g.modifier("global")*g.modifier("res_reputation")*(0.5 if route=="venture" else 1.0)),"influence":BN.of(float(offer["influence"])*sqrt(float(lots))*g.modifier("global")*g.modifier("res_influence")*(0.5 if route=="venture" else 1.0)),"duration":float(offer["seconds"])*(0.8 if route=="venture" else 1.0),"risk":risk}
static func start_trade(g,id: String,route: String,lots: int,expected_serial: int=-1) -> bool:
 var a: Dictionary = g.state["activities"]
 var offer: Dictionary = definition(id)
 if g.state["paused"] or g.persistence_blocked or offer.is_empty() or g.rank()<int(offer["rank"]) or a["orders"].size()>=capacity(g):return false
 if expected_serial>=0 and int(a["serial"])!=expected_serial:return false
 var q: Dictionary = quote(g,id,route,lots)
 if q.is_empty() or not g._pay({"coins":q["cost"]}):return false
 a["serial"]+=1
 q["serial"]=a["serial"];q["remaining"]=q["duration"];q["repeat"]=false
 q["loss"] = randf()<float(q["risk"]) # Sample once; save/reload cannot reroll it.
 a["orders"].append(q);a["revision"]+=1
 g.add_log("Dispatched %s ×%d. Capital is committed until delivery." % [offer["name"],lots])
 return true
static func toggle_repeat(g, serial: int) -> bool:
 if g.state["paused"] or not g.state["upgrades"].has("trade_clerk"):return false
 for order in g.state["activities"]["orders"]:
  if int(order["serial"])==serial:
   order["repeat"]=not order["repeat"];g.state["activities"]["revision"]+=1
   g.add_log("Trade Clerk: repeat "+("enabled." if order["repeat"] else "disabled."));return true
 return false
static func advance(g, seconds: float) -> void:
 var a: Dictionary = g.state["activities"]
 var left: float = seconds
 while left>0.000001:
  var step: float = left
  for order in a["orders"]:step=minf(step,maxf(0.0,float(order["remaining"])))
  g._accrue(step)
  a["cooldown"]=maxf(0.0,float(a["cooldown"])-step)
  for order in a["orders"]:order["remaining"]=maxf(0.0,float(order["remaining"])-step)
  left-=step
  var deliveries: Array = a["orders"].filter(func(o):return float(o["remaining"])<=0.000001)
  for order in deliveries:
   a["orders"].erase(order)
   var name: String = definition(order["id"])["name"]
   if order["loss"]:
    g.state["resources"]["coins"]=BN.add(g.resource("coins"),BN.times(order["cost"],0.85))
    a["losses"]+=1
    a["report"]="%s delayed and damaged: 85%% of capital returned. No profit or civic reward." % name
   else:
    g.state["resources"]["coins"]=BN.add(g.resource("coins"),order["cost"])
    g.gain("coins",order["profit"]);g.gain("reputation",order["reputation"]);g.gain("influence",order["influence"])
    a["profits"]=BN.add(a["profits"],order["profit"])
    a["report"]="%s delivered. +%s coins profit; your capital returned." % [name,BN.pretty(order["profit"])]
   a["completed"]+=1;a["revision"]+=1;g.add_log(a["report"])
   if order["repeat"] and g.state["upgrades"].has("trade_clerk"):
    if start_trade(g,order["id"],order["route"],int(order["lots"])):
     a["orders"][-1]["repeat"]=true
    else:
     a["report"]+=" Clerk stopped: insufficient capital. No debt incurred."
  if step<=0.0 and deliveries.is_empty():break
static func begin_talk(g,faction: String) -> bool:
 var a: Dictionary=g.state["activities"]
 if g.state["paused"] or g.persistence_blocked or not a["negotiation"].is_empty() or float(a["cooldown"])>0.001:return false
 for f in FACTIONS:
  if f["id"]==faction and g.rank()>=int(f["rank"]):
   a["serial"]+=1
   a["negotiation"]={"faction":faction,"round":0,"score":0,"tension":0,"serial":a["serial"],"pattern":int(a["talks"])%3}
   a["revision"]+=1;g.add_log("Delegates seated: "+f["name"]+".");return true
 return false
static func talk_need(g) -> String:
 var n: Dictionary=g.state["activities"]["negotiation"]
 return "" if n.is_empty() else NEEDS[(int(n["round"])+int(n["pattern"]))%3]
static func talk_options(g) -> Array[Dictionary]:
 var need: String=talk_need(g)
 var cost: float=[0.0,0.0,25.0,80.0,300.0,800.0,800.0][g.rank()]
 return [
  {"id":"listen","title":"Listen and mediate","cost":{},"score":1,"tension":-1},
  {"id":"concede","title":"Fund a concession","cost":{"coins":BN.of(cost)},"score":2 if need=="profit" else 3,"tension":-1},
  {"id":"bargain","title":"Drive a hard bargain","cost":{},"score":3 if need=="profit" else 0,"tension":2}
 ]
static func respond(g,id: String,round_expected: int=-1,serial_expected: int=-1) -> bool:
 var a: Dictionary=g.state["activities"]
 var n: Dictionary=a["negotiation"]
 if g.state["paused"] or g.persistence_blocked or n.is_empty():return false
 if round_expected>=0 and int(n["round"])!=round_expected:return false
 if serial_expected>=0 and int(n["serial"])!=serial_expected:return false
 var selected: Dictionary={}
 for o in talk_options(g):
  if o["id"]==id:selected=o
 if selected.is_empty() or not g._pay(selected["cost"]):return false
 n["score"]+=selected["score"];n["tension"]=maxi(0,int(n["tension"])+int(selected["tension"]));n["round"]+=1;a["revision"]+=1
 if int(n["round"])<3 and int(n["tension"])<3:
  g.add_log("Negotiation: %d agreement, %d tension." % [int(n["score"]),int(n["tension"])]);return true
 var success: bool=int(n["score"])>=6 and int(n["tension"])<3
 var cordial: bool=int(n["score"])>=3 and int(n["tension"])<3
 var faction: String=n["faction"]
 var scale: float=1.0 if success else 0.25 if cordial else 0.0
 if success:a["trust"][faction]=mini(5,int(a["trust"][faction])+1)
 for r in talk_reward(g,faction):g.gain(r,BN.times(talk_reward(g,faction)[r],scale))
 a["talks"]+=1;a["cooldown"]=90.0 if g.rank()>=5 else 120.0
 a["report"]=("Accord signed: +1 trust (max 5). " if success else "A cordial hearing: a small goodwill reward, no trust. " if cordial else "Talks broke down under pressure. No reward. ")+"Delegates return after a short rest."
 g.add_log(a["report"]);a["negotiation"]={}
 return true
static func talk_reward(g,faction: String) -> Dictionary:
 var reward: Dictionary={"coins":0.0,"reputation":0.0,"influence":0.0}
 if faction=="merchants":reward={"coins":[0,0,70,220,800,2000,2000][g.rank()],"reputation":4.0,"influence":0.0}
 elif faction=="commons":reward={"coins":0.0,"reputation":12.0,"influence":1.0 if g.rank()>=4 else 0.0}
 else:reward={"coins":0.0,"reputation":8.0,"influence":4.0}
 var bag: Dictionary={}
 for r in reward:
  if float(reward[r])>0:bag[r]=BN.of(float(reward[r])*g.modifier("global"))
 return bag

static func valid(a: Variant) -> bool:
 if not a is Dictionary:return false
 for key in ["serial","revision","completed","losses","talks"]:
  var v: Variant=a.get(key)
  if not (v is int or v is float) or not is_finite(float(v)) or float(v)<0 or float(v)>1e12 or float(v)!=floor(float(v)):return false
 if not BN.valid(a.get("profits")) or not a.get("report") is String or not a.get("trust") is Dictionary:return false
 if not a.get("cooldown") is float and not a.get("cooldown") is int:return false
 if not is_finite(float(a["cooldown"])) or float(a["cooldown"])<0 or float(a["cooldown"])>120:return false
 for f in FACTIONS:
  var v: Variant=a["trust"].get(f["id"])
  if not (v is int or v is float) or not is_finite(float(v)) or float(v)<0 or float(v)>5 or float(v)!=floor(float(v)):return false
 if not a.get("orders") is Array or a["orders"].size()>3:return false
 var ids: Array=[]
 for o in a["orders"]:
  if not o is Dictionary or definition(str(o.get("id",""))).is_empty():return false
  if o.get("route") not in ["safe","venture"]:return false
  if not (o.get("lots") is int or o.get("lots") is float):return false
  if not is_finite(float(o["lots"])) or float(o["lots"])!=floor(float(o["lots"])) or int(o["lots"]) not in [1,5,20]:return false
  for k in ["cost","profit","reputation","influence"]:
   if not BN.valid(o.get(k)):return false
  for k in ["duration","remaining","risk","serial"]:
   if not (o.get(k) is int or o.get(k) is float) or not is_finite(float(o[k])):return false
  if o["duration"]<1 or o["duration"]>3600 or o["remaining"]<0 or o["remaining"]>o["duration"] or o["risk"]<0 or o["risk"]>0.25:return false
  if o["serial"]<1 or o["serial"]>a["serial"] or float(o["serial"])!=floor(float(o["serial"])) or o["serial"] in ids:return false
  if not o.get("repeat") is bool or not o.get("loss") is bool:return false
  ids.append(o["serial"])
 var n: Variant=a.get("negotiation")
 if not n is Dictionary:return false
 if not n.is_empty():
  if n.get("faction") not in ["merchants","commons","council"]:return false
  for k in ["round","score","tension","serial","pattern"]:
   if not (n.get(k) is int or n.get(k) is float) or not is_finite(float(n[k])) or float(n[k])!=floor(float(n[k])):return false
  if n["round"]<0 or n["round"]>2 or n["score"]<0 or n["score"]>9 or n["tension"]<0 or n["tension"]>2 or n["pattern"]<0 or n["pattern"]>2 or n["serial"]<1 or n["serial"]>a["serial"]:return false
 return true
