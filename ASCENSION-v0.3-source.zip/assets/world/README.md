# World artwork

`ascension-eras.png` was generated for ASCENSION v0.3 using the image generation tool. It contains three equal panels: poverty/alley, commerce/harbour, and political power/citadel. Godot AtlasTexture regions select panels at runtime; the original image is not destructively cropped. The smaller SVG studies are original project artwork. Font and engine notices remain in assets/licenses.
