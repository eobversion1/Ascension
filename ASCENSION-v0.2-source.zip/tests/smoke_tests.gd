## Run: godot --headless --path . --script res://tests/smoke_tests.gd
extends SceneTree

const BN = preload("res://scripts/big_number.gd")
const Game = preload("res://scripts/game.gd")

var failures: Array[String] = []
var checks: int = 0

func _initialize() -> void:
	_test_large_number()
	_test_income_and_choices()
	_test_save_offline()
	_test_regressions()
	_test_corruption_and_offline()
	_test_all_content_and_legacy()
	_test_promotion_v02()
	if failures.is_empty():
		print("PASS: %d ASCENSION economy/saving assertions passed." % checks)
		quit(0)
	else:
		for failure in failures:
			push_error("FAIL: " + failure)
		quit(1)

func expect(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures.append(message)

func near(value: float, target: float, tolerance: float = 0.0001) -> bool:
	return absf(value - target) <= tolerance

func _test_large_number() -> void:
	var huge: Dictionary = BN.power_price(100.0, 10.0, 500)
	expect(int(huge["e"]) == 502, "Exponent representation for 10^502")
	expect(BN.compare(huge, BN.of(1.0e100)) > 0, "Huge numbers compare correctly")
	expect(BN.compare(BN.subtract(BN.of(150.0), BN.of(30.0)), BN.of(120.0)) == 0, "Simple subtraction")
	expect(BN.compare(BN.subtract(BN.of(5.0), BN.of(8.0)), BN.zero()) == 0, "No negative resource values")
	expect(BN.ratio_capped(BN.of(20.0), BN.of(100.0)) > 0.19, "Progress ratios")

func _test_income_and_choices() -> void:
	var g = Game.new()
	expect(BN.compare(g.resource("coins"), BN.zero()) == 0, "Begin destitute")
	g.work()
	expect(BN.compare(g.resource("coins"), BN.of(1.0)) == 0, "Manual work earns coins")
	g.gain("coins", BN.of(1000.0))
	expect(g.buy_generator("street_stall"), "First stall purchasable")
	var before: Dictionary = g.income_of("coins")
	g.tick(10.0)
	expect(BN.compare(g.resource("coins"), BN.of(988.0)) > 0, "Recurring production actually pays")
	expect(BN.compare(g.income_of("coins"), before) == 0, "Tick leaves generator rate unchanged")
	expect(g.buy_upgrade("warm_clothes"), "Manual multiplier purchasable")
	expect(BN.compare(g.tap_amount(), BN.of(2.0)) == 0, "Manual multiplier applies")
	# Grant milestones to validate rank gating and exclusive decisions.
	g.gain("coins", BN.of(1000000.0))
	for _i in 2:
		expect(g.buy_generator("street_stall"), "Buy milestone stalls")
	expect(g.promote(), "Promote to Scavenger")
	expect(g.promote(), "Promote to Vendor")
	expect(g.buy_upgrade("better_suppliers"), "Coin modifier purchasable")
	var multiplied: Dictionary = g.income_of("coins")
	expect(BN.compare(multiplied, before) > 0, "Upgrade raises production")
	expect(g.choose("first_contract", "profit"), "First strategic choice")
	expect(not g.choose("first_contract", "patrons"), "Mutually exclusive strategic choice")
	expect(BN.compare(g.income_of("coins"), multiplied) > 0, "Chosen strategy changes resource output")

func _test_save_offline() -> void:
	var g = Game.new()
	g.save_path = "user://ascension_smoke_test.json"
	g.backup_path = "user://ascension_smoke_test.bak.json"
	g.gain("coins", BN.of(100.0))
	expect(g.buy_generator("street_stall"), "Persistent generator bought")
	expect(g.save_game(), "Save succeeded")
	var load = Game.new()
	load.save_path = g.save_path
	load.backup_path = g.backup_path
	load.load_or_new()
	expect(load.loaded_from_save, "Restores existing save")
	expect(load.own("street_stall") == 1, "Generator count restored")
	# Artificially age save; ensure the elapsed time cannot be credited uncapped.
	var doc: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(g.save_path))
	doc["saved_at"] = Time.get_unix_time_from_system() - 1000000.0
	var f := FileAccess.open(g.save_path, FileAccess.WRITE)
	f.store_string(JSON.stringify(doc))
	f.close()
	var reloaded = Game.new()
	reloaded.save_path = g.save_path
	reloaded.backup_path = g.backup_path
	reloaded.load_or_new()
	var expected_max: Dictionary = BN.of(100.0 + 0.32 * 28800.0 * 0.75)
	expect(BN.compare(reloaded.resource("coins"), expected_max) <= 0, "Offline rewards limited to 8h")
	expect(reloaded.loaded_from_save, "Save remains readable after offline earnings")
	DirAccess.remove_absolute(ProjectSettings.globalize_path(g.save_path))
	if FileAccess.file_exists(g.backup_path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(g.backup_path))

func _test_regressions() -> void:
	expect(not BN.valid({"m":1.0,"e":NAN}), "Reject nonfinite exponent")
	expect(not BN.valid({"m":1.0,"e":1.5}), "Reject fractional exponent")
	expect(BN.compare(BN.of(99.9999), BN.of(100.0)) < 0, "Do not round insufficient funds up to the price")
	var g = Game.new()
	g.gain("coins", BN.of(14.99999))
	expect(not g.buy_generator("street_stall"), "Purchase rejects slightly insufficient funds")
	g.gain("coins", BN.of(100.0))
	g.buy_generator("street_stall")
	var before: Dictionary = g.resource("coins").duplicate()
	for invalid in [-1.0, NAN, INF]: g.tick(invalid)
	g.tick(10.0, -1.0)
	g.tick(10.0, INF)
	expect(BN.compare(g.resource("coins"), before) == 0, "Invalid time and efficiency cannot mint currency")
	var split = Game.new()
	split.state = g.state.duplicate(true)
	g.tick(10.0)
	for i in 100: split.tick(0.1)
	expect(BN.compare(g.resource("coins"), split.resource("coins")) == 0, "Frame-rate independent income")
	g.state["paused"] = true
	before = g.resource("coins").duplicate()
	g.tick(100.0)
	g.work()
	expect(BN.compare(g.resource("coins"), before) == 0, "Pause stops active and passive earnings")
	expect(not g.buy_generator("civic_hall"), "Locked generator cannot be bought")
	expect(not g.choose("election", "grassroots"), "Locked choice cannot be selected")
	expect(not g.legacy_reset(), "No free Legacy before final rank")

func _write_doc(path: String, doc: Dictionary) -> void:
	var f := FileAccess.open(path, FileAccess.WRITE)
	f.store_string(JSON.stringify(doc))
	f.close()

func _test_corruption_and_offline() -> void:
	var g = Game.new()
	g.save_path = "user://regression.json"
	g.backup_path = "user://regression.bak.json"
	for path in [g.save_path, g.backup_path]:
		if FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	g.gain("coins", BN.of(1000.0))
	g.buy_generator("street_stall")
	var valid: Dictionary = g.state.duplicate(true)
	for field in ["version", "rank", "legacy_points", "completed_runs", "saved_at"]:
		var malformed: Dictionary = valid.duplicate(true)
		malformed[field] = {"bad":true}
		_write_doc(g.save_path, malformed)
		expect(not g._load_from_path(g.save_path), "Corrupt " + field + " rejected without runtime error")
	var malformed: Dictionary = valid.duplicate(true)
	malformed["generators"]["street_stall"] = []
	_write_doc(g.save_path, malformed)
	expect(not g._load_from_path(g.save_path), "Corrupt owned count rejected")
	g.load_or_new()
	expect(g.persistence_blocked and not g.save_game(), "Unreadable save is preserved instead of overwritten")
	g.new_game()
	g.state = valid.duplicate(true)
	g.state["decisions"]["unknown"] = "fake"
	g.state["log"] = ["valid", 10, {}]
	g.save_game()
	g.load_or_new()
	expect(not g.state["decisions"].has("unknown"), "Unknown choice cannot satisfy milestone")
	expect(g.state["log"].size() == 1, "Invalid log entries removed")
	# Recover the backup and preserve resources/Legacy.
	valid["legacy_points"] = 3
	_write_doc(g.backup_path, valid)
	_write_doc(g.save_path, {"bad":true})
	g.load_or_new()
	expect(g.loaded_from_save and int(g.state["legacy_points"]) == 3, "Corrupt primary restores intact backup and Legacy")
	var future: Dictionary = valid.duplicate(true)
	future["version"] = 999
	_write_doc(g.save_path, future)
	var bytes: String = FileAccess.get_file_as_string(g.save_path)
	g.load_or_new()
	expect(g.persistence_blocked and not g.save_game(), "Newer save is never downgraded via backup")
	expect(FileAccess.get_file_as_string(g.save_path) == bytes, "Newer save remains byte-for-byte intact")
	g.new_game()
	valid["saved_at"] = Time.get_unix_time_from_system() - 1000000.0
	_write_doc(g.save_path, valid)
	g.load_or_new()
	var rewarded: Dictionary = g.resource("coins").duplicate()
	var expected: Dictionary = BN.add(valid["resources"]["coins"], BN.of(0.32 * 28800.0 * 0.75 * 1.75))
	expect(BN.compare(rewarded, expected) == 0, "Offline reward equals the 8-hour cap")
	g.load_or_new()
	expect(BN.compare(g.resource("coins"), rewarded) == 0, "Reload cannot duplicate offline award")
	valid["saved_at"] = Time.get_unix_time_from_system() + 10000.0
	_write_doc(g.save_path, valid)
	g.load_or_new()
	expect(BN.compare(g.resource("coins"), valid["resources"]["coins"]) == 0, "Backward clock awards no resources")
	valid["saved_at"] = Time.get_unix_time_from_system() - 100000.0
	valid["paused"] = true
	_write_doc(g.save_path, valid)
	g.load_or_new()
	expect(BN.compare(g.resource("coins"), valid["resources"]["coins"]) == 0, "Paused saves earn no offline rewards")
	for path in [g.save_path, g.backup_path]: DirAccess.remove_absolute(ProjectSettings.globalize_path(path))

func _test_all_content_and_legacy() -> void:
	var g = Game.new()
	g.save_path = "user://legacy_test.json"
	g.backup_path = "user://legacy_test.bak.json"
	g.state["rank"] = 6
	for r in ["coins", "reputation", "influence"]: g.gain(r, BN.of(1.0e9))
	for gen in g.DATA.GENERATORS: expect(g.buy_generator(gen["id"]), "Generator works: " + gen["id"])
	for upgrade in g.DATA.UPGRADES:
		var before: Dictionary = g.income_rates()
		var tap_before: Dictionary = g.tap_amount()
		expect(g.buy_upgrade(upgrade["id"]), "Upgrade works: " + upgrade["id"])
		var changes: bool = BN.compare(tap_before, g.tap_amount()) != 0
		for r in before: changes = changes or BN.compare(before[r], g.income_of(r)) != 0
		expect(changes, "Upgrade changes real output: " + upgrade["id"])
		var coins: Dictionary = g.resource("coins").duplicate()
		expect(not g.buy_upgrade(upgrade["id"]), "Upgrade cannot be bought twice")
		expect(BN.compare(coins, g.resource("coins")) == 0, "Duplicate purchase does not spend")
	for d in g.DATA.DECISIONS:
		expect(g.choose(d["id"], d["options"][0]["id"]), "Decision works: " + d["id"])
		expect(not g.choose(d["id"], d["options"][1]["id"]), "Decision alternatives remain exclusive")
	g.state["legacy_points"] = 2
	var actual_path: String = g.save_path
	g.save_path = "user://no-such-legacy-directory/save.json"
	expect(not g.legacy_reset() and g.rank()==6 and int(g.state["legacy_points"])==2, "Failed Legacy save preserves previous life and prestige")
	g.save_path = actual_path
	expect(g.legacy_reset(), "Completed chapter grants Legacy")
	expect(int(g.state["legacy_points"]) == 3 and g.rank() == 0, "Legacy preserves previous points and resets run")
	expect(g.own("street_stall") == 0 and g.state["decisions"].is_empty(), "Legacy resets enterprises and choices")
	expect(near(g.modifier("global"), 1.75), "All Legacy points contribute +25% each")
	g.load_or_new()
	expect(int(g.state["legacy_points"]) == 3, "Legacy survives save/reload")
	for path in [g.save_path, g.backup_path]:
		if FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))

func _test_promotion_v02() -> void:
	var g = Game.new()
	g.save_path = "user://promotion-v02.json"
	g.backup_path = "user://promotion-v02.bak.json"
	g.gain("coins", BN.of(2350.0))
	g.state["generators"]["street_stall"] = 20
	expect(float(g.DATA.RANKS[1]["needs"]["coins_total"]) == 30.0, "Reported defect is not concealed by changing the 30-coin requirement")
	expect(int(g.DATA.RANKS[1]["needs"]["gen_street_stall"]) == 1, "Original one-stall gate remains intact")
	expect(g.can_promote() and g.milestone_percent() == 100, "Reported 2350-coin/20-stall save is eligible")
	var balance: Dictionary = g.resource("coins").duplicate()
	expect(g.promote(0) and g.rank() == 1, "Expected-rank promotion advances exactly one rank")
	expect(not g.promote(0) and g.rank() == 1, "Repeated stale tap cannot skip into another eligible rank")
	expect(BN.compare(balance, g.resource("coins")) == 0, "Promotion never consumes currency")
	expect(g.own("street_stall") == 20, "Promotion preserves owned assets")
	expect(near(float(g.tap_amount()["m"]), 1.5), "Scavenger unlock grants real +50% manual income")
	expect(g.save_game(), "Promotion save persists")
	g.load_or_new()
	expect(g.rank() == 1 and g.own("street_stall") == 20, "Restart restores rank and assets")
	expect(g.buy_upgrade("better_location"), "Promotion unlocks the correct economic upgrade")
	g.new_game()
	g.gain("coins", BN.of(2350.0))
	expect(not g.can_promote() and not g.promote(0), "Coins alone cannot bypass missing stall")
	expect(g.milestone_percent() < 100, "Incomplete ownership requirement never displays 100 percent")
	g.new_game()
	g.gain("coins", BN.of(29.999))
	g.state["generators"]["street_stall"] = 1
	expect(not g.can_promote() and g.milestone_percent() == 99, "Near-threshold rounding cannot falsely display completion")
	expect(not g.promote(0) and g.rank() == 0, "Unsuccessful promotion leaves rank unchanged")
	var old: Dictionary = g.state.duplicate(true)
	old.erase("app_version")
	old["rank"] = 1
	old["legacy_points"] = 3
	_write_doc(g.save_path, old)
	g.load_or_new()
	expect(g.rank() == 1 and int(g.state["legacy_points"]) == 3, "Version-1 save retains rank and Legacy on update")
	expect(FileAccess.file_exists(g.save_path + ".pre-v02.json"), "Pre-update save backup is created")
	var preserved: Variant = JSON.parse_string(FileAccess.get_file_as_string(g.save_path + ".pre-v02.json"))
	expect(preserved is Dictionary and not preserved.has("app_version"), "Update backup preserves original schema fields")
	for path in [g.save_path, g.backup_path, g.save_path + ".pre-v02.json"]:
		if FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
