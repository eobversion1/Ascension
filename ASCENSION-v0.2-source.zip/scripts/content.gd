## All early-game progression data. Append eras without restructuring the economy.
class_name AscensionContent
extends RefCounted

const RESOURCES = ["coins", "reputation", "influence"]
const RANKS = [
	{"id":"beggar", "name":"Homeless Beggar", "era":"Survival", "objective":"Earn the first coins by working.", "needs":{}},
	{"id":"scavenger", "name":"Street Scavenger", "era":"Survival", "objective":"Begin investing in recurring income.", "needs":{"coins_total":30.0, "gen_street_stall":1}},
	{"id":"vendor", "name":"Street Vendor", "era":"Survival", "objective":"Turn tiny earnings into a functioning business.", "needs":{"coins_total":350.0, "gen_street_stall":3}},
	{"id":"trader", "name":"Independent Trader", "era":"Enterprise", "objective":"Build a trade network. Reputation is now possible.", "needs":{"coins_total":2800.0, "gen_workshop":2}},
	{"id":"guildmaster", "name":"Guildmaster", "era":"Enterprise", "objective":"Recruit allies and dominate the city's markets.", "needs":{"coins_total":18000.0, "reputation_total":65.0, "gen_trading_post":2}},
	{"id":"advocate", "name":"Civic Advocate", "era":"Local Influence", "objective":"Convert reputation into influence and public support.", "needs":{"coins_total":75000.0, "reputation_total":420.0, "influence_total":16.0, "gen_campaign_office":1}},
	{"id":"civic_leader", "name":"Civic Leader", "era":"Local Influence", "objective":"A foundation for the next age of political power.", "needs":{"coins_total":250000.0, "reputation_total":1700.0, "influence_total":120.0, "choices":2}}
]

const GENERATORS = [
	{"id":"street_stall","name":"Street Stall","description":"Small, regular sales turn survival into a livelihood.","rank":0,"cost":{"coins":15.0},"growth":1.15,"output":{"coins":0.32}},
	{"id":"workshop","name":"Workshop","description":"Employ craftspeople and scale production.","rank":2,"cost":{"coins":220.0},"growth":1.17,"output":{"coins":2.4}},
	{"id":"trading_post","name":"Trading Post","description":"Wide trade routes produce accelerating revenue.","rank":3,"cost":{"coins":2400.0},"growth":1.19,"output":{"coins":16.0}},
	{"id":"rumour_network","name":"Rumour Network","description":"Patrons and relationships generate a reputation stream.","rank":3,"cost":{"coins":1800.0},"growth":1.16,"output":{"reputation":0.26}},
	{"id":"campaign_office","name":"Campaign Office","description":"Translate goodwill into political influence.","rank":4,"cost":{"coins":14000.0,"reputation":75.0},"growth":1.21,"output":{"influence":0.052,"reputation":0.096}},
	{"id":"civic_hall","name":"Civic Hall","description":"A durable institution that builds public legitimacy.","rank":5,"cost":{"coins":65000.0,"reputation":450.0},"growth":1.23,"output":{"influence":0.6,"reputation":1.0}}
]

const UPGRADES = [
	{"id":"warm_clothes","name":"Warm Clothes","rank":0,"description":"Make each manual effort count twice.","cost":{"coins":12.0},"mods":{"tap":2.0}},
	{"id":"route_scouting","name":"Route Scouting","rank":0,"description":"Find better-paid work: +75% manual earnings.","cost":{"coins":45.0},"mods":{"tap":1.75}},
	{"id":"better_location","name":"Better Location","rank":1,"description":"Double Street Stall production.","cost":{"coins":95.0},"mods":{"gen_street_stall":2.0}},
	{"id":"better_suppliers","name":"Better Suppliers","rank":2,"description":"All coin-producing assets earn 25% more.","cost":{"coins":320.0},"mods":{"res_coins":1.25}},
	{"id":"sturdy_tools","name":"Sturdy Tools","rank":2,"description":"Double Workshop production.","cost":{"coins":720.0},"mods":{"gen_workshop":2.0}},
	{"id":"trained_staff","name":"Trained Staff","rank":2,"description":"Another 80% Workshop production.","cost":{"coins":2000.0},"mods":{"gen_workshop":1.8}},
	{"id":"commercial_ledger","name":"Commercial Ledger","rank":3,"description":"Double Trading Post production.","cost":{"coins":4300.0},"mods":{"gen_trading_post":2.0}},
	{"id":"reliable_messengers","name":"Reliable Messengers","rank":3,"description":"Double Rumour Network production.","cost":{"coins":3800.0},"mods":{"gen_rumour_network":2.0}},
	{"id":"chartered_trade","name":"Chartered Trade","rank":4,"description":"All coin-producing assets gain another 50%.","cost":{"coins":9500.0,"reputation":35.0},"mods":{"res_coins":1.5}},
	{"id":"public_forums","name":"Public Forums","rank":4,"description":"All reputation generation increases by 60%.","cost":{"coins":16000.0,"reputation":100.0},"mods":{"res_reputation":1.6}},
	{"id":"press_relations","name":"Press Relations","rank":4,"description":"Double Rumour Network output again.","cost":{"coins":18000.0,"reputation":95.0},"mods":{"gen_rumour_network":2.0}},
	{"id":"field_organisers","name":"Field Organisers","rank":5,"description":"Double Campaign Office production.","cost":{"coins":32000.0,"reputation":180.0},"mods":{"gen_campaign_office":2.0}},
	{"id":"trusted_councillors","name":"Trusted Councillors","rank":5,"description":"All influence income increases by 75%.","cost":{"coins":75000.0,"reputation":350.0},"mods":{"res_influence":1.75}},
	{"id":"institutional_reform","name":"Institutional Reform","rank":5,"description":"All resources gain a 25% production bonus.","cost":{"coins":120000.0,"reputation":700.0},"mods":{"global":1.25}}
]

const DECISIONS = [
	{"id":"first_contract","title":"The First Contract","rank":2,"description":"Choose what kind of enterprise to build.","options":[
		{"id":"profit","title":"Reinvest profits","description":"+35% coin production, -10% reputation production.","cost":{"coins":450.0},"mods":{"res_coins":1.35,"res_reputation":0.90}},
		{"id":"patrons","title":"Cultivate patrons","description":"+45% reputation production, +20% coin production.","cost":{"coins":450.0},"mods":{"res_reputation":1.45,"res_coins":1.20}}
	]},
	{"id":"guild_charter","title":"A Guild Charter","rank":3,"description":"Your trading contacts propose competing alliances.","options":[
		{"id":"independent","title":"Independent merchants","description":"+40% trade revenue, -15% influence output.","cost":{"coins":6000.0},"mods":{"gen_trading_post":1.40,"res_influence":0.85}},
		{"id":"coalition","title":"Build a coalition","description":"+25% reputation and influence, +10% coin output.","cost":{"coins":5500.0,"reputation":40.0},"mods":{"res_reputation":1.25,"res_influence":1.25,"res_coins":1.10}}
	]},
	{"id":"city_renewal","title":"Renew the City","rank":4,"description":"The district is changing. Where will you invest?","options":[
		{"id":"factories","title":"Industrial renewal","description":"+35% coins, +10% influence; costs more capital.","cost":{"coins":30000.0,"reputation":120.0},"mods":{"res_coins":1.35,"res_influence":1.10}},
		{"id":"housing","title":"Public housing initiative","description":"+60% reputation, +20% influence.","cost":{"coins":22000.0,"reputation":100.0},"mods":{"res_reputation":1.60,"res_influence":1.20}}
	]},
	{"id":"election","title":"Your Political Moment","rank":5,"description":"A civic election offers two different routes to power.","options":[
		{"id":"grassroots","title":"Grassroots organising","description":"+65% influence and +20% reputation.","cost":{"coins":65000.0,"reputation":420.0},"mods":{"res_influence":1.65,"res_reputation":1.20}},
		{"id":"establishment","title":"Establishment support","description":"+35% influence and +40% coins.","cost":{"coins":85000.0,"reputation":300.0},"mods":{"res_influence":1.35,"res_coins":1.40}}
	]}
]

const ACHIEVEMENTS = [
	{"id":"first_coin","title":"The First Coin","hint":"Earn 1 coin."},
	{"id":"first_stall","title":"In Business","hint":"Buy a Street Stall."},
	{"id":"workshop","title":"An Employer","hint":"Own a Workshop."},
	{"id":"first_reputation","title":"Known Around Town","hint":"Earn 1 reputation."},
	{"id":"influence","title":"Political Capital","hint":"Earn 1 influence."},
	{"id":"first_choice","title":"A Defining Choice","hint":"Make a strategic decision."},
	{"id":"civic_leader","title":"Leader of the City","hint":"Reach Civic Leader."},
	{"id":"legacy","title":"A Name Remembered","hint":"Start a new life with Legacy."}
]

# Cumulative, derived rank benefits: existing version-1 saves receive their earned perks.
const RANK_REWARDS = [
 {"narrative":"Below the city's golden towers, your story begins with a single coin.", "unlocks":"Work and your first Street Stall.", "benefit":"Build an income that continues while you are away.", "mods":{}, "icon":"embers"},
 {"narrative":"The alleys have taught you their secrets. You are no longer waiting for fortune: you know where to find it.", "unlocks":"Better Location: double the output of every Street Stall.", "benefit":"Salvage routes: +50% earnings from every WORK tap.", "mods":{"tap":1.5}, "icon":"compass"},
 {"narrative":"A permanent place in the market. Craftspeople seek your patronage, and your first real contract awaits.", "unlocks":"Workshops, supplier upgrades and your first exclusive contract.", "benefit":"Market standing: +10% Street Stall production.", "mods":{"gen_street_stall":1.1}, "icon":"market"},
 {"narrative":"Your name travels farther than your footsteps. Trade now opens doors that money alone cannot.", "unlocks":"Trading Posts, reputation networks and community investment.", "benefit":"Trusted introductions: +10% reputation production.", "mods":{"res_reputation":1.1}, "icon":"routes"},
 {"narrative":"Others trade in goods. You now trade in promises, loyalties and the future of the city.", "unlocks":"Campaign Offices, influence conversion and civic investment choices.", "benefit":"Organising credibility: +10% influence production.", "mods":{"res_influence":1.1}, "icon":"seal"},
 {"narrative":"Your voice carries beyond the market walls. Citizens look to you for institutions that endure.", "unlocks":"Civic Halls, political alliances and advanced influence upgrades.", "benefit":"Public mandate: +5% output across your entire enterprise.", "mods":{"global":1.05}, "icon":"citadel"},
 {"narrative":"The city that once ignored you now entrusts its future to you. This life may end, but your name will remain.", "unlocks":"Legacy prestige: begin anew with a permanent +25% output per point.", "benefit":"City charter: +15% output for the rest of this life.", "mods":{"global":1.15}, "icon":"crown"}
]
